@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "OUT=%CD%\RELEASE\DragonMineZ-LivingWorld-1.0.0.jar"
set "SRCOUT=%CD%\RELEASE\DragonMineZ-LivingWorld-1.0.0-Source.zip"

echo ================================================================
echo DragonMine Z: Living World 1.0.0 - OFFICIAL RELEASE
echo ================================================================
echo.
for %%F in (
  "libs\dragonminez-2.1.3.jar"
  "libs\geckolib-forge-1.20.1-4.8.4.jar"
  "libs\curios-forge-5.14.1+1.20.1.jar"
  "libs\TerraBlender-forge-1.20.1-3.0.1.10.jar"
) do (
  if not exist %%F (
    echo ERROR: Missing required dev dependency %%~F
    goto :fail
  )
)
if exist RELEASE rmdir /s /q RELEASE
mkdir RELEASE

call gradlew.bat --no-daemon clean releaseLivingWorldJar
if errorlevel 1 goto :fail
if not exist "%OUT%" (
  echo ERROR: Gradle finished but Living World's release JAR was not created.
  goto :fail
)
if not exist "%SRCOUT%" (
  echo ERROR: GPL source archive was not created.
  goto :fail
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%CD%\VERIFY_LIVING_WORLD_JAR.ps1" -JarPath "%OUT%"
if errorlevel 1 goto :fail

echo.
echo SUCCESS - verified dmzlivingworld 1.0.0 release artifact
echo JAR: %OUT%
echo SOURCE: %SRCOUT%
echo.
echo Copy ONLY that RELEASE JAR into your normal Minecraft mods folder.
pause
exit /b 0

:fail
echo.
echo BUILD FAILED OR OUTPUT VERIFICATION FAILED.
echo Do not copy anything from libs. Send the first Gradle/Java error block exactly as shown.
pause
exit /b 1
