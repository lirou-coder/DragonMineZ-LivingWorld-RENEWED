param(
    [Parameter(Mandatory=$true)]
    [string]$JarPath
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem

if (-not (Test-Path -LiteralPath $JarPath)) {
    Write-Host "ERROR: release JAR not found: $JarPath"
    exit 2
}

$zip = [IO.Compression.ZipFile]::OpenRead($JarPath)
try {
    $modsEntry = $zip.GetEntry('META-INF/mods.toml')
    if ($null -eq $modsEntry) { Write-Host 'ERROR: mods.toml missing.'; exit 3 }
    $reader = New-Object IO.StreamReader($modsEntry.Open())
    try { $modsToml = $reader.ReadToEnd() } finally { $reader.Dispose() }
    if (-not $modsToml.Contains('modId="dmzlivingworld"')) { Write-Host 'ERROR: built JAR is not dmzlivingworld.'; exit 4 }
    if (-not $modsToml.Contains('version="1.0.0"')) { Write-Host 'ERROR: built JAR does not report version 1.0.0.'; exit 8 }
    if (-not $modsToml.Contains('license="GNU General Public License v3.0"')) { Write-Host 'ERROR: built JAR does not report GPLv3 in mods.toml.'; exit 9 }
    if ($modsToml.Contains('All Rights Reserved')) { Write-Host 'ERROR: stale All Rights Reserved metadata found.'; exit 10 }
    if ($null -eq $zip.GetEntry('META-INF/LICENSE_dmzlivingworld.txt')) { Write-Host 'ERROR: GPLv3 license is not packaged in the JAR.'; exit 11 }
    if ($null -eq $zip.GetEntry('META-INF/NOTICE_dmzlivingworld.txt')) { Write-Host 'ERROR: third-party/license notice is not packaged in the JAR.'; exit 12 }

    $required = @(
        'com/dmzlivingworld/world/FighterArsenalManager.class',
        'com/dmzlivingworld/world/FighterLegacyManager.class',
        'com/dmzlivingworld/world/FighterLegacyWorldData.class',
        'com/dmzlivingworld/world/FighterTechniqueManager.class',
        'com/dmzlivingworld/world/FighterGoalManager.class',
        'com/dmzlivingworld/world/FighterInspectionManager.class',
        'com/dmzlivingworld/world/PeacekeeperManager.class',
        'com/dmzlivingworld/world/LivingWorldLifecycle.class',
        'com/dmzlivingworld/client/screen/FactionDossierScreen.class'
    )
    foreach ($entry in $required) {
        if ($null -eq $zip.GetEntry($entry)) { Write-Host "ERROR: required entry missing: $entry"; exit 5 }
    }

    foreach ($prefix in @('com/dragonminez/','software/bernie/geckolib/','top/theillusivec4/curios/')) {
        $bad = $zip.Entries | Where-Object { $_.FullName.StartsWith($prefix) } | Select-Object -First 1
        if ($null -ne $bad) { Write-Host "ERROR: dependency class accidentally bundled: $($bad.FullName)"; exit 6 }
    }
    $nested = $zip.Entries | Where-Object { $_.FullName -like 'libs/*' -or $_.FullName -match '\.jar$' } | Select-Object -First 1
    if ($null -ne $nested) { Write-Host "ERROR: nested dependency JAR found: $($nested.FullName)"; exit 7 }

    Write-Host 'VERIFIED: Living World 1.0.0 release JAR structure is valid.'
    exit 0
}
finally {
    $zip.Dispose()
}
