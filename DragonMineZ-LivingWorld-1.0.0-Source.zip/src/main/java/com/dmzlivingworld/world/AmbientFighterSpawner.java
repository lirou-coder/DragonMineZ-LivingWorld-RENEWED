package com.dmzlivingworld.world;

import com.dmzlivingworld.LivingWorldMod;
import com.dmzlivingworld.entity.AmbientFighterEntity;
import com.dmzlivingworld.entity.FighterAlignment;
import com.dmzlivingworld.entity.FighterArchetype;
import com.dmzlivingworld.entity.FighterRace;
import com.dmzlivingworld.entity.FighterPersonality;
import com.dmzlivingworld.entity.FighterRank;
import com.dmzlivingworld.entity.LWEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;
import java.util.UUID;

/** Lightweight Earth + Namek encounter population, not vanilla biome spawn injection. */
@Mod.EventBusSubscriber(modid = LivingWorldMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class AmbientFighterSpawner {
    private static final int CHECK_INTERVAL = 400; // 20 seconds, staggered per player.
    private static final double NATURAL_ROLL = 0.40D;
    private static final double DYNAMIC_ENCOUNTER_SHARE = 0.25D;
    private static final double FACTION_ENCOUNTER_SHARE = 0.38D;
    private static final double RECURRING_FIGHTER_SHARE = 0.12D;
    private static final double LOCAL_RADIUS = 160.0D;
    private static final int LOCAL_CAP = 20;
    private static final int LOCAL_BAD_CAP = 6;
    private static final int MIN_DISTANCE = 38;
    private static final int MAX_DISTANCE = 72;

    private AmbientFighterSpawner() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            if (!(player.level() instanceof ServerLevel level)) continue;
            if (!LivingWorldDimensions.isSupported(level)) continue;

            // Create/persist the shared Earth/Namek social map automatically as soon as
            // either supported world becomes active.
            FactionWorldData factionData = FactionWorldData.get(level);
            factionData.tickOrganizations(level);
            if (player.isSpectator() || player.isCreative()) continue;

            long gameTime = level.getGameTime();
            int stagger = Math.floorMod(player.getUUID().hashCode(), CHECK_INTERVAL);
            if (Math.floorMod(gameTime + stagger, CHECK_INTERVAL) != 0) continue;

            RandomSource random = player.getRandom();

            List<AmbientFighterEntity> nearby = level.getEntitiesOfClass(
                    AmbientFighterEntity.class,
                    player.getBoundingBox().inflate(LOCAL_RADIUS)
            );
            if (nearby.size() >= LOCAL_CAP) continue;

            // Visiting a generated faction region now has a concrete contract: if its
            // resident cell is absent, manifest one before rolling unrelated encounters.
            WorldFaction regionalFaction = FactionManager.factionsForRealm(level).stream()
                    .filter(f -> {
                        double dx = f.roamX() - player.getX();
                        double dz = f.roamZ() - player.getZ();
                        return dx * dx + dz * dz <= (double) f.roamRadius() * f.roamRadius();
                    })
                    .min(java.util.Comparator.comparingDouble(f -> {
                        double dx = f.roamX() - player.getX();
                        double dz = f.roamZ() - player.getZ();
                        return dx * dx + dz * dz;
                    })).orElse(null);
            if (regionalFaction != null && LOCAL_CAP - nearby.size() >= 4
                    && FactionEncounterManager.ensureRegionalPresence(player, regionalFaction, false)) {
                continue;
            }

            if (random.nextDouble() >= NATURAL_ROLL) continue;

            long badCount = nearby.stream().filter(f -> f.getAlignment() == FighterAlignment.BAD).count();
            int capacity = LOCAL_CAP - nearby.size();
            int remainingBadSlots = LOCAL_BAD_CAP - (int) badCount;

            // A small share of successful pulses can reintroduce somebody the player
            // has genuinely met before. This is deliberately rarer than fresh strangers.
            if (capacity >= 1 && random.nextDouble() < RECURRING_FIGHTER_SHARE
                    && FighterMemoryManager.trySpawnRecurring(player, false)) {
                continue;
            }

            // Faction parties are common enough to make the social map visible, but
            // independents remain the majority of individual people in the world.
            if (capacity >= 2 && random.nextDouble() < FACTION_ENCOUNTER_SHARE) {
                if (FactionEncounterManager.trySpawnNatural(player, capacity)) {
                    continue;
                }
            }

            // Existing Living World scenes remain alongside faction life.
            if (capacity >= 2 && random.nextDouble() < DYNAMIC_ENCOUNTER_SHARE) {
                if (DynamicEncounterManager.trySpawnNaturalEncounter(player, capacity, remainingBadSlots)) {
                    continue;
                }
            }

            FighterAlignment alignment = FighterAlignment.roll(random);
            if (alignment == FighterAlignment.BAD && remainingBadSlots <= 0) {
                alignment = random.nextBoolean() ? FighterAlignment.GOOD : FighterAlignment.NEUTRAL;
            }

            AmbientFighterEntity spawned = spawnNearPlayer(player, alignment, FighterRank.roll(random), false);
            if (spawned != null && alignment != FighterAlignment.BAD && random.nextFloat() < 0.20F) {
                spawned.setNonCombatant(true);
                if (spawned.getSpeech().isEmpty() && random.nextFloat() < 0.25F) spawned.speak("Just passing through.", 42);
            }
        }
    }

    public static AmbientFighterEntity spawnNearPlayer(ServerPlayer player, FighterAlignment alignment,
                                                         FighterRank rank, boolean closeForDebug) {
        return spawnNearPlayer(player, alignment, rank, null, closeForDebug);
    }

    public static AmbientFighterEntity spawnNearPlayer(ServerPlayer player, FighterAlignment alignment,
                                                         FighterRank rank, FighterPersonality personality,
                                                         boolean closeForDebug) {
        if (!(player.level() instanceof ServerLevel level) || !LivingWorldDimensions.isSupported(level)) return null;
        int min = closeForDebug ? 7 : MIN_DISTANCE;
        int max = closeForDebug ? 13 : MAX_DISTANCE;
        BlockPos pos = findSafeGroundAround(level, player.blockPosition(), player.getRandom(), min, max, 18);
        if (pos == null) return null;
        return spawnAt(level, pos, alignment, rank, personality, player.getRandom());
    }

    public static AmbientFighterEntity spawnNearPlayer(ServerPlayer player, FighterAlignment alignment, boolean debug) {
        return spawnNearPlayer(player, alignment, FighterRank.roll(player.getRandom()), debug);
    }

    /** Finds a safe central point for a multi-fighter scene. */
    public static BlockPos findEncounterAnchor(ServerPlayer player, boolean debug) {
        if (!(player.level() instanceof ServerLevel level) || !LivingWorldDimensions.isSupported(level)) return null;
        int min = debug ? 9 : MIN_DISTANCE;
        int max = debug ? 15 : 62;
        return findSafeGroundAround(level, player.blockPosition(), player.getRandom(), min, max, 24);
    }

    /** Places a fighter a few blocks around an encounter anchor. */
    public static AmbientFighterEntity spawnAroundAnchor(ServerPlayer player, BlockPos anchor,
                                                          FighterAlignment alignment, FighterRank rank,
                                                          FighterPersonality personality, int minRadius, int maxRadius) {
        if (!(player.level() instanceof ServerLevel level) || anchor == null) return null;
        BlockPos pos = findSafeGroundAround(level, anchor, player.getRandom(), minRadius, maxRadius, 14);
        if (pos == null) pos = anchor;
        return spawnAt(level, pos, alignment, rank, personality, player.getRandom());
    }

    public static AmbientFighterEntity spawnAt(ServerLevel level, BlockPos pos, FighterAlignment alignment,
                                                 FighterRank rank, FighterPersonality personality,
                                                 RandomSource random) {
        return spawnAt(level, pos, alignment, rank, personality, null, null, random);
    }

    public static AmbientFighterEntity spawnAt(ServerLevel level, BlockPos pos, FighterAlignment alignment,
                                                 FighterRank rank, FighterPersonality personality,
                                                 FighterRace race, FighterArchetype archetype,
                                                 RandomSource random) {
        if (!level.getWorldBorder().isWithinBounds(pos) || !isUsableGround(level, pos)) return null;

        AmbientFighterEntity fighter = LWEntities.AMBIENT_FIGHTER.get().create(level);
        if (fighter == null) return null;
        fighter.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, random.nextFloat() * 360.0F, 0.0F);
        FighterPersonality resolvedPersonality = personality == null
                ? FighterPersonality.roll(random, alignment) : personality;
        FighterRace resolvedRace = race == null ? rollRaceForLevel(level, random) : race;
        FighterArchetype resolvedArchetype = archetype == null ? FighterArchetype.roll(random, rank) : archetype;
        fighter.initializeAs(alignment, rank, resolvedPersonality, resolvedRace, resolvedArchetype);
        fighter.setBattlePower(WorldPowerScaler.rollBattlePower(level, pos, rank, random));
        if (!level.noCollision(fighter)) return null;

        level.addFreshEntity(fighter);
        return fighter;
    }


    public static AmbientFighterEntity spawnRemembered(ServerPlayer player, CompoundTag profile, UUID recordId,
                                                         int encounters, int relationship, boolean rescued,
                                                         boolean closeForDebug) {
        if (!(player.level() instanceof ServerLevel level) || !LivingWorldDimensions.isSupported(level)) return null;
        int min = closeForDebug ? 8 : MIN_DISTANCE;
        int max = closeForDebug ? 14 : MAX_DISTANCE;
        BlockPos pos = findSafeGroundAround(level, player.blockPosition(), player.getRandom(), min, max, 22);
        if (pos == null) return null;
        AmbientFighterEntity fighter = LWEntities.AMBIENT_FIGHTER.get().create(level);
        if (fighter == null) return null;
        fighter.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, player.getRandom().nextFloat() * 360.0F, 0.0F);
        fighter.initializeFromMemory(profile);
        fighter.bindMemory(player.getUUID(), recordId, encounters, relationship, rescued);
        if (!level.noCollision(fighter)) return null;
        level.addFreshEntity(fighter);
        return fighter;
    }


    public static FighterRace rollRaceForLevel(ServerLevel level, RandomSource random) {
        if (LivingWorldDimensions.realm(level) == FactionRealm.NAMEK) {
            int roll = random.nextInt(100);
            if (roll < 58) return FighterRace.NAMEKIAN;
            if (roll < 70) return FighterRace.HUMAN;
            if (roll < 82) return FighterRace.SAIYAN;
            if (roll < 89) return FighterRace.MAJIN;
            if (roll < 95) return FighterRace.FROST_DEMON;
            return FighterRace.BIO_ANDROID;
        }
        return FighterRace.roll(random);
    }

    public static BlockPos findSafeGroundAround(ServerLevel level, BlockPos center, RandomSource random,
                                                  int minDistance, int maxDistance, int attempts) {
        for (int attempt = 0; attempt < attempts; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2.0D;
            int distance = Mth.nextInt(random, Math.max(0, minDistance), Math.max(minDistance, maxDistance));
            int x = Mth.floor(center.getX() + 0.5D + Math.cos(angle) * distance);
            int z = Mth.floor(center.getZ() + 0.5D + Math.sin(angle) * distance);

            BlockPos rough = new BlockPos(x, center.getY(), z);
            if (!level.hasChunkAt(rough)) continue;

            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos spawnPos = new BlockPos(x, y, z);
            if (!level.getWorldBorder().isWithinBounds(spawnPos)) continue;
            if (!isUsableGround(level, spawnPos)) continue;
            return spawnPos;
        }
        return null;
    }

    public static boolean isUsableGround(ServerLevel level, BlockPos pos) {
        BlockPos below = pos.below();
        if (!level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) return false;
        if (!level.getFluidState(pos).isEmpty() || !level.getFluidState(pos.above()).isEmpty()) return false;
        return level.getBlockState(pos).isAir() && level.getBlockState(pos.above()).isAir();
    }
}
