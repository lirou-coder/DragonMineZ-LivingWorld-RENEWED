package com.dmzlivingworld.network;

import com.dmzlivingworld.LivingWorldMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** Tiny S2C channel used only for presentation snapshots. Simulation remains server authoritative. */
public final class LWNetwork {
    private static final String PROTOCOL = "5";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(LivingWorldMod.MOD_ID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    private static int nextId;
    private static boolean registered;

    private LWNetwork() {}

    public static void register() {
        if (registered) return;
        registered = true;
        CHANNEL.registerMessage(nextId++, FactionDossierPacket.class,
                FactionDossierPacket::encode,
                FactionDossierPacket::decode,
                FactionDossierPacket::handle);
        CHANNEL.registerMessage(nextId++, LivingWorldMenuRequestPacket.class,
                LivingWorldMenuRequestPacket::encode,
                LivingWorldMenuRequestPacket::decode,
                LivingWorldMenuRequestPacket::handle);
    }

    public static void sendFactionDossier(ServerPlayer player, FactionDossierPacket packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }

    public static void requestMenu(String page, int slot) {
        CHANNEL.sendToServer(new LivingWorldMenuRequestPacket(page, slot));
    }
}
