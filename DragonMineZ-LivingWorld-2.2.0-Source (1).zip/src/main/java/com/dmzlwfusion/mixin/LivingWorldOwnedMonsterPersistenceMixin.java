package com.dmzlwfusion.mixin;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Keeps only Living World-owned native minions functional through vanilla Peaceful/distance rules. */
@Mixin(value = Mob.class, remap = false)
public abstract class LivingWorldOwnedMonsterPersistenceMixin {
    private boolean dmzlivingworld$isOwnedMinion(Mob self) {
        var data = self.getPersistentData();
        return data.getBoolean("LWScientistPersistentSpecimen") || data.getBoolean("LWX7Reinforcement");
    }

    @Inject(method = {"shouldDespawnInPeaceful()Z", "m_8028_()Z"}, at = @At("HEAD"), cancellable = true, remap = false)
    private void dmzlivingworld$keepOwnedMinionsInPeaceful(CallbackInfoReturnable<Boolean> cir) {
        Mob self = (Mob)(Object)this;
        if (self.level().isClientSide || !dmzlivingworld$isOwnedMinion(self)) return;
        self.setPersistenceRequired();
        cir.setReturnValue(false);
    }

    @Inject(method = {"doHurtTarget(Lnet/minecraft/world/entity/Entity;)Z", "m_7327_(Lnet/minecraft/world/entity/Entity;)Z"}, at = @At("HEAD"), cancellable = true, remap = false)
    private void dmzlivingworld$ownedMinionPeacefulDamage(Entity target, CallbackInfoReturnable<Boolean> cir) {
        Mob self = (Mob)(Object)this;
        if (self.level().isClientSide || self.level().getDifficulty() != Difficulty.PEACEFUL
                || !dmzlivingworld$isOwnedMinion(self) || !(target instanceof ServerPlayer player)) return;
        double raw = self.getAttributeValue(Attributes.ATTACK_DAMAGE);
        if (raw <= 0.0D) { cir.setReturnValue(false); return; }
        player.invulnerableTime = 0;
        cir.setReturnValue(player.hurt(self.level().damageSources().generic(), (float)raw));
    }
}
