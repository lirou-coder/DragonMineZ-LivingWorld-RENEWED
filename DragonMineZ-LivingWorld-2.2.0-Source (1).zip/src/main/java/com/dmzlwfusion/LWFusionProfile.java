package com.dmzlwfusion;

import net.minecraft.world.entity.LivingEntity;

import java.util.HashMap;
import java.util.Map;

/**
 * Converts an LW fighter's existing combat identity into the six DMZ stats only
 * for the duration of fusion math. It does NOT add a second progression system
 * to Living World and nothing is written back to the NPC.
 */
public final class LWFusionProfile {
    private final int totalStats;
    private final Map<String, Integer> stats;

    private LWFusionProfile(int totalStats, Map<String, Integer> stats) {
        this.totalStats = totalStats;
        this.stats = stats;
    }

    public int totalStats() {
        return totalStats;
    }

    public int stat(String name) {
        return Math.max(0, stats.getOrDefault(name, 0));
    }

    public static LWFusionProfile from(LivingEntity fighter) {
        int battlePower = LivingWorldCompat.battlePower(fighter);

        // Inverse of DMZ's unmodified 100%-release BP curve for a roughly even
        // six-stat character:
        //   BP = 1200 * (effective / 100)^1.2
        // and an even character has effective ~= totalStats / 1.2.
        // This yields a native-scale equivalent stat budget without pretending
        // LW has its own hidden player StatsData capability.
        double effective = 100.0D * Math.pow(Math.max(1.0D, battlePower) / 1200.0D, 1.0D / 1.2D);
        int total = Math.max(6, (int) Math.round(effective * 1.2D));

        double[] weights = switch (LivingWorldCompat.archetype(fighter)) {
            case "BRAWLER" -> new double[]{1.45, 0.95, 1.10, 1.30, 0.55, 0.65};
            case "KI_SPECIALIST" -> new double[]{0.70, 0.80, 0.80, 0.85, 1.55, 1.30};
            case "SPEEDSTER", "SPEED_FIGHTER" -> new double[]{0.85, 1.60, 0.85, 0.80, 0.85, 1.05};
            case "GUARDIAN" -> new double[]{0.90, 0.80, 1.45, 1.45, 0.65, 0.75};
            default -> new double[]{1.10, 1.10, 1.00, 1.00, 0.90, 0.90};
        };

        String[] names = {"STR", "SKP", "RES", "VIT", "PWR", "ENE"};
        double weightSum = 0.0D;
        for (double weight : weights) weightSum += weight;

        // Allocate with largest remainders so the six derived values always
        // sum to the exact native-scale budget. This matters because DMZ's
        // Metamoran gap check and bonus multiplier both use total stats.
        Map<String, Integer> result = new HashMap<>();
        int[] values = new int[names.length];
        double[] fractions = new double[names.length];
        int assigned = 0;
        for (int i = 0; i < names.length; i++) {
            double exact = total * (weights[i] / weightSum);
            values[i] = Math.max(1, (int) Math.floor(exact));
            fractions[i] = exact - Math.floor(exact);
            assigned += values[i];
        }
        while (assigned < total) {
            int best = 0;
            for (int i = 1; i < fractions.length; i++) {
                if (fractions[i] > fractions[best]) best = i;
            }
            values[best]++;
            fractions[best] = -1.0D;
            assigned++;
        }
        while (assigned > total) {
            int best = -1;
            for (int i = 0; i < values.length; i++) {
                if (values[i] > 1 && (best < 0 || fractions[i] < fractions[best])) best = i;
            }
            if (best < 0) break;
            values[best]--;
            assigned--;
        }
        for (int i = 0; i < names.length; i++) result.put(names[i], values[i]);
        return new LWFusionProfile(total, result);
    }
}
