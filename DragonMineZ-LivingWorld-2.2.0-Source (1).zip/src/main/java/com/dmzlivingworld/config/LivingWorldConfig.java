package com.dmzlivingworld.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** World-specific Living World settings. Registered as a Forge SERVER config. */
public final class LivingWorldConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.IntValue NEARBY_FIGHTER_CAP;
    public static final ForgeConfigSpec.IntValue NEARBY_HOSTILE_CAP;
    public static final ForgeConfigSpec.BooleanValue FACTION_ENCOUNTERS;
    public static final ForgeConfigSpec.BooleanValue DYNAMIC_ENCOUNTERS;
    public static final ForgeConfigSpec.BooleanValue RECURRING_FIGHTERS;
    public static final ForgeConfigSpec.IntValue LIVING_PRESENCE_TARGET;
    public static final ForgeConfigSpec.IntValue LIVING_PRESENCE_RADIUS;
    public static final ForgeConfigSpec.IntValue NPC_DESPAWN_PROTECTION_RADIUS;
    public static final ForgeConfigSpec.IntValue FACTION_RESIDENT_CAP;
    public static final ForgeConfigSpec.BooleanValue AUTOMATIC_POWER_SENSING;
    public static final ForgeConfigSpec.BooleanValue WORLD_INCIDENTS;
    public static final ForgeConfigSpec.BooleanValue WORLD_EVENT_ALERTS;
    public static final ForgeConfigSpec.IntValue WORLD_EVENT_ALERT_RADIUS;
    public static final ForgeConfigSpec.BooleanValue SOCIAL_TALK;
    public static final ForgeConfigSpec.IntValue TALK_BASE_GAIN;
    public static final ForgeConfigSpec.IntValue TALK_RELATIONSHIP_CAP;
    public static final ForgeConfigSpec.IntValue TALK_COOLDOWN_MIN_SECONDS;
    public static final ForgeConfigSpec.IntValue TALK_COOLDOWN_MAX_SECONDS;
    public static final ForgeConfigSpec.BooleanValue NPC_SOCIALIZING;
    public static final ForgeConfigSpec.IntValue NPC_CHAT_FREQUENCY_PERCENT;
    public static final ForgeConfigSpec.IntValue NPC_CHAOS_PERCENT;
    public static final ForgeConfigSpec.IntValue NPC_STRENGTH_PERCENT;
    public static final ForgeConfigSpec.IntValue NPC_GROWTH_PERCENT;
    public static final ForgeConfigSpec.BooleanValue ATTACK_MINECRAFT_MOBS;
    public static final ForgeConfigSpec.BooleanValue COMPANION_SAGA_HELP;
    public static final ForgeConfigSpec.IntValue EARTH_GUARDIAN_RESPONSE_PERCENT;
    public static final ForgeConfigSpec.IntValue NPC_KI_MODE;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.comment(
                "Dragon Mine Z: Living World — per-world/server settings.",
                "Most important options are also available from L -> Settings. Advanced values remain editable here.")
                .push("world");

        builder.push("population");
        NEARBY_FIGHTER_CAP = builder.comment(
                        "Maximum Living World fighters naturally maintained near each player.",
                        "Large values increase active fighter AI cost; lowering this does not remove fighters who already exist.")
                .defineInRange("nearbyFighterCap", 20, 0, 4096);
        NEARBY_HOSTILE_CAP = builder.comment("Maximum naturally generated hostile Living World fighters near each player.")
                .defineInRange("nearbyHostileCap", 6, 0, 4096);
        FACTION_RESIDENT_CAP = builder.comment("Maximum physical resident cell size that one faction territory can request. Still bounded by the local fighter cap.")
                .defineInRange("factionResidentCap", 15, 4, 512);
        builder.pop();

        builder.push("livingPresence");
        RECURRING_FIGHTERS = builder.comment(
                        "Allow persistent remembered fighters whose simulated lives are nearby to become real loaded NPCs.",
                        "No chunks are force-loaded and the normal local population cap still applies.")
                .define("enabled", true);
        LIVING_PRESENCE_TARGET = builder.comment(
                        "Preferred number of remembered people physically present near a player.",
                        "0 disables natural materialization without deleting memories.")
                .defineInRange("targetRememberedPeople", 2, 0, 128);
        LIVING_PRESENCE_RADIUS = builder.comment("Maximum approximate distance in blocks for a simulated remembered life to qualify for materialization.")
                .defineInRange("materializationRadius", 256, 96, 8192);
        NPC_DESPAWN_PROTECTION_RADIUS = builder.comment(
                        "Distance in blocks around a non-spectator player where loaded Living World fighters are protected from native despawn.",
                        "RC8 default is 288 blocks (3x the former hard-coded 96-block protection).")
                .defineInRange("npcDespawnProtectionRadius", 288, 96, 4096);
        builder.pop();

        builder.push("encounters");
        FACTION_ENCOUNTERS = builder.comment("Allow natural faction patrols/parties and regional faction presence.")
                .define("factionEncounters", true);
        DYNAMIC_ENCOUNTERS = builder.comment("Allow small scenes such as duels, clashes, rescues and ambushes.")
                .define("dynamicEncounters", true);
        WORLD_INCIDENTS = builder.comment("Allow slow history-driven incidents between fighters who already exist.")
                .define("worldIncidents", true);
        WORLD_EVENT_ALERTS = builder.comment("Notify nearby players when a noteworthy physical world event is happening so they can travel to its coordinates.")
                .define("eventAlerts", true);
        WORLD_EVENT_ALERT_RADIUS = builder.comment("Maximum distance in blocks for Living World coordinate/event alerts.")
                .defineInRange("eventAlertRadius", 1400, 128, 32768);
        builder.pop();

        builder.push("social");
        SOCIAL_TALK = builder.comment("Enable the low-pressure Talk interaction that lets strangers naturally become Familiar.")
                .define("talkEnabled", true);
        TALK_BASE_GAIN = builder.comment("Base relationship gain from a successful Talk before personality/social-nature adjustment.")
                .defineInRange("talkBaseGain", 2, 0, 50);
        TALK_RELATIONSHIP_CAP = builder.comment("Maximum personal relationship Talk alone can reach. Shared experiences are required above this value.")
                .defineInRange("talkRelationshipCap", 20, 0, 100);
        TALK_COOLDOWN_MIN_SECONDS = builder.comment("Minimum real gameplay seconds before the same persistent person can grant Talk progress again.")
                .defineInRange("talkCooldownMinSeconds", 120, 10, 86400);
        TALK_COOLDOWN_MAX_SECONDS = builder.comment("Maximum Talk cooldown. Values below the minimum are clamped at runtime.")
                .defineInRange("talkCooldownMaxSeconds", 240, 10, 86400);
        NPC_SOCIALIZING = builder.comment(
                        "Allow idle Living World fighters to have sparse, situation-aware conversations and build lightweight bonds with each other.",
                        "This also allows compatible NPC pairs to occasionally meditate together. It does not create chat spam or a second player relationship currency.")
                .define("npcSocializing", true);
        NPC_CHAT_FREQUENCY_PERCENT = builder.comment(
                        "How often autonomous Living World NPC conversations are attempted.",
                        "100 = the established normal cadence; 0 suppresses autonomous NPC chatter without disabling explicit Talk or authored scene dialogue; higher values make social chatter more frequent.")
                .defineInRange("npcChatFrequencyPercent", 100, 0, 500);
        builder.pop();

        builder.push("behavior");
        NPC_CHAOS_PERCENT = builder.comment(
                        "World activity: controls the pace of ambient NPC life and optional spontaneous fights.",
                        "100 = normal activity; lower values are calmer, higher values are busier.",
                        "Self-defense, explicit duels and intentional story/faction conflicts are unaffected.")
                .defineInRange("npcChaosPercent", 100, 0, 1000);
        NPC_STRENGTH_PERCENT = builder.comment(
                        "Living World fighter strength/difficulty baseline.",
                        "100 = normal current balance; lower values create a weaker population, higher values a stronger one.",
                        "This scales the world-era anchor used for NEW fighters and future earned progression ceilings.",
                        "Changing it does not rewrite the current BP of fighters who already exist and never directly matches NPC BP to the player.")
                .defineInRange("npcStrengthPercent", 100, 25, 1000);
        NPC_GROWTH_PERCENT = builder.comment(
                        "Living World fighter earned growth speed.",
                        "100 = normal progression; 0 freezes earned BP/legacy growth; values above 100 accelerate earned progression.",
                        "Applies to training, meditation, jogging and meaningful fights without directly matching NPC BP to the player.")
                .defineInRange("npcGrowthPercent", 100, 0, 1000);
        ATTACK_MINECRAFT_MOBS = builder.comment(
                        "Allow ordinary Living World fighters to initiate combat against Minecraft entities outside authored Living World conflicts.",
                        "Turning this off protects ordinary animals, pets, villagers and monsters from proactive LW combat. A registered companion can still defend its player from a Minecraft attacker; authored LW/faction/story conflicts remain intact.")
                .define("attackMinecraftMobs", true);
        COMPANION_SAGA_HELP = builder.comment(
                        "Allow a fighter travelling with the player to help against Dragon Mine Z saga enemies.",
                        "When disabled, companions still protect the player from Living World fighters and ordinary Minecraft threats.")
                .define("companionSagaHelp", true);
        EARTH_GUARDIAN_RESPONSE_PERCENT = builder.comment(
                        "How frequently the Earth Guardian Corps responds to violence, crime and player-targeted emergencies when its existing response rules otherwise qualify.",
                        "100 = the established normal response frequency; 0 disables optional Corps response rolls; higher values make eligible responses more likely without changing faction reputation requirements or authored conflicts.")
                .defineInRange("earthGuardianResponsePercent", 100, 0, 500);
        builder.pop();

        builder.push("awareness");
        AUTOMATIC_POWER_SENSING = builder.comment("Show automatic nearby-power sensing notifications. Manual /lw sense is unaffected.")
                .define("automaticPowerSensing", true);
        builder.pop();

        builder.push("kiSecurity");
        NPC_KI_MODE = builder.comment(
                        "How Living World NPC Ki attacks interact with blocks. Player damage is unchanged in every Ki-enabled mode.",
                        "GUI order: Normal -> Player Blocks -> Player + World -> Ki Off.",
                        "Stored values preserve older worlds: 0 = Normal; 1 = Player + World; 2 = Ki Off; 3 = Player Blocks.",
                        "Player Blocks protects tracked player-placed blocks but still allows natural terrain destruction.",
                        "Player + World protects all blocks while NPC Ki can still hurt players.")
                .defineInRange("npcKiMode", 1, 0, 3);
        builder.pop();

        builder.pop();
        SPEC = builder.build();
    }

    private LivingWorldConfig() {}

    /** Retained in the network snapshot for compatibility with older 1.9 release candidates. */
    public static int activityPreset() { return 2; }
    public static int nearbyFighterCap() { return NEARBY_FIGHTER_CAP.get(); }
    public static int nearbyHostileCap() { return Math.min(NEARBY_HOSTILE_CAP.get(), nearbyFighterCap()); }
    public static boolean factionEncounters() { return FACTION_ENCOUNTERS.get(); }
    public static boolean dynamicEncounters() { return DYNAMIC_ENCOUNTERS.get(); }
    public static boolean recurringFighters() { return RECURRING_FIGHTERS.get(); }
    public static int livingPresenceTarget() {
        return LIVING_PRESENCE_TARGET.get();
    }
    public static int livingPresenceRadius() { return LIVING_PRESENCE_RADIUS.get(); }
    public static int npcDespawnProtectionRadius() { return NPC_DESPAWN_PROTECTION_RADIUS.get(); }
    public static int factionResidentCap() { return FACTION_RESIDENT_CAP.get(); }
    public static boolean automaticPowerSensing() { return AUTOMATIC_POWER_SENSING.get(); }
    public static boolean worldIncidents() { return WORLD_INCIDENTS.get(); }
    public static boolean worldEventAlerts() { return WORLD_EVENT_ALERTS.get(); }
    public static int worldEventAlertRadius() { return WORLD_EVENT_ALERT_RADIUS.get(); }
    public static boolean socialTalk() { return SOCIAL_TALK.get(); }
    public static int talkBaseGain() { return TALK_BASE_GAIN.get(); }
    public static int talkRelationshipCap() { return TALK_RELATIONSHIP_CAP.get(); }
    public static int talkCooldownMinSeconds() { return TALK_COOLDOWN_MIN_SECONDS.get(); }
    public static int talkCooldownMaxSeconds() { return Math.max(talkCooldownMinSeconds(), TALK_COOLDOWN_MAX_SECONDS.get()); }
    public static boolean npcSocializing() { return NPC_SOCIALIZING.get(); }
    public static int npcChatFrequencyPercent() { return NPC_CHAT_FREQUENCY_PERCENT.get(); }
    public static double npcChatFrequencyScale() { return npcChatFrequencyPercent() / 100.0D; }

    /**
     * Scale an autonomous chatter probability while preserving the established DEV4 cadence at 100%.
     * Authored/explicit dialogue does not call this helper.
     */
    public static float scaledNpcChatChance(float baseChance) {
        if (baseChance <= 0.0F) return 0.0F;
        double scale = npcChatFrequencyScale();
        if (scale <= 0.0D) return 0.0F;
        return (float)Math.min(1.0D, baseChance * scale);
    }

    /**
     * Scale autonomous chatter cooldowns inversely with the configured frequency.
     * 100% returns the exact pre-2.1 delay; 50% doubles it; 200% halves it.
     */
    public static long scaledNpcChatDelay(long baseDelayTicks) {
        if (baseDelayTicks <= 0L) return 0L;
        double scale = npcChatFrequencyScale();
        if (scale <= 0.0D) return Long.MAX_VALUE / 4L;
        return Math.max(1L, Math.round(baseDelayTicks / scale));
    }
    public static int npcChaosPercent() { return NPC_CHAOS_PERCENT.get(); }
    public static int npcStrengthPercent() { return NPC_STRENGTH_PERCENT.get(); }
    public static double npcStrengthScale() { return npcStrengthPercent() / 100.0D; }
    public static int npcGrowthPercent() { return NPC_GROWTH_PERCENT.get(); }
    public static double npcGrowthScale() { return npcGrowthPercent() / 100.0D; }
    public static boolean attackMinecraftMobs() { return ATTACK_MINECRAFT_MOBS.get(); }
    public static boolean companionSagaHelp() { return COMPANION_SAGA_HELP.get(); }
    public static int earthGuardianResponsePercent() { return EARTH_GUARDIAN_RESPONSE_PERCENT.get(); }
    public static double earthGuardianResponseScale() { return earthGuardianResponsePercent() / 100.0D; }
    public static double ambientConflictRoll() {
        // 100% is the normal frequency. This multiplier gates optional free-roaming
        // aggression; explicit targets, self-defense and intentional conflicts bypass it.
        return 0.002D * (npcChaosPercent() / 100.0D);
    }
    public static int npcKiMode() { return NPC_KI_MODE.get(); }

    public static int naturalCheckIntervalTicks() {
        // Below 100%, fewer population opportunities are evaluated. At and above 100%,
        // keep a stable cadence and scale the NUMBER of opportunities instead of squeezing
        // one probability toward 100%; this makes 500% genuinely feel about five times busier.
        int chaos = npcChaosPercent();
        if (chaos <= 0) return 1200;
        if (chaos >= 100) return 400;
        return clamp((int)Math.round(400.0D * 100.0D / Math.max(10, chaos)), 400, 4000);
    }

    public static int naturalActivityAttempts() {
        int chaos = npcChaosPercent();
        if (chaos <= 0) return 0;
        return clamp((int)Math.ceil(chaos / 100.0D), 1, 10);
    }

    public static double naturalSpawnRoll() {
        int chaos = npcChaosPercent();
        if (chaos <= 0) return 0.0D;
        // Each opportunity uses the 100% baseline roll. Higher activity is represented by
        // additional opportunities rather than a saturated single roll.
        return 0.40D * Math.min(1.0D, chaos / 100.0D);
    }

    public static double ambientActivityStartChance() {
        int chaos = npcChaosPercent();
        if (chaos <= 0) return 0.0D;
        return Math.min(0.90D, 0.20D * Math.max(0.10D, chaos / 100.0D));
    }

    public static int ambientActivityDelay(int normalTicks) {
        int chaos = npcChaosPercent();
        if (chaos <= 0) return Math.max(normalTicks, 2400);
        double scale = Math.max(0.10D, chaos / 100.0D);
        return clamp((int)Math.round(normalTicks / scale), 120, 12000);
    }

    public static Snapshot snapshot() {
        return new Snapshot(activityPreset(), nearbyFighterCap(), nearbyHostileCap(), factionEncounters(),
                dynamicEncounters(), recurringFighters(), LIVING_PRESENCE_TARGET.get(), livingPresenceRadius(), factionResidentCap(),
                automaticPowerSensing(), worldIncidents(), worldEventAlerts(), worldEventAlertRadius(),
                socialTalk(), talkBaseGain(), talkRelationshipCap(), talkCooldownMinSeconds(), talkCooldownMaxSeconds(),
                npcSocializing(), npcChaosPercent(), companionSagaHelp(), npcKiMode(), npcStrengthPercent(), npcGrowthPercent(), attackMinecraftMobs(),
                npcChatFrequencyPercent(), earthGuardianResponsePercent());
    }

    public static void apply(Snapshot value) {
        if (value == null) return;
        int nearby = clamp(value.nearbyFighterCap(), 0, 4096);
        NEARBY_FIGHTER_CAP.set(nearby);
        NEARBY_HOSTILE_CAP.set(clamp(value.nearbyHostileCap(), 0, nearby));
        FACTION_ENCOUNTERS.set(value.factionEncounters());
        DYNAMIC_ENCOUNTERS.set(value.dynamicEncounters());
        RECURRING_FIGHTERS.set(value.recurringFighters());
        LIVING_PRESENCE_TARGET.set(clamp(value.livingPresenceTargetBase(), 0, 128));
        LIVING_PRESENCE_RADIUS.set(clamp(value.livingPresenceRadius(), 96, 8192));
        FACTION_RESIDENT_CAP.set(clamp(value.factionResidentCap(), 4, 512));
        AUTOMATIC_POWER_SENSING.set(value.automaticPowerSensing());
        WORLD_INCIDENTS.set(value.worldIncidents());
        WORLD_EVENT_ALERTS.set(value.worldEventAlerts());
        WORLD_EVENT_ALERT_RADIUS.set(clamp(value.worldEventAlertRadius(), 128, 32768));
        SOCIAL_TALK.set(value.socialTalk());
        TALK_BASE_GAIN.set(clamp(value.talkBaseGain(), 0, 50));
        TALK_RELATIONSHIP_CAP.set(clamp(value.talkRelationshipCap(), 0, 100));
        int min = clamp(value.talkCooldownMinSeconds(), 10, 86400);
        TALK_COOLDOWN_MIN_SECONDS.set(min);
        TALK_COOLDOWN_MAX_SECONDS.set(clamp(value.talkCooldownMaxSeconds(), min, 86400));
        NPC_SOCIALIZING.set(value.npcSocializing());
        NPC_CHAT_FREQUENCY_PERCENT.set(clamp(value.npcChatFrequencyPercent(), 0, 500));
        NPC_CHAOS_PERCENT.set(clamp(value.npcChaosPercent(), 0, 1000));
        NPC_STRENGTH_PERCENT.set(clamp(value.npcStrengthPercent(), 25, 1000));
        NPC_GROWTH_PERCENT.set(clamp(value.npcGrowthPercent(), 0, 1000));
        ATTACK_MINECRAFT_MOBS.set(value.attackMinecraftMobs());
        COMPANION_SAGA_HELP.set(value.companionSagaHelp());
        EARTH_GUARDIAN_RESPONSE_PERCENT.set(clamp(value.earthGuardianResponsePercent(), 0, 500));
        NPC_KI_MODE.set(clamp(value.npcKiMode(), 0, 3));
        // ConfigValue#set updates the loaded Forge config in memory; explicitly save the
        // shared SERVER config after a GUI edit so world settings survive a restart.
        NEARBY_FIGHTER_CAP.save();
    }

    public static Snapshot defaults() {
        return new Snapshot(2, 20, 6, true, true, true, 2, 256, 15,
                true, true, true, 1400, true, 2, 20, 120, 240, true, 100, true, 1, 100, 100, true, 100, 100);
    }

    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }

    public record Snapshot(int activityPreset, int nearbyFighterCap, int nearbyHostileCap,
                           boolean factionEncounters, boolean dynamicEncounters, boolean recurringFighters,
                           int livingPresenceTargetBase, int livingPresenceRadius, int factionResidentCap,
                           boolean automaticPowerSensing, boolean worldIncidents,
                           boolean worldEventAlerts, int worldEventAlertRadius,
                           boolean socialTalk, int talkBaseGain, int talkRelationshipCap,
                           int talkCooldownMinSeconds, int talkCooldownMaxSeconds,
                           boolean npcSocializing, int npcChaosPercent, boolean companionSagaHelp, int npcKiMode,
                           int npcStrengthPercent, int npcGrowthPercent, boolean attackMinecraftMobs,
                           int npcChatFrequencyPercent, int earthGuardianResponsePercent) {}
}
