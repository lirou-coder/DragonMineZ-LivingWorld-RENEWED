package com.dmzlivingworld.world;

import com.dmzlivingworld.LivingWorldMod;
import com.dmzlivingworld.entity.AmbientFighterEntity;
import com.dragonminez.common.init.MainEffects;
import com.dragonminez.common.init.entities.ki.AbstractKiProjectile;
import com.dragonminez.common.stats.StatsCapability;
import com.dragonminez.common.stats.StatsData;
import com.dragonminez.common.stats.StatsProvider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Compatibility boundary between Living World NPC attacks and DMZ player defense.
 *
 * <p>DMZ records raw damage during {@link LivingHurtEvent}, then applies player defense at the
 * final {@code LivingDamageEvent} priority. Its flat-defense threshold can cancel the latter
 * event completely. Trying to revive that final event is order-dependent because DMZ itself also
 * subscribes at the final priority. This bridge instead runs after DMZ's HIGH-priority hurt
 * preparation and, only for valid Living World hits, installs a BP-ratio-derived minimum before
 * final mitigation. Blocking, canceled/parried hits, creative mode and post-spar peace never
 * reach this handler.</p>
 */
@Mod.EventBusSubscriber(modid = LivingWorldMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class NpcPlayerDamageManager {
    private static final String DMZ_RAW = "dmz_raw_damage";
    private static final String DMZ_PENETRATION = "dmz_defense_pen";

    private NpcPlayerDamageManager() {}


    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
    public static void observeNpcAttackGate(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.level().isClientSide) return;
        if (!(event.getSource().getEntity() instanceof AmbientFighterEntity attacker)) return;
        CompoundTag data = player.getPersistentData();
        data.putLong("LWLastNpcAttackGateTick", player.level().getGameTime());
        data.putString("LWLastNpcAttackGateName", attacker.getFighterName());
        data.putDouble("LWLastNpcAttackGateAmount", finiteNonNegative(event.getAmount()));
        data.putBoolean("LWLastNpcAttackGateCanceled", event.isCanceled());
        data.putBoolean("LWLastNpcAttackGateStunned", attacker.hasEffect(MainEffects.STUN.get()));
        data.putBoolean("LWLastNpcAttackGatePostSpar", attacker.isPostSparOpponent(player));
        data.putInt("LWLastNpcAttackGateInvuln", Math.max(0, player.invulnerableTime));
    }

    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = false)
    public static void prepareValidNpcHit(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.level().isClientSide) return;
        Entity direct = event.getSource().getDirectEntity();
        AmbientFighterEntity attacker = responsibleFighter(event.getSource().getEntity(), direct);
        if (attacker == null || player.isCreative() || player.isSpectator()
                || attacker.isPostSparOpponent(player)) return;

        StatsData stats = StatsProvider.get(StatsCapability.INSTANCE, player).orElse(null);
        if (stats == null || !stats.getStatus().isHasCreatedCharacter() || stats.getStatus().isBlocking()) return;

        boolean kiAttack = direct instanceof AbstractKiProjectile;
        boolean directMelee = !kiAttack && event.getSource().getEntity() == attacker;
        CompoundTag data = player.getPersistentData();
        double incoming = finiteNonNegative(event.getAmount());
        double attackAttribute = finiteNonNegative(attacker.getAttributeValue(Attributes.ATTACK_DAMAGE));
        double raw = data.contains(DMZ_RAW) ? finiteNonNegative(data.getDouble(DMZ_RAW)) : incoming;
        // R11's repair could never run when another combat layer had already reduced the hurt-stage
        // amount/raw tag to zero. Native DMZ NPC melee is backed by ATTACK_DAMAGE, so use that real
        // combat attribute as the pre-mitigation source only for a direct fighter melee hit.
        if (raw <= 0.0D && directMelee) raw = attackAttribute;

        double penetration = data.contains(DMZ_PENETRATION) ? data.getDouble(DMZ_PENETRATION) : 0.0D;
        if (!Double.isFinite(penetration)) penetration = 0.0D;
        penetration = Math.max(0.0D, Math.min(1.0D, penetration));

        boolean guardBroken = stats.getStatus().isStunEffect()
                && stats.getResources().getCurrentPoise() <= 0.0F;
        double ordinaryResult = raw > 0.0D
                ? stats.calculatePostMitigationDamage(raw, guardBroken, penetration) : 0.0D;
        double minimum = minimumDamageForPower(attacker, player, stats, kiAttack);
        boolean needsRepair = !Double.isFinite(ordinaryResult) || ordinaryResult < minimum;

        if (directMelee) rememberMeleeDiagnostic(player, attacker, incoming, attackAttribute, raw,
                ordinaryResult, minimum, needsRepair, false);
        if (!needsRepair) return;

        // DMZ reads these exact tags later at LOWEST LivingDamage priority. Full penetration is
        // deliberately limited to the BP-derived minimum; a naturally stronger ordinary result
        // remains untouched above. Active blocking and any earlier cancellation never enter here.
        data.putDouble(DMZ_RAW, minimum);
        data.putDouble(DMZ_PENETRATION, 1.0D);

        if (directMelee) {
            // Critical R12 repair: keep the legitimate, non-cancelled melee hurt pipeline alive.
            // A zero hurt-stage amount can prevent LivingDamageEvent (where DMZ consumes DMZ_RAW)
            // from ever becoming useful. This positive carrier is NOT final damage; DMZ still owns
            // the final defense/block/ki-protection calculation from the tags above.
            float carrier = (float)Math.max(0.5D, Math.min(Float.MAX_VALUE, minimum));
            if (!Float.isFinite(event.getAmount()) || event.getAmount() < carrier) event.setAmount(carrier);
            rememberMeleeDiagnostic(player, attacker, incoming, attackAttribute, raw, ordinaryResult,
                    minimum, true, true);
        }
    }

    private static double finiteNonNegative(double value) {
        return Double.isFinite(value) ? Math.max(0.0D, value) : 0.0D;
    }

    private static void rememberMeleeDiagnostic(ServerPlayer player, AmbientFighterEntity attacker,
                                                double incoming, double attackAttribute, double raw,
                                                double ordinaryResult, double minimum, boolean repaired,
                                                boolean carrierRevived) {
        CompoundTag data = player.getPersistentData();
        data.putLong("LWLastNpcMeleeTick", player.level().getGameTime());
        data.putString("LWLastNpcMeleeName", attacker.getFighterName());
        data.putDouble("LWLastNpcMeleeIncoming", incoming);
        data.putDouble("LWLastNpcMeleeAttackAttribute", attackAttribute);
        data.putDouble("LWLastNpcMeleeRaw", raw);
        data.putDouble("LWLastNpcMeleeOrdinary", finiteNonNegative(ordinaryResult));
        data.putDouble("LWLastNpcMeleeMinimum", finiteNonNegative(minimum));
        data.putBoolean("LWLastNpcMeleeRepaired", repaired);
        data.putBoolean("LWLastNpcMeleeCarrierRevived", carrierRevived);
    }

    public static String debugStatus(ServerPlayer player, AmbientFighterEntity fighter) {
        StatsData stats = StatsProvider.get(StatsCapability.INSTANCE, player).orElse(null);
        if (stats == null || fighter == null) return "No DMZ player stats or Living World fighter available.";
        double floor = minimumDamageForPower(fighter, player, stats, false);
        CompoundTag data = player.getPersistentData();
        long age = data.contains("LWLastNpcMeleeTick")
                ? Math.max(0L, player.level().getGameTime() - data.getLong("LWLastNpcMeleeTick")) : -1L;
        String last = data.getString("LWLastNpcMeleeName");
        String lastText = age < 0 ? "no LivingHurt melee observed yet"
                : String.format(java.util.Locale.ROOT,
                "last %s %dt ago: hurt %.2f / attr %.2f / raw %.2f / ordinary %.2f / floor %.2f / repaired %s / carrier %s",
                last.isBlank() ? "fighter" : last, age, data.getDouble("LWLastNpcMeleeIncoming"),
                data.getDouble("LWLastNpcMeleeAttackAttribute"), data.getDouble("LWLastNpcMeleeRaw"),
                data.getDouble("LWLastNpcMeleeOrdinary"), data.getDouble("LWLastNpcMeleeMinimum"),
                data.getBoolean("LWLastNpcMeleeRepaired"), data.getBoolean("LWLastNpcMeleeCarrierRevived"));
        long gateAge = data.contains("LWLastNpcAttackGateTick")
                ? Math.max(0L, player.level().getGameTime() - data.getLong("LWLastNpcAttackGateTick")) : -1L;
        String gate = gateAge < 0 ? "no LivingAttack gate observed"
                : String.format(java.util.Locale.ROOT,
                "attack gate %dt ago: canceled %s / stunned %s / post-spar %s / prior invuln %d / amount %.2f",
                gateAge, data.getBoolean("LWLastNpcAttackGateCanceled"), data.getBoolean("LWLastNpcAttackGateStunned"),
                data.getBoolean("LWLastNpcAttackGatePostSpar"), data.getInt("LWLastNpcAttackGateInvuln"),
                data.getDouble("LWLastNpcAttackGateAmount"));
        String peace = fighter.isPostSparOpponent(player)
                ? String.format(java.util.Locale.ROOT, "post-spar peace ACTIVE %dt (%.1fs)",
                fighter.getPostSparPeaceTicks(), fighter.getPostSparPeaceTicks() / 20.0D)
                : "post-spar peace inactive";
        return String.format(java.util.Locale.ROOT,
                "%s • BP %d • ATTACK_DAMAGE %.2f • current BP-relative melee floor %.2f • %s • %s • %s",
                fighter.getFighterName(), fighter.getBattlePower(),
                fighter.getAttributeValue(Attributes.ATTACK_DAMAGE), floor, lastText, gate, peace);
    }

    static double minimumDamageForPower(AmbientFighterEntity attacker, ServerPlayer player,
                                        StatsData playerStats, boolean kiAttack) {
        double playerPower = playerStats.getBattlePowerExact();
        if (!Double.isFinite(playerPower) || playerPower <= 0.0D) playerPower = 1.0D;
        double ratio = Math.max(0.01D, Math.min(16.0D, attacker.getBattlePower() / playerPower));
        double style = kiAttack
                ? switch (attacker.getArchetype()) {
                    case KI_SPECIALIST -> 1.18D;
                    case MARTIAL_ARTIST -> 1.02D;
                    case SPEEDSTER -> 0.92D;
                    case GUARDIAN -> 0.86D;
                    case BRAWLER -> 0.78D;
                }
                : switch (attacker.getArchetype()) {
                    case BRAWLER -> 1.15D;
                    case MARTIAL_ARTIST -> 1.05D;
                    case SPEEDSTER -> 0.94D;
                    case GUARDIAN -> 0.88D;
                    case KI_SPECIALIST -> 0.80D;
                };
        double fraction = Math.max(0.005D, Math.min(0.22D,
                0.05D * Math.sqrt(ratio) * style));
        return Math.max(0.5D, player.getMaxHealth() * fraction);
    }

    private static AmbientFighterEntity responsibleFighter(Entity causing, Entity direct) {
        if (causing instanceof AmbientFighterEntity fighter) return fighter;
        if (direct instanceof AbstractKiProjectile projectile
                && projectile.getOwner() instanceof AmbientFighterEntity fighter) return fighter;
        return null;
    }

}
