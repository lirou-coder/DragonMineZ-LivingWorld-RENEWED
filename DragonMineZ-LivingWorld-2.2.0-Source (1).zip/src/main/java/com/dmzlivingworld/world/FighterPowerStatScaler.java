package com.dmzlivingworld.world;

import com.dmzlivingworld.entity.AmbientFighterEntity;

/**
 * Converts earned/current BP into the physical values used by Minecraft/DMZ combat.
 *
 * <p>DMZ battle power is approximately {@code 1200 * (effective / 100)^1.2}.  The old
 * scaler compared BP to a rank midpoint and clamped every ratio below one.  Consequently,
 * a 250 BP rookie and an 825 BP rookie had identical real stats, while later BP mutations
 * could leave those stats stale altogether.  Inverting DMZ's curve gives every BP value a
 * single, monotonic physical profile and keeps displayed power aligned with actual output.</p>
 */
public final class FighterPowerStatScaler {
    private FighterPowerStatScaler() {}

    static double effectiveStatBudget(int battlePower) {
        double normalized = Math.max(1.0D, battlePower) / 1200.0D;
        return 100.0D * Math.pow(normalized, 1.0D / 1.2D);
    }

    public static double baseHealth(AmbientFighterEntity fighter, double livedMultiplier) {
        double effective = effectiveStatBudget(fighter.getBattlePower());
        double lived = Math.min(1.22D, 1.0D + (Math.max(1.0D, livedMultiplier) - 1.0D) * 0.55D);
        // 825/3300/8850 BP land close to the historical 115/240/460 HP profiles, but
        // unlike the old rank floor the values below and between those anchors still vary.
        // R5 accidentally replaced the original bounded late-game headroom with a flat 1,024
        // ceiling. Keep the new monotonic curve intact below that point, then retain the
        // original rank-specific 40x safety ceiling so Android/Super BP is still physical.
        double originalSafetyCeiling = fighter.getRank().maxHealth() * 40.0D;
        return Math.max(20.0D, Math.min(originalSafetyCeiling, (48.0D + effective * 0.82D) * lived));
    }

    public static double baseAttack(AmbientFighterEntity fighter, double livedMultiplier) {
        double effective = effectiveStatBudget(fighter.getBattlePower());
        // BP represents DMZ's aggregate active stat budget, not one individual stat. Allocate a
        // real melee share by archetype just as a player build would distribute that budget.
        double strengthShare = switch (fighter.getArchetype()) {
            case BRAWLER -> 0.27D;
            case MARTIAL_ARTIST -> 0.24D;
            case SPEEDSTER -> 0.22D;
            case GUARDIAN -> 0.19D;
            case KI_SPECIALIST -> 0.17D;
        };
        return Math.max(2.0D, Math.min(2048.0D,
                (1.0D + effective * strengthShare) * Math.max(1.0D, livedMultiplier)));
    }

    public static float baseKi(AmbientFighterEntity fighter, float historicalKi) {
        double effective = effectiveStatBudget(fighter.getBattlePower());
        double rankBaseline = switch (fighter.getRank()) {
            case ROOKIE -> 5.5D;
            case TRAINED -> 9.2D;
            case VETERAN -> 15.5D;
        };
        // Preserve the archetype's historical Ki bias (notably Ki Specialists) without
        // allowing rank to become a second, contradictory source of physical strength.
        double archetypeBias = Math.max(0.75D, Math.min(1.35D, historicalKi / rankBaseline));
        return (float)Math.max(1.0D, Math.min(2500.0D, (2.0D + effective * 0.16D) * archetypeBias));
    }
}
