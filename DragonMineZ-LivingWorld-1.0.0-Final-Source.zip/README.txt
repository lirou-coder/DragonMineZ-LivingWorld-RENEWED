DragonMine Z: Living World 1.0.0
=================================

Living World makes Dragon Mine Z's world feel inhabited by persistent fighters rather than disposable encounters.

Fighters can remember you and each other, form friendships and rivalries, join factions, train and grow, learn real Dragon Mine Z techniques, own and inherit real DMZ equipment, pursue individual goals, fight in dynamic encounters, and build a history that remains attached to that character over time.

Highlights
----------
- Persistent fighters with names, appearances, personalities, race, combat style and progression.
- Relationships, companions, mentors and rivalries that survive across encounters.
- Factions with leaders, ranks, patrols, conflicts, territory activity and Guardian Corps intervention.
- Individual goals grounded in real gameplay: training, techniques, equipment, flight, racial progression, victories and rival fights.
- Real Dragon Mine Z equipment ownership, including DMZ swords, armor, scouters, Power Pole and ranged equipment where appropriate.
- Equipment can be gifted, recovered from the battlefield and inherited by meaningful successors.
- Real Dragon Mine Z techniques can be learned from other fighters and passed down through multiple generations.
- Battle records and important events follow persistent fighters over time.
- Important deaths remain recorded instead of silently recreating the same fighter later.
- Native DMZ combat, movement, transformations, Ki attacks, flight and rendering remain the foundation.
- Optional compatibility with Dragon Mine Z Meditation and Living World Fusion Bridge.

Natural interaction
-------------------
- Shift + right-click a Living World fighter with an empty hand: open their Fighter Profile.
- If that fighter has a pending companion/bond interaction, that action takes priority.
- Shift + right-click while holding a real DMZ scouter: open the profile with additional tactical information.
- Shift + right-click while holding supported equipment: offer the item to an eligible fighter.
- Normal right-click is left to Minecraft and Dragon Mine Z.

Commands
--------
Normal play does not require commands. /lw commands are operator-only development/admin tools.
Public-facing debug groups use straightforward names such as:
  /lw equipment ...
  /lw history ...
  /lw rivalry ...

Requirements
------------
- Minecraft 1.20.1
- Forge 47.4.x
- DragonMineZ 2.1.3
- GeckoLib 4.8.4+

Optional integrations
---------------------
- Dragon Mine Z Meditation 4.4.0 RC7+
- Living World Fusion Bridge

Important save note
-------------------
Living World can be added to an existing Dragon Mine Z world. Version 1.0.0 preserves the persistent data used by the 0.9.x development builds so existing fighters, equipment, relationships, techniques, goals and history can carry forward.

Living World owns its Ambient Fighter entity type. Removing the entire mod is therefore not equivalent to removing a stat-only addon. Back up long-term worlds before uninstalling a content mod.


LICENSE
=======
DragonMine Z: Living World is licensed under the GNU General Public License v3.0 only (GPL-3.0-only). See LICENSE.txt.
The release source archive is generated alongside the public JAR.


WORLD SETTINGS
==============
Open Living World with L, then choose Settings. World hosts/server operators can tune exact natural-activity steps, nearby fighter population, hostile cap, faction encounters, dynamic encounters, recurring fighters and automatic power sensing. Settings are stored per world in serverconfig/dmzlivingworld-server.toml. Defaults preserve the intended Living World experience. High population caps retain full fighter simulation and may require more CPU.
