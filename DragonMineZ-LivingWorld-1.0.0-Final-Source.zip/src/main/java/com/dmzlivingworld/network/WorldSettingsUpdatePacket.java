package com.dmzlivingworld.network;

import com.dmzlivingworld.config.LivingWorldConfig;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** C2S update request. The server validates edit permission and persists the per-world config. */
public record WorldSettingsUpdatePacket(int activityPreset, int nearbyFighterCap, int nearbyHostileCap,
                                        boolean factionEncounters, boolean dynamicEncounters,
                                        boolean recurringFighters, boolean automaticPowerSensing) {
    public LivingWorldConfig.Snapshot snapshot() {
        return new LivingWorldConfig.Snapshot(activityPreset, nearbyFighterCap, nearbyHostileCap,
                factionEncounters, dynamicEncounters, recurringFighters, automaticPowerSensing);
    }

    public static void encode(WorldSettingsUpdatePacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.activityPreset);
        buf.writeVarInt(msg.nearbyFighterCap);
        buf.writeVarInt(msg.nearbyHostileCap);
        buf.writeBoolean(msg.factionEncounters);
        buf.writeBoolean(msg.dynamicEncounters);
        buf.writeBoolean(msg.recurringFighters);
        buf.writeBoolean(msg.automaticPowerSensing);
    }

    public static WorldSettingsUpdatePacket decode(FriendlyByteBuf buf) {
        return new WorldSettingsUpdatePacket(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
                buf.readBoolean(), buf.readBoolean(), buf.readBoolean(), buf.readBoolean());
    }

    public static void handle(WorldSettingsUpdatePacket msg, Supplier<NetworkEvent.Context> context) {
        NetworkEvent.Context ctx = context.get();
        ServerPlayer sender = ctx.getSender();
        if (sender != null) {
            ctx.enqueueWork(() -> {
                if (!canEdit(sender)) return;
                LivingWorldConfig.apply(msg.snapshot());
                LWNetwork.sendWorldSettings(sender, true);
            });
        }
        ctx.setPacketHandled(true);
    }

    public static boolean canEdit(ServerPlayer player) {
        if (player == null || player.getServer() == null) return false;
        return player.createCommandSourceStack().hasPermission(2) || player.getServer().isSingleplayerOwner(player.getGameProfile());
    }
}
