package com.dmzlivingworld.network;

import com.dmzlivingworld.client.screen.WorldSettingsScreen;
import com.dmzlivingworld.config.LivingWorldConfig;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server-authoritative snapshot used to populate the player-facing World Settings screen. */
public record WorldSettingsPacket(int activityPreset, int nearbyFighterCap, int nearbyHostileCap,
                                  boolean factionEncounters, boolean dynamicEncounters,
                                  boolean recurringFighters, boolean automaticPowerSensing,
                                  boolean canEdit) {
    public static WorldSettingsPacket from(LivingWorldConfig.Snapshot value, boolean canEdit) {
        return new WorldSettingsPacket(value.activityPreset(), value.nearbyFighterCap(), value.nearbyHostileCap(),
                value.factionEncounters(), value.dynamicEncounters(), value.recurringFighters(),
                value.automaticPowerSensing(), canEdit);
    }

    public LivingWorldConfig.Snapshot snapshot() {
        return new LivingWorldConfig.Snapshot(activityPreset, nearbyFighterCap, nearbyHostileCap,
                factionEncounters, dynamicEncounters, recurringFighters, automaticPowerSensing);
    }

    public static void encode(WorldSettingsPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.activityPreset);
        buf.writeVarInt(msg.nearbyFighterCap);
        buf.writeVarInt(msg.nearbyHostileCap);
        buf.writeBoolean(msg.factionEncounters);
        buf.writeBoolean(msg.dynamicEncounters);
        buf.writeBoolean(msg.recurringFighters);
        buf.writeBoolean(msg.automaticPowerSensing);
        buf.writeBoolean(msg.canEdit);
    }

    public static WorldSettingsPacket decode(FriendlyByteBuf buf) {
        return new WorldSettingsPacket(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(),
                buf.readBoolean(), buf.readBoolean(), buf.readBoolean(), buf.readBoolean(), buf.readBoolean());
    }

    public static void handle(WorldSettingsPacket msg, Supplier<NetworkEvent.Context> context) {
        NetworkEvent.Context ctx = context.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> WorldSettingsScreen.open(msg)));
        ctx.setPacketHandled(true);
    }
}
