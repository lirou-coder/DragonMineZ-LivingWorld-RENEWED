package com.dmzlivingworld.network;

import com.dmzlivingworld.client.screen.FactionDossierScreen;
import com.dmzlivingworld.client.screen.LivingWorldGuideScreen;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Read-only world/faction snapshot. No client data is trusted by the simulation. */
public record FactionDossierPacket(String page, int slot, String title, String subtitle, List<String> lines) {
    public FactionDossierPacket {
        page = page == null ? "world" : page;
        slot = Math.max(0, slot);
        title = title == null ? "Living World" : title;
        subtitle = subtitle == null ? "" : subtitle;
        lines = lines == null ? List.of() : List.copyOf(lines);
    }

    /** Compatibility constructor for existing debug/profile callers. */
    public FactionDossierPacket(String title, String subtitle, List<String> lines) {
        this("world", 0, title, subtitle, lines);
    }

    public static void encode(FactionDossierPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.page, 32);
        buf.writeVarInt(msg.slot);
        buf.writeUtf(msg.title, 256);
        buf.writeUtf(msg.subtitle, 512);
        int size = Math.min(180, msg.lines.size());
        buf.writeVarInt(size);
        for (int i = 0; i < size; i++) buf.writeUtf(msg.lines.get(i), 1024);
    }

    public static FactionDossierPacket decode(FriendlyByteBuf buf) {
        String page = buf.readUtf(32);
        int slot = buf.readVarInt();
        String title = buf.readUtf(256);
        String subtitle = buf.readUtf(512);
        int size = Math.min(180, Math.max(0, buf.readVarInt()));
        List<String> lines = new ArrayList<>(size);
        for (int i = 0; i < size; i++) lines.add(buf.readUtf(1024));
        return new FactionDossierPacket(page, slot, title, subtitle, lines);
    }

    public static void handle(FactionDossierPacket msg, Supplier<NetworkEvent.Context> context) {
        NetworkEvent.Context ctx = context.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> {
                    if ("guide".equals(msg.page())) LivingWorldGuideScreen.open();
                    else FactionDossierScreen.open(msg);
                }));
        ctx.setPacketHandled(true);
    }
}
