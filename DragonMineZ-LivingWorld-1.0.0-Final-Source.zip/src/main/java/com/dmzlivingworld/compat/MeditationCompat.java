package com.dmzlivingworld.compat;

import com.dmzlivingworld.LivingWorldMod;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;
import com.dmzlivingworld.entity.AmbientFighterEntity;
import net.minecraftforge.fml.ModList;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

import java.lang.reflect.Method;

/**
 * Optional bridge to DragonMine Z Meditation (MediMod).
 *
 * MediMod's actual meditation session belongs to ServerPlayer. Living World never
 * fakes an NPC as a player capability holder; NPCs instead participate through
 * Living World's own meditation state while nearby real players receive the
 * shared training benefits through MediMod's public DMZTrainingBridge.
 */
public final class MeditationCompat {
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final String MOD_ID = "dbzmeditation";
    private static boolean resolved;
    private static boolean available;
    private static boolean failedLogged;
    private static Method startMeditation;
    private static Method recoverResources;
    private static Method gainActiveFormMastery;
    private static Method getMeditationTpUnit;
    private static Method awardMeditationTp;

    private MeditationCompat() {}

    public static boolean isAvailable() {
        if (!ModList.get().isLoaded(MOD_ID)) return false;
        resolve();
        return available;
    }

    /** MediMod 4.4 stores its authoritative active flag in player persistent data. */
    public static boolean isPlayerMeditating(ServerPlayer player) {
        return player != null && isAvailable() && player.getPersistentData().getBoolean("dbzm_active");
    }

    /** Starts MediMod's real player meditation session, including its seat/visual/session state. */
    public static boolean startPlayerMeditation(ServerPlayer player) {
        if (player == null || !isAvailable()) return false;
        if (isPlayerMeditating(player)) return true;
        try {
            startMeditation.invoke(null, player);
            return isPlayerMeditating(player);
        } catch (Throwable error) {
            logFailure("could not start MediMod meditation", error);
            return false;
        }
    }

    /**
     * Adds a deliberately conservative NPC harmony bonus on top of MediMod's own
     * meditation. This never replaces MediMod's normal rewards.
     */
    public static void applyNpcHarmony(ServerPlayer player, int partners, long meditationTicks) {
        if (player == null || partners <= 0 || !isPlayerMeditating(player) || !isAvailable()) return;
        int capped = Math.min(3, partners);
        try {
            // Public MediMod bridge: a tiny extra recovery pulse each second.
            recoverResources.invoke(null, player, 0.0015D * capped);

            // Form mastery is intentionally tiny and only once every 20 seconds.
            if (meditationTicks > 0 && meditationTicks % 400L == 0L) {
                gainActiveFormMastery.invoke(null, player, 0.0025D * capped);
            }

            // One modest native MediMod TP pulse per full minute of shared stillness.
            if (meditationTicks > 0 && meditationTicks % 1200L == 0L && awardMeditationTp != null) {
                Object unit = getMeditationTpUnit.invoke(null, player);
                int base = unit instanceof Number n ? n.intValue() : 1;
                int award = Math.max(1, Math.min(12, Math.round(base * 0.35F * capped)));
                awardMeditationTp.invoke(null, player, award);
            }

            // A subtle shared-energy cue between real MediMod meditation and nearby LW partners.
            // This uses MediMod's own particle registry and stays intentionally sparse.
            if (meditationTicks > 0 && meditationTicks % 100L == 0L) {
                SimpleParticleType absorb = particle("ki_absorb");
                SimpleParticleType mote = particle("ki_mote");
                ServerLevel level = player.serverLevel();
                if (absorb != null) level.sendParticles(absorb, player.getX(), player.getY() + 0.9D, player.getZ(),
                        capped, 0.42D, 0.34D, 0.42D, 0.012D);
                if (mote != null) level.sendParticles(mote, player.getX(), player.getY() + 0.55D, player.getZ(),
                        Math.min(4, 1 + capped), 0.48D, 0.28D, 0.48D, 0.008D);
            }
        } catch (Throwable error) {
            logFailure("could not apply shared NPC meditation rewards", error);
        }
    }


    /**
     * Uses MediMod's own registered particle types around a Living World NPC. This is
     * visual interoperability only; the NPC never impersonates MediMod's ServerPlayer state.
     */
    public static void spawnNpcMeditationStartVisual(AmbientFighterEntity fighter) {
        if (fighter == null || !(fighter.level() instanceof ServerLevel level) || !isAvailable()) return;
        SimpleParticleType burst = particle("ki_burst");
        SimpleParticleType mote = particle("ki_mote");
        double x = fighter.getX(), y = fighter.getY(), z = fighter.getZ();
        if (burst != null) level.sendParticles(burst, x, y + fighter.getBbHeight() * 0.48D, z,
                5, 0.24D, 0.18D, 0.24D, 0.012D);
        if (mote != null) level.sendParticles(mote, x, y + 0.34D, z,
                10, 0.50D, 0.12D, 0.50D, 0.006D);
    }

    public static void spawnNpcMeditationVisual(AmbientFighterEntity fighter, boolean harmony) {
        if (fighter == null || !(fighter.level() instanceof ServerLevel level) || !isAvailable()) return;
        SimpleParticleType mote = particle("ki_mote");
        SimpleParticleType glyph = particle("meditation_glyph");
        SimpleParticleType absorb = particle("ki_absorb");
        SimpleParticleType rune = particle("ground_rune");
        double x = fighter.getX(), y = fighter.getY(), z = fighter.getZ();
        if (mote != null) level.sendParticles(mote, x, y + fighter.getBbHeight() * 0.55D, z,
                harmony ? 3 : 2, 0.34D, 0.42D, 0.34D, 0.012D);
        if (fighter.tickCount % 72 < 20 && rune != null)
            level.sendParticles(rune, x, y + 0.04D, z, 1, 0.02D, 0.01D, 0.02D, 0.0D);
        if (fighter.tickCount % 108 < 20 && glyph != null)
            level.sendParticles(glyph, x, y + fighter.getBbHeight() * 0.72D, z, 1, 0.10D, 0.12D, 0.10D, 0.0D);
        if (harmony && absorb != null)
            level.sendParticles(absorb, x, y + fighter.getBbHeight() * 0.62D, z, 2, 0.46D, 0.36D, 0.46D, 0.018D);
    }

    private static SimpleParticleType particle(String name) {
        var type = ForgeRegistries.PARTICLE_TYPES.getValue(new ResourceLocation(MOD_ID, name));
        return type instanceof SimpleParticleType simple ? simple : null;
    }
    private static synchronized void resolve() {
        if (resolved) return;
        resolved = true;
        try {
            Class<?> meditation = Class.forName("com.kunyo.dbzmeditation.DBZMeditation");
            Class<?> bridge = Class.forName("com.kunyo.dbzmeditation.DMZTrainingBridge");

            startMeditation = meditation.getDeclaredMethod("startMeditation", ServerPlayer.class);
            startMeditation.setAccessible(true);
            recoverResources = bridge.getMethod("recoverResources", ServerPlayer.class, double.class);
            gainActiveFormMastery = bridge.getMethod("gainActiveFormMastery", ServerPlayer.class, double.class);
            getMeditationTpUnit = bridge.getMethod("getMeditationTpUnit", ServerPlayer.class);
            try {
                awardMeditationTp = meditation.getDeclaredMethod("awardMeditationTp", ServerPlayer.class, int.class);
                awardMeditationTp.setAccessible(true);
            } catch (ReflectiveOperationException ignored) {
                // Recovery/mastery compatibility remains useful even if a future MediMod hides this differently.
                awardMeditationTp = null;
            }
            available = true;
            LOGGER.info("[{}] DragonMine Z Meditation compatibility enabled.", LivingWorldMod.MOD_ID);
        } catch (Throwable error) {
            available = false;
            logFailure("MediMod was present but its compatibility API could not be resolved", error);
        }
    }

    private static void logFailure(String message, Throwable error) {
        if (failedLogged) return;
        failedLogged = true;
        LOGGER.warn("[{}] {}. Living World will continue without meditation compatibility.",
                LivingWorldMod.MOD_ID, message, error);
    }
}
