package com.dmzlivingworld.client;

import com.dmzlivingworld.entity.AmbientFighterEntity;
import com.dmzlivingworld.entity.FighterRace;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.model.data.EntityModelData;

/** Uses DragonMineZ's own race geometry with its native saga animation library. */
public final class FighterModel extends GeoModel<AmbientFighterEntity> {
    private static final ResourceLocation HUMAN = dmz("geo/entity/races/human.geo.json");
    private static final ResourceLocation HUMAN_SLIM = dmz("geo/entity/races/human_slim.geo.json");
    // DragonMineZ's actual female/buffed Human-Saiyan geometry contains the native
    // "boobas" chest bone. human_slim.geo.json is only a slim-arm model and does
    // not contain the female chest geometry, which made LW women read as slim men.
    private static final ResourceLocation HUMAN_FEMALE = dmz("geo/entity/races/hbuffed_fem.geo.json");
    private static final ResourceLocation NAMEKIAN = dmz("geo/entity/enemies/namekian.geo.json");
    private static final ResourceLocation FROST = dmz("geo/entity/races/frostdemon.geo.json");
    private static final ResourceLocation MAJIN = dmz("geo/entity/races/majin.geo.json");
    private static final ResourceLocation MAJIN_SLIM = dmz("geo/entity/races/majin_slim.geo.json");
    private static final ResourceLocation BIO = dmz("geo/entity/races/bioandroid.geo.json");
    private static final ResourceLocation BUFFED = dmz("geo/entity/races/hbuffed.geo.json");
    private static final ResourceLocation BUFFED_FEMALE = dmz("geo/entity/races/hbuffed_fem.geo.json");
    private static final ResourceLocation FROST_SECOND = dmz("geo/entity/races/frostdemon_second.geo.json");
    private static final ResourceLocation FROST_THIRD = dmz("geo/entity/races/frostdemon_third.geo.json");
    private static final ResourceLocation FROST_FP = dmz("geo/entity/races/frostdemon_fp.geo.json");
    private static final ResourceLocation FROST_FIFTH = dmz("geo/entity/races/frostdemon_fifth.geo.json");
    private static final ResourceLocation BIO_SEMI = dmz("geo/entity/races/bioandroid_semi.geo.json");
    private static final ResourceLocation BIO_PERFECT = dmz("geo/entity/races/bioandroid_perfect.geo.json");
    private static final ResourceLocation BIO_ULTRA = dmz("geo/entity/races/bioandroid_ultra.geo.json");
    private static final ResourceLocation BLANK = dmz("textures/armor/blank.png");
    private static final ResourceLocation SAGA_ANIMATIONS = dmz("animations/entity/sagas/saga_base.animation.json");

    private static final String[] ARMOR_LAYER_BONES = {
            "hat_layer", "armorHead", "armorBody", "armorLeggingsBody", "body_layer",
            "armorRightArm", "right_arm_layer", "armorLeftArm", "left_arm_layer",
            "armorRightLeg", "armorRightBoot", "right_leg_layer",
            "armorLeftLeg", "armorLeftBoot", "left_leg_layer"
    };
    private static final String[] TAIL_BONES = {
            "tail1", "tail2", "tail3", "tail4", "tail5", "tail6", "tail7", "tail8", "tail9",
            "tail1m", "tail2m", "tail3m", "tail4m", "tail5m", "tail6m", "tail7m", "tail8m", "tail9m"
    };

    @Override
    public ResourceLocation getModelResource(AmbientFighterEntity entity) {
        var form = entity.getActiveRacialForm();
        if (form != null) {
            String model = form.modelKey();
            if ("buffed".equals(model)) return entity.isFemale() ? BUFFED_FEMALE : BUFFED;
            if ("frostdemon_second".equals(model)) return FROST_SECOND;
            if ("frostdemon_third".equals(model)) return FROST_THIRD;
            if ("frostdemon_fp".equals(model)) return FROST_FP;
            if ("frostdemon_fifth".equals(model)) return FROST_FIFTH;
            if ("bioandroid_semi".equals(model)) return BIO_SEMI;
            if ("bioandroid_perfect".equals(model)) return BIO_PERFECT;
            if ("bioandroid_ultra".equals(model)) return BIO_ULTRA;
            // DMZ resolves several player-only aliases (SSJ4/Namek/Majin) through its
            // player form renderer. Living World keeps native base geometry rather than
            // inventing a replacement model for those aliases.
        }
        return switch (entity.getRace()) {
            case HUMAN, SAIYAN -> entity.isFemale() ? HUMAN_FEMALE : HUMAN;
            case NAMEKIAN -> NAMEKIAN;
            case MAJIN -> entity.isFemale() ? MAJIN_SLIM : MAJIN;
            case FROST_DEMON -> FROST;
            case BIO_ANDROID -> BIO;
        };
    }

    @Override
    public ResourceLocation getTextureResource(AmbientFighterEntity entity) {
        return BLANK;
    }

    @Override
    public ResourceLocation getAnimationResource(AmbientFighterEntity entity) {
        return SAGA_ANIMATIONS;
    }

    @Override
    public void setCustomAnimations(AmbientFighterEntity entity, long instanceId,
                                    AnimationState<AmbientFighterEntity> state) {
        super.setCustomAnimations(entity, instanceId, state);

        boolean hasArmor = !entity.getItemBySlot(EquipmentSlot.HEAD).isEmpty()
                || !entity.getItemBySlot(EquipmentSlot.CHEST).isEmpty()
                || !entity.getItemBySlot(EquipmentSlot.LEGS).isEmpty()
                || !entity.getItemBySlot(EquipmentSlot.FEET).isEmpty();
        for (String boneName : ARMOR_LAYER_BONES) setHiddenIfPresent(boneName, !hasArmor);

        // Living World no longer synthesizes a Saiyan tail from the body model.
        // DMZ's actual Saiyan tail is a separate race-parts render (tailenrolled +
        // character/status state), so procedural Saiyans stay tailless until that
        // exact native pipeline can be reused safely. Frost/Bio retain their race geometry.
        boolean hideTail = entity.getRace() == FighterRace.HUMAN
                || entity.getRace() == FighterRace.SAIYAN
                || entity.getRace() == FighterRace.MAJIN
                || entity.getRace() == FighterRace.NAMEKIAN;
        for (String boneName : TAIL_BONES) setHiddenIfPresent(boneName, hideTail);

        if (entity.isMeditating()) applyMeditationPose(entity);

        EntityModelData modelData = state.getData(DataTickets.ENTITY_MODEL_DATA);
        if (modelData != null) {
            var head = this.getAnimationProcessor().getBone("head");
            if (head != null) {
                head.setRotX(modelData.headPitch() * ((float)Math.PI / 180F));
                head.setRotY(modelData.netHeadYaw() * ((float)Math.PI / 180F));
            }
        }
    }


    /** Exact pose values from DMZ 2.1.3's base.meditation animation, converted the same way GeckoLib converts Bedrock rotation channels. */
    private void applyMeditationPose(AmbientFighterEntity entity) {
        // base.meditation uses sin/cos(query.anim_time * 90). Molang trig is degree based,
        // so this is the same four-second cycle driven by entity time rather than wall-clock time.
        float t = entity.tickCount / 20.0F;
        float cycle = (float)Math.cos(t * Math.PI * 0.5D);
        var root = this.getAnimationProcessor().getBone("root");
        if (root != null) root.setPosY((float)Math.sin(t * Math.PI * 0.5D) * 0.7F - 0.4F);
        var waist = this.getAnimationProcessor().getBone("waist");
        if (waist != null) waist.setRotX(rad(-5.0F));
        var rightArm = this.getAnimationProcessor().getBone("right_arm");
        if (rightArm != null) { rightArm.setRotX(rad(40.76924F)); rightArm.setRotY(rad(29.98661F)); rightArm.setRotZ(rad(-23.4933F - 0.8F * cycle)); }
        var leftArm = this.getAnimationProcessor().getBone("left_arm");
        if (leftArm != null) { leftArm.setRotX(rad(33.64517F)); leftArm.setRotY(rad(-35.69025F)); leftArm.setRotZ(rad(23.28706F + 0.8F * cycle)); }
        var rightLeg = this.getAnimationProcessor().getBone("right_leg");
        if (rightLeg != null) {
            rightLeg.setRotX(rad(60.63603F)); rightLeg.setRotY(rad(31.4031F)); rightLeg.setRotZ(rad(-21.10915F));
            rightLeg.setPosX(-3.0F); rightLeg.setPosY(1.25F); rightLeg.setPosZ(0.5F);
        }
        var leftLeg = this.getAnimationProcessor().getBone("left_leg");
        if (leftLeg != null) {
            leftLeg.setRotX(rad(56.52347F)); leftLeg.setRotY(rad(-34.8921F)); leftLeg.setRotZ(rad(26.16981F));
            leftLeg.setPosX(3.25F); leftLeg.setPosY(0.75F); leftLeg.setPosZ(1.0F);
        }
    }

    private static float rad(float degrees) { return degrees * ((float)Math.PI / 180.0F); }

    private void setHiddenIfPresent(String boneName, boolean hidden) {
        var bone = this.getAnimationProcessor().getBone(boneName);
        if (bone != null) bone.setHidden(hidden);
    }

    private static ResourceLocation dmz(String path) {
        return new ResourceLocation("dragonminez", path);
    }
}
