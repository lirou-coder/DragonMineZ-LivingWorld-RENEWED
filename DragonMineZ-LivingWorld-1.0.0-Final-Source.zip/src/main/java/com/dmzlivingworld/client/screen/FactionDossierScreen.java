package com.dmzlivingworld.client.screen;

import com.dmzlivingworld.network.FactionDossierPacket;
import com.dmzlivingworld.network.LWNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.List;

/** Lightweight read-only profile; deliberately avoids inventory/menu complexity. */
@OnlyIn(Dist.CLIENT)
public final class FactionDossierScreen extends Screen implements LivingWorldScreenMarker {
    private static final String[] TABS = {"World", "Factions", "People", "Wanted", "Guide"};

    private final String page;
    private final int slot;
    private final String subtitle;
    private final List<String> rawLines;
    private final List<VisualLine> visualLines = new ArrayList<>();
    private int scroll;
    private int maxScroll;
    private int panelLeft;
    private int panelTop;
    private int panelWidth;
    private int panelHeight;

    private record VisualLine(FormattedCharSequence text, int color, int gapBefore, int factionSlot) {}

    private FactionDossierScreen(FactionDossierPacket packet) {
        super(Component.literal(packet.title()));
        this.page = packet.page();
        this.slot = packet.slot();
        this.subtitle = packet.subtitle();
        this.rawLines = packet.lines();
    }

    public static void open(FactionDossierPacket packet) {
        Minecraft minecraft = Minecraft.getInstance();
        minecraft.setScreen(new FactionDossierScreen(packet));
    }

    @Override
    protected void init() {
        clearWidgets();
        panelWidth = Math.min(430, Math.max(260, width - 44));
        panelHeight = Math.min(310, Math.max(190, height - 34));
        panelLeft = (width - panelWidth) / 2;
        panelTop = (height - panelHeight) / 2;
        rebuildLines();
    }

    private void rebuildLines() {
        visualLines.clear();
        int wrap = panelWidth - 34;
        for (String raw : rawLines) {
            if (raw == null) continue;
            String line = raw;
            int factionSlot = extractSlot(raw);
            int color = 0xFFD8D8D8;
            int gap = 0;
            if (line.startsWith("## ")) { line = line.substring(3); color = LivingWorldGuiStyle.GOLD; gap = 5; }
            else if (line.startsWith("!! ")) { line = line.substring(3); color = 0xFFFF7777; gap = 2; }
            else if (line.startsWith("+ ")) { line = line.substring(2); color = LivingWorldGuiStyle.GREEN; }
            else if (line.startsWith("~ ")) { line = line.substring(2); color = 0xFF8ED6FF; }
            else if (line.startsWith("* ")) { line = "• " + line.substring(2); color = 0xFFC7C7C7; }
            else if (line.startsWith(". ")) { line = line.substring(2); color = 0xFF8D8D8D; }
            List<FormattedCharSequence> wrapped = font.split(Component.literal(line), wrap);
            if (wrapped.isEmpty()) wrapped = List.of(Component.empty().getVisualOrderText());
            boolean first = true;
            for (FormattedCharSequence seq : wrapped) {
                visualLines.add(new VisualLine(seq, color, first ? gap : 0, factionSlot));
                first = false;
            }
        }
        int bodyHeight = panelHeight - ("fighter".equals(page) ? 54 : 72);
        int content = 0;
        for (VisualLine line : visualLines) content += 11 + line.gapBefore;
        maxScroll = Math.max(0, content - bodyHeight);
        scroll = Math.max(0, Math.min(scroll, maxScroll));
    }

    private int footerY() { return panelTop + panelHeight - 27; }
    private int tabGap() { return 4; }
    private int tabWidth() {
        int available = panelWidth - 24 - tabGap() * (TABS.length - 1);
        return Math.max(42, available / TABS.length);
    }
    private int tabX(int index) { return panelLeft + 12 + index * (tabWidth() + tabGap()); }

    private boolean tabSelected(int index) {
        return switch (index) {
            case 0 -> "world".equals(page);
            case 1 -> "factions".equals(page) || "faction".equals(page);
            case 2 -> "people".equals(page);
            case 3 -> "wanted".equals(page);
            default -> false;
        };
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        LivingWorldGuiStyle.drawPanel(graphics, panelLeft, panelTop, panelWidth, panelHeight);
        graphics.fill(panelLeft + 7, panelTop + 43, panelLeft + panelWidth - 7, panelTop + 44, 0xFF4B5662);

        graphics.drawString(font, title, panelLeft + 13, panelTop + 11, 0xFFFFE29A, false);
        if (!subtitle.isBlank()) graphics.drawString(font, subtitle, panelLeft + 13, panelTop + 27, LivingWorldGuiStyle.MUTED, false);

        if (!"fighter".equals(page)) {
            for (int i = 0; i < TABS.length; i++) {
                LivingWorldGuiStyle.drawButton(graphics, font, tabX(i), footerY(), tabWidth(), 18, TABS[i],
                        mouseX, mouseY, true, tabSelected(i), false);
            }
            if ("world".equals(page)) {
                LivingWorldGuiStyle.drawButton(graphics, font,
                        panelLeft + panelWidth - 116, panelTop + 9, 72, 18, "Settings",
                        mouseX, mouseY, true, false, false);
            }
        }

        if ("faction".equals(page) && slot > 0) {
            LivingWorldGuiStyle.drawArrowButton(graphics, font,
                    panelLeft + panelWidth - 100, panelTop + 8, 25, 20, "<", mouseX, mouseY, slot > 1);
            LivingWorldGuiStyle.drawArrowButton(graphics, font,
                    panelLeft + panelWidth - 71, panelTop + 8, 25, 20, ">", mouseX, mouseY, true);
        }
        LivingWorldGuiStyle.drawButton(graphics, font,
                panelLeft + panelWidth - 40, panelTop + 8, 25, 20, "×",
                mouseX, mouseY, true, false, false);

        int clipLeft = panelLeft + 10;
        int clipTop = panelTop + 51;
        int clipRight = panelLeft + panelWidth - 10;
        int clipBottom = panelTop + panelHeight - ("fighter".equals(page) ? 14 : 36);
        graphics.enableScissor(clipLeft, clipTop, clipRight, clipBottom);
        int y = clipTop - scroll;
        for (VisualLine line : visualLines) {
            y += line.gapBefore;
            if (y > clipTop - 14 && y < clipBottom + 4) {
                graphics.drawString(font, line.text, panelLeft + 17, y, line.color, false);
            }
            y += 11;
        }
        graphics.disableScissor();

        if (maxScroll > 0) {
            int trackTop = clipTop;
            int trackBottom = clipBottom;
            int trackHeight = trackBottom - trackTop;
            int thumb = Math.max(18, trackHeight * trackHeight / Math.max(trackHeight + maxScroll, 1));
            int thumbY = trackTop + (trackHeight - thumb) * scroll / Math.max(maxScroll, 1);
            graphics.fill(panelLeft + panelWidth - 7, trackTop, panelLeft + panelWidth - 5, trackBottom, 0x443E4650);
            graphics.fill(panelLeft + panelWidth - 7, thumbY, panelLeft + panelWidth - 5, thumbY + thumb, 0xFFB9C2CC);
            graphics.drawString(font, "Scroll", panelLeft + panelWidth - 45, panelTop + panelHeight - 23, 0xFF777F89, false);
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (!"fighter".equals(page)) {
                for (int i = 0; i < TABS.length; i++) {
                    if (LivingWorldGuiStyle.isInside(mouseX, mouseY, tabX(i), footerY(), tabWidth(), 18)) {
                        switch (i) {
                            case 0 -> LWNetwork.requestMenu("world", 0);
                            case 1 -> LWNetwork.requestMenu("factions", 0);
                            case 2 -> LWNetwork.requestMenu("people", 0);
                            case 3 -> LWNetwork.requestMenu("wanted", 0);
                            case 4 -> LivingWorldGuideScreen.open();
                            default -> { }
                        }
                        return true;
                    }
                }
                if ("world".equals(page) && LivingWorldGuiStyle.isInside(mouseX, mouseY,
                        panelLeft + panelWidth - 116, panelTop + 9, 72, 18)) {
                    LWNetwork.requestMenu("settings", 0);
                    return true;
                }
            }

            if ("faction".equals(page) && slot > 0) {
                if (slot > 1 && LivingWorldGuiStyle.isInside(mouseX, mouseY,
                        panelLeft + panelWidth - 100, panelTop + 8, 25, 20)) {
                    LWNetwork.requestMenu("faction", slot - 1);
                    return true;
                }
                if (LivingWorldGuiStyle.isInside(mouseX, mouseY,
                        panelLeft + panelWidth - 71, panelTop + 8, 25, 20)) {
                    LWNetwork.requestMenu("faction", slot + 1);
                    return true;
                }
            }
            if (LivingWorldGuiStyle.isInside(mouseX, mouseY,
                    panelLeft + panelWidth - 40, panelTop + 8, 25, 20)) {
                onClose();
                return true;
            }

            if ("factions".equals(page)) {
                int clipTop = panelTop + 51;
                int clipBottom = panelTop + panelHeight - ("fighter".equals(page) ? 14 : 36);
                if (mouseX >= panelLeft + 10 && mouseX <= panelLeft + panelWidth - 10 && mouseY >= clipTop && mouseY <= clipBottom) {
                    int y = clipTop - scroll;
                    for (VisualLine line : visualLines) {
                        y += line.gapBefore;
                        if (line.factionSlot > 0 && mouseY >= y - 1 && mouseY <= y + 10) {
                            LWNetwork.requestMenu("faction", line.factionSlot);
                            return true;
                        }
                        y += 11;
                    }
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (maxScroll <= 0) return super.mouseScrolled(mouseX, mouseY, delta);
        scroll = Math.max(0, Math.min(maxScroll, scroll - (int)Math.round(delta * 26.0D)));
        return true;
    }

    private static int extractSlot(String raw) {
        if (raw == null) return 0;
        int hash = raw.indexOf('#');
        if (hash < 0) return 0;
        int end = hash + 1;
        while (end < raw.length() && Character.isDigit(raw.charAt(end))) end++;
        if (end == hash + 1) return 0;
        try { return Integer.parseInt(raw.substring(hash + 1, end)); }
        catch (NumberFormatException ignored) { return 0; }
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
