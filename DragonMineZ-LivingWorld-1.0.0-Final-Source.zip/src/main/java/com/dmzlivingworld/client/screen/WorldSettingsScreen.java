package com.dmzlivingworld.client.screen;

import com.dmzlivingworld.config.LivingWorldConfig;
import com.dmzlivingworld.network.LWNetwork;
import com.dmzlivingworld.network.WorldSettingsPacket;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/** Player-facing editor for the world-specific Forge server config. */
@OnlyIn(Dist.CLIENT)
public final class WorldSettingsScreen extends Screen implements LivingWorldScreenMarker {
    private static final int GOLD = 0xFFFFD66B;
    private static final int GOLD_DARK = 0xFF8D7335;
    private static final int TEXT = 0xFFE4E8EC;
    private static final int MUTED = 0xFF98A4B1;
    private static final int GREEN = 0xFF8EE6A0;
    private static final int ORANGE = 0xFFFFB36B;
    private static final int PANEL = 0xF2181C22;
    private static final int PANEL_INNER = 0xFF20262E;
    private static final int ROW = 0xDD1D232A;
    private static final int ROW_BORDER = 0xFF39434F;
    private static final int CONTROL = 0xFF252D36;
    private static final int CONTROL_HOVER = 0xFF33404C;
    private static final int CONTROL_BORDER = 0xFF556575;
    private static final int CONTROL_DISABLED = 0xFF1D2228;

    private static final int[] FIGHTER_CAPS = {0, 8, 12, 20, 30, 40, 64};
    private static final int[] HOSTILE_CAPS = {0, 2, 4, 6, 8, 10, 16, 24, 32};
    private static final int ROW_COUNT = 7;

    private int activityPreset;
    private int nearbyFighterCap;
    private int nearbyHostileCap;
    private boolean factionEncounters;
    private boolean dynamicEncounters;
    private boolean recurringFighters;
    private boolean automaticPowerSensing;
    private final boolean canEdit;

    private int panelLeft;
    private int panelTop;
    private int panelWidth;
    private int panelHeight;
    private int rowTop;
    private int rowStep;
    private int controlLeft;
    private int controlWidth;
    private int arrowWidth;
    private int footerY;
    private String status = "";
    private long statusUntilMillis;
    private boolean savePending;

    private WorldSettingsScreen(WorldSettingsPacket packet) {
        super(Component.literal("Living World — World Settings"));
        this.activityPreset = packet.activityPreset();
        this.nearbyFighterCap = packet.nearbyFighterCap();
        this.nearbyHostileCap = Math.min(packet.nearbyHostileCap(), packet.nearbyFighterCap());
        this.factionEncounters = packet.factionEncounters();
        this.dynamicEncounters = packet.dynamicEncounters();
        this.recurringFighters = packet.recurringFighters();
        this.automaticPowerSensing = packet.automaticPowerSensing();
        this.canEdit = packet.canEdit();
    }

    public static void open(WorldSettingsPacket packet) {
        Minecraft minecraft = Minecraft.getInstance();
        boolean acknowledgedSave = minecraft.screen instanceof WorldSettingsScreen current && current.savePending;
        WorldSettingsScreen next = new WorldSettingsScreen(packet);
        if (acknowledgedSave) next.setStatus("Saved for this world.", 3200L);
        minecraft.setScreen(next);
    }

    @Override
    protected void init() {
        clearWidgets();
        panelWidth = Math.min(520, Math.max(300, width - 16));
        panelHeight = Math.min(374, Math.max(190, height - 12));
        panelHeight = Math.min(panelHeight, Math.max(160, height - 4));
        panelLeft = (width - panelWidth) / 2;
        panelTop = (height - panelHeight) / 2;

        boolean compact = panelHeight < 300;
        rowTop = panelTop + (compact ? 52 : 62);
        footerY = panelTop + panelHeight - (compact ? 27 : 34);
        int availableRows = footerY - rowTop - 5;
        rowStep = Math.max(20, Math.min(39, availableRows / ROW_COUNT));
        controlWidth = Math.min(178, Math.max(146, panelWidth / 3));
        arrowWidth = 28;
        controlLeft = panelLeft + panelWidth - controlWidth - 16;
    }

    private void resetDefaults() {
        if (!canEdit) return;
        LivingWorldConfig.Snapshot defaults = LivingWorldConfig.defaults();
        activityPreset = defaults.activityPreset();
        nearbyFighterCap = defaults.nearbyFighterCap();
        nearbyHostileCap = defaults.nearbyHostileCap();
        factionEncounters = defaults.factionEncounters();
        dynamicEncounters = defaults.dynamicEncounters();
        recurringFighters = defaults.recurringFighters();
        automaticPowerSensing = defaults.automaticPowerSensing();
        setStatus("Defaults loaded — press Save to apply.", 5000L);
    }

    private void save() {
        if (!canEdit) return;
        normalizeCaps();
        savePending = true;
        setStatus("Saving world settings…", 6000L);
        LWNetwork.updateWorldSettings(new LivingWorldConfig.Snapshot(activityPreset, nearbyFighterCap, nearbyHostileCap,
                factionEncounters, dynamicEncounters, recurringFighters, automaticPowerSensing));
    }

    private void normalizeCaps() {
        nearbyFighterCap = clamp(nearbyFighterCap, 0, 64);
        nearbyHostileCap = clamp(nearbyHostileCap, 0, Math.min(32, nearbyFighterCap));
    }

    private void setStatus(String message, long durationMillis) {
        status = message == null ? "" : message;
        statusUntilMillis = status.isBlank() ? 0L : Util.getMillis() + Math.max(500L, durationMillis);
    }

    private String activityLabel() {
        return switch (activityPreset) {
            case 0 -> "Off";
            case 1 -> "25% / 30s";
            case 3 -> "55% / 12s";
            default -> "40% / 20s";
        };
    }

    private String rowName(int row) {
        return switch (row) {
            case 0 -> "Natural activity";
            case 1 -> "Nearby fighters";
            case 2 -> "Hostile fighters";
            case 3 -> "Faction encounters";
            case 4 -> "Dynamic encounters";
            case 5 -> "Returning fighters";
            default -> "Power sensing";
        };
    }

    private String rowHelp(int row) {
        return switch (row) {
            case 0 -> "Attempt chance / interval for natural Living World activity";
            case 1 -> nearbyFighterCap >= 40
                    ? "Local natural population cap — high values increase AI load"
                    : "Local natural population cap around each player";
            case 2 -> "Maximum hostile fighters inside that local population";
            case 3 -> "Patrols, faction parties and regional presence";
            case 4 -> "Duels, clashes, rescues, ambushes and similar scenes";
            case 5 -> "Previously met persistent fighters may reappear";
            default -> "Automatic nearby-power notifications";
        };
    }

    private String valueLabel(int row) {
        return switch (row) {
            case 0 -> activityLabel();
            case 1 -> Integer.toString(nearbyFighterCap);
            case 2 -> Integer.toString(nearbyHostileCap);
            case 3 -> onOff(factionEncounters);
            case 4 -> onOff(dynamicEncounters);
            case 5 -> onOff(recurringFighters);
            default -> onOff(automaticPowerSensing);
        };
    }

    private boolean canDecrease(int row) {
        if (!canEdit) return false;
        return switch (row) {
            case 0 -> activityPreset > 0;
            case 1 -> previousValue(FIGHTER_CAPS, nearbyFighterCap) < nearbyFighterCap;
            case 2 -> nearbyHostileCap > 0 && previousHostileValue() < nearbyHostileCap;
            case 3 -> factionEncounters;
            case 4 -> dynamicEncounters;
            case 5 -> recurringFighters;
            default -> automaticPowerSensing;
        };
    }

    private boolean canIncrease(int row) {
        if (!canEdit) return false;
        return switch (row) {
            case 0 -> activityPreset < 3;
            case 1 -> nextValue(FIGHTER_CAPS, nearbyFighterCap) > nearbyFighterCap;
            case 2 -> nearbyHostileCap < Math.min(32, nearbyFighterCap) && nextHostileValue() > nearbyHostileCap;
            case 3 -> !factionEncounters;
            case 4 -> !dynamicEncounters;
            case 5 -> !recurringFighters;
            default -> !automaticPowerSensing;
        };
    }

    private void changeValue(int row, int direction) {
        if (!canEdit || direction == 0) return;
        if (direction < 0 && !canDecrease(row)) return;
        if (direction > 0 && !canIncrease(row)) return;

        switch (row) {
            case 0 -> activityPreset = clamp(activityPreset + Integer.signum(direction), 0, 3);
            case 1 -> {
                nearbyFighterCap = direction < 0
                        ? previousValue(FIGHTER_CAPS, nearbyFighterCap)
                        : nextValue(FIGHTER_CAPS, nearbyFighterCap);
                if (nearbyFighterCap <= 0) nearbyHostileCap = 0;
                else if (nearbyHostileCap > nearbyFighterCap) nearbyHostileCap = nearbyFighterCap;
            }
            case 2 -> nearbyHostileCap = direction < 0 ? previousHostileValue() : nextHostileValue();
            case 3 -> factionEncounters = direction > 0;
            case 4 -> dynamicEncounters = direction > 0;
            case 5 -> recurringFighters = direction > 0;
            case 6 -> automaticPowerSensing = direction > 0;
            default -> { }
        }
        savePending = false;
        setStatus("", 0L);
        normalizeCaps();
    }

    private int previousHostileValue() {
        int previous = 0;
        for (int value : HOSTILE_CAPS) {
            if (value >= nearbyHostileCap) break;
            if (value <= nearbyFighterCap) previous = value;
        }
        return previous;
    }

    private int nextHostileValue() {
        int limit = Math.min(32, nearbyFighterCap);
        if (nearbyHostileCap >= limit) return nearbyHostileCap;
        for (int value : HOSTILE_CAPS) {
            if (value > nearbyHostileCap && value <= limit) return value;
        }
        // The local population cap can be a useful exact ceiling even when it is not
        // one of the standard hostile steps (for example 12, 20 or 30).
        return limit;
    }

    private static String onOff(boolean value) { return value ? "On" : "Off"; }

    private static int previousValue(int[] values, int current) {
        int previous = values[0];
        for (int value : values) {
            if (value >= current) break;
            previous = value;
        }
        return previous;
    }

    private static int nextValue(int[] values, int current) {
        for (int value : values) if (value > current) return value;
        return current;
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private int rowY(int row) { return rowTop + row * rowStep; }
    private int rowHeight() { return Math.max(18, rowStep - 3); }
    private int controlHeight() { return Math.min(20, Math.max(16, rowHeight() - 2)); }
    private int leftArrowX() { return controlLeft; }
    private int valueX() { return controlLeft + arrowWidth + 3; }
    private int valueWidth() { return controlWidth - arrowWidth * 2 - 6; }
    private int rightArrowX() { return controlLeft + controlWidth - arrowWidth; }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);

        LivingWorldGuiStyle.drawPanel(graphics, panelLeft, panelTop, panelWidth, panelHeight);
        graphics.fill(panelLeft + 5, panelTop + 5, panelLeft + panelWidth - 5, panelTop + panelHeight - 5, PANEL_INNER);
        // Keep an interior header accent while the shared outer frame provides the strong border.
        graphics.fill(panelLeft + 5, panelTop + 5, panelLeft + panelWidth - 5, panelTop + 8, GOLD);
        graphics.fill(panelLeft + 12, panelTop + 48, panelLeft + panelWidth - 12, panelTop + 49, 0xFF49535E);

        graphics.drawString(font, "DRAGON MINE Z: LIVING WORLD", panelLeft + 16, panelTop + 14, 0xFFFFE29A, false);
        graphics.drawString(font, "World Settings", panelLeft + 16, panelTop + 30, MUTED, false);
        graphics.drawString(font, "Saved per world/server", panelLeft + panelWidth - 122, panelTop + 30, 0xFF75818D, false);

        for (int row = 0; row < ROW_COUNT; row++) drawSettingRow(graphics, row, mouseX, mouseY);

        int statusY = footerY - (rowStep < 29 ? 10 : 12);
        if (!canEdit) {
            graphics.drawString(font, "View only — world host or server operator required to edit.",
                    panelLeft + 16, statusY, ORANGE, false);
        } else if (!status.isBlank() && Util.getMillis() <= statusUntilMillis) {
            graphics.drawString(font, status, panelLeft + 16, statusY,
                    status.startsWith("Saved") ? GREEN : MUTED, false);
        } else if (nearbyFighterCap >= 40) {
            graphics.drawString(font, "Performance note: large local populations mean more active DMZ AI.",
                    panelLeft + 16, statusY, ORANGE, false);
        }

        int defaultsX = panelLeft + 16;
        int backX = panelLeft + panelWidth - 78;
        int saveX = backX - 72;
        drawActionButton(graphics, defaultsX, footerY, 78, 20, "Defaults", mouseX, mouseY, canEdit, false);
        drawActionButton(graphics, saveX, footerY, 64, 20, "Save", mouseX, mouseY, canEdit, true);
        drawActionButton(graphics, backX, footerY, 62, 20, "Back", mouseX, mouseY, true, false);

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private void drawSettingRow(GuiGraphics graphics, int row, int mouseX, int mouseY) {
        int y = rowY(row);
        int h = rowHeight();
        int rowLeft = panelLeft + 13;
        int rowRight = panelLeft + panelWidth - 13;
        graphics.fill(rowLeft, y, rowRight, y + h, ROW_BORDER);
        graphics.fill(rowLeft + 1, y + 1, rowRight - 1, y + h - 1, ROW);
        graphics.fill(rowLeft + 1, y + 1, rowLeft + 3, y + h - 1, row == 0 ? GOLD_DARK : 0xFF53687A);

        if (rowStep >= 29) {
            graphics.drawString(font, rowName(row), rowLeft + 9, y + 5, TEXT, false);
            graphics.drawString(font, rowHelp(row), rowLeft + 9, y + 16, MUTED, false);
        } else {
            graphics.drawString(font, rowName(row), rowLeft + 9, y + Math.max(4, (h - 8) / 2), TEXT, false);
        }

        int controlH = controlHeight();
        drawArrowControl(graphics, row, y + Math.max(1, (h - controlH) / 2), controlH, mouseX, mouseY);
    }

    private void drawArrowControl(GuiGraphics graphics, int row, int y, int h, int mouseX, int mouseY) {
        boolean leftEnabled = canDecrease(row);
        boolean rightEnabled = canIncrease(row);
        drawSmallButton(graphics, leftArrowX(), y, arrowWidth, h, "<", mouseX, mouseY, leftEnabled);
        drawValueBox(graphics, valueX(), y, valueWidth(), h, valueLabel(row), row, mouseX, mouseY);
        drawSmallButton(graphics, rightArrowX(), y, arrowWidth, h, ">", mouseX, mouseY, rightEnabled);
    }

    private void drawValueBox(GuiGraphics graphics, int x, int y, int w, int h, String label, int row, int mouseX, int mouseY) {
        graphics.fill(x, y, x + w, y + h, CONTROL_BORDER);
        graphics.fill(x + 1, y + 1, x + w - 1, y + h - 1, CONTROL);
        int color = ((row >= 3 && "On".equals(label)) ? GREEN : TEXT);
        drawCentered(graphics, label, x, y + Math.max(4, (h - 8) / 2), w, color);
    }

    private void drawSmallButton(GuiGraphics graphics, int x, int y, int w, int h, String label,
                                 int mouseX, int mouseY, boolean enabled) {
        LivingWorldGuiStyle.drawArrowButton(graphics, font, x, y, w, h, label, mouseX, mouseY, enabled);
    }

    private void drawActionButton(GuiGraphics graphics, int x, int y, int w, int h, String label,
                                  int mouseX, int mouseY, boolean enabled, boolean primary) {
        LivingWorldGuiStyle.drawButton(graphics, font, x, y, w, h, label, mouseX, mouseY, enabled, false, primary);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        for (int row = 0; row < ROW_COUNT; row++) {
            int controlH = controlHeight();
            int y = rowY(row) + Math.max(1, (rowHeight() - controlH) / 2);
            if (isInside(mouseX, mouseY, leftArrowX(), y, arrowWidth, controlH)) {
                changeValue(row, -1);
                return true;
            }
            if (isInside(mouseX, mouseY, rightArrowX(), y, arrowWidth, controlH)) {
                changeValue(row, 1);
                return true;
            }
        }

        int defaultsX = panelLeft + 16;
        int backX = panelLeft + panelWidth - 78;
        int saveX = backX - 72;
        if (isInside(mouseX, mouseY, defaultsX, footerY, 78, 20)) { resetDefaults(); return true; }
        if (isInside(mouseX, mouseY, saveX, footerY, 64, 20)) { save(); return true; }
        if (isInside(mouseX, mouseY, backX, footerY, 62, 20)) {
            LWNetwork.requestMenu("world", 0);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void drawCentered(GuiGraphics graphics, String label, int x, int y, int w, int color) {
        graphics.drawString(font, label, x + Math.max(0, (w - font.width(label)) / 2), y, color, false);
    }

    private static boolean isInside(double mouseX, double mouseY, int x, int y, int w, int h) {
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }

    @Override
    public void onClose() {
        LWNetwork.requestMenu("world", 0);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
