package com.dmzlivingworld.client.screen;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Shared visual language for every Living World screen and control. */
public final class LivingWorldGuiStyle {
    public static final int GOLD = 0xFFFFD66B;
    public static final int GOLD_DARK = 0xFF8D7335;
    public static final int TEXT = 0xFFE4E8EC;
    public static final int MUTED = 0xFF98A4B1;
    public static final int GREEN = 0xFF8EE6A0;
    public static final int ORANGE = 0xFFFFB36B;
    public static final int PANEL = 0xF2181C22;
    public static final int PANEL_INNER = 0xFF20262E;
    public static final int CONTROL = 0xFF252D36;
    public static final int CONTROL_HOVER = 0xFF33404C;
    public static final int CONTROL_BORDER = 0xFF556575;
    public static final int CONTROL_DISABLED = 0xFF1D2228;
    public static final int CONTROL_SELECTED = 0xFF3A3423;

    private LivingWorldGuiStyle() { }

    /**
     * Draws a deliberately visible two-tone border with a dark drop shadow.
     * The border is shared by the overview, guide and settings screens so the
     * entire addon reads as one interface instead of a collection of vanilla menus.
     */
    public static void drawPanel(GuiGraphics graphics, int left, int top, int width, int height) {
        int right = left + width;
        int bottom = top + height;

        graphics.fill(left - 4, top - 4, right + 4, bottom + 4, 0x99000000);
        graphics.fill(left - 3, top - 3, right + 3, bottom + 3, GOLD_DARK);
        graphics.fill(left - 2, top - 2, right + 2, bottom + 2, GOLD);
        graphics.fill(left - 1, top - 1, right + 1, bottom + 1, 0xFF4E421F);
        graphics.fill(left, top, right, bottom, PANEL);

        // Small bright corner brackets make the frame read clearly even on busy scenes.
        graphics.fill(left - 3, top - 3, left + 12, top - 1, GOLD);
        graphics.fill(left - 3, top - 3, left - 1, top + 12, GOLD);
        graphics.fill(right - 12, top - 3, right + 3, top - 1, GOLD);
        graphics.fill(right + 1, top - 3, right + 3, top + 12, GOLD);
        graphics.fill(left - 3, bottom + 1, left + 12, bottom + 3, GOLD_DARK);
        graphics.fill(left - 3, bottom - 12, left - 1, bottom + 3, GOLD_DARK);
        graphics.fill(right - 12, bottom + 1, right + 3, bottom + 3, GOLD_DARK);
        graphics.fill(right + 1, bottom - 12, right + 3, bottom + 3, GOLD_DARK);
    }

    public static void drawButton(GuiGraphics graphics, Font font,
                                  int x, int y, int width, int height, String label,
                                  int mouseX, int mouseY,
                                  boolean enabled, boolean selected, boolean primary) {
        boolean hover = enabled && isInside(mouseX, mouseY, x, y, width, height);
        int border = enabled
                ? ((selected || primary) ? GOLD_DARK : CONTROL_BORDER)
                : 0xFF333940;
        int fill = enabled
                ? (hover ? CONTROL_HOVER : (selected ? CONTROL_SELECTED : CONTROL))
                : CONTROL_DISABLED;
        int textColor = enabled
                ? ((selected || primary) ? GOLD : TEXT)
                : 0xFF626B74;

        graphics.fill(x, y, x + width, y + height, border);
        graphics.fill(x + 1, y + 1, x + width - 1, y + height - 1, fill);
        if (selected || primary) {
            graphics.fill(x + 1, y + 1, x + width - 1, y + 2, GOLD_DARK);
        }
        if (hover) {
            graphics.fill(x + 2, y + height - 2, x + width - 2, y + height - 1,
                    selected || primary ? GOLD : 0xFF6A7D8F);
        }
        drawCentered(graphics, font, label, x, y, width, height, textColor);
    }

    /** Draws a larger, optically centered arrow without changing the hitbox size. */
    public static void drawArrowButton(GuiGraphics graphics, Font font,
                                       int x, int y, int width, int height, String label,
                                       int mouseX, int mouseY, boolean enabled) {
        boolean hover = enabled && isInside(mouseX, mouseY, x, y, width, height);
        int border = enabled ? GOLD_DARK : 0xFF333940;
        int fill = enabled ? (hover ? CONTROL_HOVER : CONTROL) : CONTROL_DISABLED;
        int color = enabled ? GOLD : 0xFF626B74;

        graphics.fill(x, y, x + width, y + height, border);
        graphics.fill(x + 1, y + 1, x + width - 1, y + height - 1, fill);
        if (hover) graphics.fill(x + 2, y + height - 2, x + width - 2, y + height - 1, GOLD);

        float scale = 1.35F;
        float centerX = x + width / 2.0F;
        float centerY = y + height / 2.0F;
        graphics.pose().pushPose();
        graphics.pose().translate(centerX, centerY, 0.0F);
        graphics.pose().scale(scale, scale, 1.0F);
        int textX = -font.width(label) / 2;
        int textY = -font.lineHeight / 2;
        graphics.drawString(font, label, textX, textY, color, false);
        graphics.pose().popPose();
    }

    public static void drawCentered(GuiGraphics graphics, Font font, String label,
                                    int x, int y, int width, int height, int color) {
        int textX = x + Math.max(0, (width - font.width(label)) / 2);
        int textY = y + Math.max(0, (height - font.lineHeight) / 2) + 1;
        graphics.drawString(font, label, textX, textY, color, false);
    }

    public static boolean isInside(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }
}
