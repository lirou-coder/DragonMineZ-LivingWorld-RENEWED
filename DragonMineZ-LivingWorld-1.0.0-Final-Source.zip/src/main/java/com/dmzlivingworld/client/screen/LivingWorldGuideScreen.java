package com.dmzlivingworld.client.screen;

import com.dmzlivingworld.network.LWNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.ArrayList;
import java.util.List;

/** Player-facing Living World guide. Static help stays client-side and never touches simulation state. */
@OnlyIn(Dist.CLIENT)
public final class LivingWorldGuideScreen extends Screen {
    private static final int GOLD = 0xFFFFD66B;
    private static final int TEXT = 0xFFD8D8D8;
    private static final int MUTED = 0xFF9EABB8;
    private static final int ACCENT = 0xFF8ED6FF;

    private record Chapter(String title, String subtitle, List<String> lines) {}
    private record VisualLine(FormattedCharSequence text, int color, int gapBefore) {}

    private static final List<Chapter> CHAPTERS = List.of(
            chapter("Getting Started", "What Living World changes",
                    "Living World makes Dragon Mine Z fighters persistent parts of your world instead of disposable encounters.",
                    "## Start here",
                    "* Press L to open the Living World overview.",
                    "* Use the Guide button there to return to this screen at any time.",
                    "* Shift + Right-click a Living World fighter to inspect that fighter.",
                    "* A Dragon Mine Z Scouter reveals additional combat information when inspecting.",
                    "## What happens automatically",
                    "* Fighters can grow, remember battles, develop relationships, pursue goals and take part in world activity without needing debug commands.",
                    ". The /lw command tree is primarily an operator/debug toolbox. Normal play does not require it."),
            chapter("Fighters", "Persistent warriors with their own identity",
                    "Living World fighters keep an identity and can become recurring characters across your playthrough.",
                    "## A fighter can remember",
                    "* Power and progression",
                    "* Personality and combat tendencies",
                    "* Important battles and opponents",
                    "* Relationships and rivalries",
                    "* Equipment, techniques and goals",
                    "## Inspecting fighters",
                    "* Shift + Right-click a Living World fighter for a readable profile.",
                    "* Their history becomes more meaningful the longer they survive and interact with the world."),
            chapter("Relationships", "Rivals, companions, mentors and students",
                    "Repeated encounters can change how fighters relate to you and to one another.",
                    "## Relationships can develop into",
                    "* Friendship and companionship",
                    "* Rivalry and long-running grudges",
                    "* Mentorship and student relationships",
                    "* Faction ties and changing reputation",
                    "## Companions",
                    "* Compatible fighters can become travelling companions through Living World's interaction systems.",
                    "* A companion remains a real persistent fighter rather than being replaced by a generic follower."),
            chapter("Combat & Growth", "Dragon Mine Z systems, not a separate combat layer",
                    "Living World is built around Dragon Mine Z's native combat and progression systems.",
                    "## Fighters can use",
                    "* Melee combat and Ki attacks",
                    "* Flight and pursuit",
                    "* Transformations and racial progression",
                    "* Training and power growth",
                    "* Native Dragon Mine Z equipment",
                    ". Their strength and decisions can change as their story develops."),
            chapter("Techniques", "Knowledge can have a lineage",
                    "Fighters can learn real Dragon Mine Z techniques and remember where that knowledge came from.",
                    "## Technique lineage",
                    "* Mentors can teach other fighters.",
                    "* Learned techniques remain attached to the persistent fighter.",
                    "* Teacher/student history can become part of a fighter's legacy."),
            chapter("Equipment", "Ownership, recovery and inheritance",
                    "Living World fighters can interact with actual Dragon Mine Z equipment rather than cosmetic stand-ins.",
                    "## Equipment systems",
                    "* Fighters can own and use equipment.",
                    "* Important gear can change owners over time.",
                    "* Equipment may be recovered or inherited after major events.",
                    "* Supported gear includes items such as armor, swords and Blaster Cannons when available through DMZ."),
            chapter("Goals", "Fighters have reasons to act",
                    "Persistent fighters can pursue practical objectives instead of existing only to fight the player.",
                    "## Example goals",
                    "* Defeat a rival or stronger opponent",
                    "* Learn a technique",
                    "* Obtain useful equipment",
                    "* Learn flight or improve combat ability",
                    ". Goals can change as a fighter progresses and experiences new events."),
            chapter("Factions & Activity", "A world with organizations and conflict",
                    "Living World adds ongoing activity around Dragon Mine Z's existing world.",
                    "## You may encounter",
                    "* Wandering warriors",
                    "* Factions and patrols",
                    "* Training groups and clashes",
                    "* Wanted fighters",
                    "* Guardian/peacekeeper responses",
                    "* Conflicts and faction requests",
                    "## L menu",
                    "* World shows the current situation around you.",
                    "* Factions tracks organizations you have discovered.",
                    "* People surfaces notable persistent fighters.",
                    "* Wanted shows active wanted profiles."),
            chapter("History & Legacy", "The world remembers important events",
                    "Living World records major events so fighters can build an actual history across a long save.",
                    "## History can include",
                    "* Important victories and defeats",
                    "* Rival battles",
                    "* Techniques and mentorship",
                    "* Equipment inheritance",
                    "* Progression and major changes",
                    "* Deaths and fallen fighters",
                    ". The goal is for a long-running world to accumulate its own recognizable cast and stories."),
            chapter("Controls", "Useful player interactions",
                    "## Main interface",
                    "* L — open the Living World overview.",
                    "* Guide — open this guide from the overview.",
                    "## Fighters",
                    "* Shift + Right-click — inspect a Living World fighter.",
                    "* Shift + Right-click with a Dragon Mine Z Scouter — show additional combat information.",
                    "## Commands",
                    "* /livingworld — open the Living World overview.",
                    "* /livingworld guide — open this guide directly.",
                    ". /lw is reserved primarily for operators and debugging."),
            chapter("Integrations", "Compatibility with the Dragon Mine Z ecosystem",
                    "Living World is an unofficial Dragon Mine Z addon and depends on Dragon Mine Z for its core combat/progression systems.",
                    "## Required",
                    "* Minecraft 1.20.1",
                    "* Forge 47.4.x",
                    "* Dragon Mine Z 2.1.3",
                    "* GeckoLib 4.8.4+",
                    "## Optional",
                    "* Supported Dragon Mine Z Meditation builds can integrate with Living World companion/meditation behavior when installed.")
    );

    private final List<VisualLine> visualLines = new ArrayList<>();
    private int chapterIndex;
    private int scroll;
    private int maxScroll;
    private int panelLeft;
    private int panelTop;
    private int panelWidth;
    private int panelHeight;
    private int navWidth;

    private LivingWorldGuideScreen() {
        super(Component.literal("Living World — Guide"));
    }

    public static void open() {
        Minecraft.getInstance().setScreen(new LivingWorldGuideScreen());
    }

    @Override
    protected void init() {
        clearWidgets();
        panelWidth = Math.min(620, Math.max(390, width - 34));
        panelHeight = Math.min(360, Math.max(230, height - 28));
        panelLeft = (width - panelWidth) / 2;
        panelTop = (height - panelHeight) / 2;
        navWidth = Math.min(148, Math.max(112, panelWidth / 4));

        int navX = panelLeft + 12;
        int navY = panelTop + 49;
        int buttonW = navWidth - 18;
        int available = panelHeight - 86;
        int buttonH = Math.max(16, Math.min(19, (available - (CHAPTERS.size() - 1) * 3) / CHAPTERS.size()));
        for (int i = 0; i < CHAPTERS.size(); i++) {
            final int index = i;
            addRenderableWidget(Button.builder(Component.literal(CHAPTERS.get(i).title()), b -> selectChapter(index))
                    .bounds(navX, navY + i * (buttonH + 3), buttonW, buttonH).build());
        }

        addRenderableWidget(Button.builder(Component.literal("Back"), b -> LWNetwork.requestMenu("world", 0))
                .bounds(panelLeft + panelWidth - 91, panelTop + panelHeight - 27, 52, 18).build());
        addRenderableWidget(Button.builder(Component.literal("×"), b -> onClose())
                .bounds(panelLeft + panelWidth - 33, panelTop + panelHeight - 27, 22, 18).build());
        rebuildLines();
    }

    private static Chapter chapter(String title, String subtitle, String... lines) {
        return new Chapter(title, subtitle, List.of(lines));
    }

    private void selectChapter(int index) {
        chapterIndex = Math.max(0, Math.min(CHAPTERS.size() - 1, index));
        scroll = 0;
        rebuildLines();
    }

    private void rebuildLines() {
        visualLines.clear();
        Chapter chapter = CHAPTERS.get(chapterIndex);
        int contentLeft = panelLeft + navWidth + 12;
        int wrap = Math.max(120, panelLeft + panelWidth - 18 - contentLeft);
        for (String raw : chapter.lines()) {
            if (raw == null) continue;
            String line = raw;
            int color = TEXT;
            int gap = 0;
            if (line.startsWith("## ")) { line = line.substring(3); color = GOLD; gap = 6; }
            else if (line.startsWith("* ")) { line = "• " + line.substring(2); color = 0xFFC7C7C7; }
            else if (line.startsWith(". ")) { line = line.substring(2); color = MUTED; gap = 2; }
            else if (line.startsWith("~ ")) { line = line.substring(2); color = ACCENT; }
            List<FormattedCharSequence> wrapped = font.split(Component.literal(line), wrap);
            if (wrapped.isEmpty()) wrapped = List.of(Component.empty().getVisualOrderText());
            boolean first = true;
            for (FormattedCharSequence seq : wrapped) {
                visualLines.add(new VisualLine(seq, color, first ? gap : 0));
                first = false;
            }
        }
        int bodyHeight = panelHeight - 94;
        int content = 0;
        for (VisualLine line : visualLines) content += 11 + line.gapBefore();
        maxScroll = Math.max(0, content - bodyHeight);
        scroll = Math.max(0, Math.min(scroll, maxScroll));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelTop + panelHeight, 0xE514171C);
        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 3, 0xFFFFC857);
        graphics.fill(panelLeft + navWidth, panelTop + 43, panelLeft + navWidth + 1, panelTop + panelHeight - 35, 0x554F5966);
        graphics.fill(panelLeft + 8, panelTop + 43, panelLeft + panelWidth - 8, panelTop + 44, 0x554F5966);

        Chapter chapter = CHAPTERS.get(chapterIndex);
        graphics.drawString(font, "DRAGON MINE Z: LIVING WORLD", panelLeft + 13, panelTop + 11, 0xFFFFE29A, false);
        graphics.drawString(font, "Guide", panelLeft + 13, panelTop + 27, MUTED, false);

        int contentLeft = panelLeft + navWidth + 12;
        graphics.drawString(font, chapter.title(), contentLeft, panelTop + 52, GOLD, false);
        graphics.drawString(font, chapter.subtitle(), contentLeft, panelTop + 66, MUTED, false);

        int clipTop = panelTop + 84;
        int clipBottom = panelTop + panelHeight - 35;
        int clipRight = panelLeft + panelWidth - 10;
        graphics.enableScissor(contentLeft, clipTop, clipRight, clipBottom);
        int y = clipTop - scroll;
        for (VisualLine line : visualLines) {
            y += line.gapBefore();
            if (y > clipTop - 14 && y < clipBottom + 4) graphics.drawString(font, line.text(), contentLeft, y, line.color(), false);
            y += 11;
        }
        graphics.disableScissor();

        if (maxScroll > 0) {
            int trackHeight = clipBottom - clipTop;
            int thumb = Math.max(18, trackHeight * trackHeight / Math.max(trackHeight + maxScroll, 1));
            int thumbY = clipTop + (trackHeight - thumb) * scroll / Math.max(maxScroll, 1);
            graphics.fill(panelLeft + panelWidth - 7, clipTop, panelLeft + panelWidth - 5, clipBottom, 0x443E4650);
            graphics.fill(panelLeft + panelWidth - 7, thumbY, panelLeft + panelWidth - 5, thumbY + thumb, 0xFFB9C2CC);
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (maxScroll <= 0) return super.mouseScrolled(mouseX, mouseY, delta);
        scroll = Math.max(0, Math.min(maxScroll, scroll - (int) Math.round(delta * 26.0D)));
        return true;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
