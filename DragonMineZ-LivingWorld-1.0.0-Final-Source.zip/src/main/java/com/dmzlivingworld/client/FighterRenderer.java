package com.dmzlivingworld.client;

import com.dmzlivingworld.client.layer.FighterAppearanceLayer;
import com.dmzlivingworld.client.layer.FighterHairLayer;
import com.dmzlivingworld.entity.AmbientFighterEntity;
import com.dragonminez.client.init.entities.renderer.sagas.DBSagasRenderer;
import com.dragonminez.client.init.entities.renderer.sagas.layer.DMZSagaArmorLayer;
import com.dragonminez.client.init.entities.renderer.sagas.layer.DMZSagaItemInHandLayer;
import com.dragonminez.client.render.util.IrisCompat;
import com.dragonminez.client.render.util.PlayerEffectQueue;
import com.dragonminez.common.init.entities.sagas.DBSagasEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.network.chat.Component;
import org.joml.Matrix4f;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

import java.lang.reflect.Method;

/**
 * Multi-race Living World fighter renderer.
 *
 * The body/appearance is LW's procedural composition of DMZ assets, while the
 * charging/transforming aura pass is delegated back to DragonMineZ's own
 * DBSagasRenderer implementation. This is important: DBSagasEntity.setKiCharge()
 * only changes entity state; the stock saga renderer is what actually draws DMZ's
 * aura shader, pulse aura and lightning. Our custom renderer previously skipped it.
 */
public final class FighterRenderer extends GeoEntityRenderer<AmbientFighterEntity> {
    private final DBSagasRenderer<AmbientFighterEntity> nativeSagaEffects;
    private final Method drawEffectsInline;
    private final Method drawEffectsDeferred;
    private boolean nativeEffectsUnavailable;

    public FighterRenderer(EntityRendererProvider.Context context) {
        super(context, new FighterModel());
        addRenderLayer(new FighterAppearanceLayer(this));
        addRenderLayer(new FighterHairLayer(this));
        // Reuse DMZ 2.1.3's own saga equipment renderers. Living Arsenal stores
        // genuine ItemStacks in the entity slots; these layers are the native visual path.
        addRenderLayer(new DMZSagaArmorLayer<>(this));
        addRenderLayer(new DMZSagaItemInHandLayer<>(this));
        shadowRadius = 0.45F;

        // Targeted bridge for the exact DMZ 2.1.3 runtime this addon supports.
        // The methods are private in DMZ, so reflection lets us reuse the exact
        // native saga aura implementation without copying/reinventing its shader.
        DBSagasRenderer<AmbientFighterEntity> effects = null;
        Method inline = null;
        Method deferred = null;
        try {
            effects = new DBSagasRenderer<>(context);
            inline = DBSagasRenderer.class.getDeclaredMethod(
                    "drawEffectsInline", DBSagasEntity.class, PoseStack.class,
                    float.class, boolean.class, boolean.class);
            inline.setAccessible(true);
            deferred = DBSagasRenderer.class.getDeclaredMethod(
                    "drawEffects", DBSagasEntity.class, Matrix4f.class,
                    float.class, boolean.class, boolean.class);
            deferred.setAccessible(true);
        } catch (ReflectiveOperationException ignored) {
            // If DMZ changes these internals in a future version, rendering the
            // fighter itself must remain safe. This addon targets DMZ 2.1.3.
        }
        nativeSagaEffects = effects;
        drawEffectsInline = inline;
        drawEffectsDeferred = deferred;
    }

    @Override
    public void render(AmbientFighterEntity entity, float entityYaw, float partialTick,
                       PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
        float scale = entity.getDisplayScale();
        poseStack.pushPose();
        poseStack.scale(scale, scale, scale);
        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);

        // DMZ's native saga renderer draws aura whenever a saga NPC is charging or
        // transforming, plus lightning independently. Mirror that exact trigger.
        renderNativeSagaEffects(entity, poseStack, partialTick);
        poseStack.popPose();

        renderIdentity(entity, poseStack, bufferSource, packedLight);
        renderSpeech(entity, poseStack, bufferSource, packedLight);
    }

    private void renderNativeSagaEffects(AmbientFighterEntity entity, PoseStack poseStack, float partialTick) {
        if (nativeEffectsUnavailable || nativeSagaEffects == null || drawEffectsInline == null) return;

        boolean aura = entity.isTransforming() || entity.isCharge() || entity.isAuraFlared() || entity.isKaiokenAuraPulse();
        boolean lightning = entity.isLightning();
        if (!aura && !lightning) return;

        try {
            if (IrisCompat.isShaderPackInUse() && drawEffectsDeferred != null) {
                Matrix4f capturedMatrix = new Matrix4f(poseStack.last().pose());
                PlayerEffectQueue.addEntityEffect(() -> {
                    try {
                        drawEffectsDeferred.invoke(nativeSagaEffects, entity, capturedMatrix,
                                partialTick, aura, lightning);
                    } catch (ReflectiveOperationException ignored) {
                        nativeEffectsUnavailable = true;
                    }
                });
            } else {
                drawEffectsInline.invoke(nativeSagaEffects, entity, poseStack,
                        partialTick, aura, lightning);
            }
        } catch (ReflectiveOperationException ignored) {
            nativeEffectsUnavailable = true;
        }
    }

    private void renderIdentity(AmbientFighterEntity entity, PoseStack poseStack,
                                MultiBufferSource buffers, int packedLight) {
        Minecraft minecraft = Minecraft.getInstance();
        // Fusion and other native effects may intentionally hide a fighter. Never
        // render LW's custom floating identity independently of the hidden body.
        if (entity.isInvisible() || (minecraft.player != null && entity.isInvisibleTo(minecraft.player))) return;
        if (minecraft.player == null) return;
        double max = entity.isWanted() || entity.isFactionLeader() ? 4096.0D : 2304.0D;
        if (minecraft.player.distanceToSqr(entity) > max) return;

        Font font = minecraft.font;
        String title = entity.isNonCombatant() ? "Resident" : entity.getFactionTitle();
        String top = entity.getFighterName();
        if (!title.isBlank()) top = title + " " + top;
        String legacyTitle = entity.getLegacyTitle();
        if (!legacyTitle.isBlank()) top = legacyTitle + " " + top;
        if (entity.isWanted()) top = "WANTED " + "★".repeat(Math.max(1, entity.getWantedLevel())) + " " + top;
        String story = switch (entity.getStoryRole()) {
            case AmbientFighterEntity.STORY_ALLY -> "ALLY • ";
            case AmbientFighterEntity.STORY_ENEMY -> "ENEMY • ";
            case AmbientFighterEntity.STORY_CAPTIVE -> "CAPTIVE • ";
            case AmbientFighterEntity.STORY_PEACEKEEPER -> "PEACEKEEPER • ";
            default -> "";
        };
        top = story + top;
        Component name = Component.literal(top);
        float nameWidth = font.width(name);

        poseStack.pushPose();
        double labelHeight = entity.getBbHeight() + 0.96D + Math.max(0.0F, entity.getDisplayScale() - 1.0F) * 0.46D;
        poseStack.translate(0.0D, labelHeight, 0.0D);
        poseStack.mulPose(minecraft.getEntityRenderDispatcher().cameraOrientation());
        poseStack.scale(-0.028F, -0.028F, 0.028F);
        int color = entity.getStoryRole() == AmbientFighterEntity.STORY_ALLY ? 0xFF7DFF9A
                : entity.getStoryRole() == AmbientFighterEntity.STORY_ENEMY ? 0xFFFF6969
                : entity.getStoryRole() == AmbientFighterEntity.STORY_CAPTIVE ? 0xFFFFD166
                : entity.getStoryRole() == AmbientFighterEntity.STORY_PEACEKEEPER ? 0xFF76D7FF
                : entity.isWanted() ? 0xFFFF6B6B
                : entity.isFactionLeader() ? 0xFFFFD76A
                : entity.getFactionRole() == com.dmzlivingworld.world.FactionRole.LIEUTENANT ? 0xFF7FDBFF
                : entity.getFactionRole() == com.dmzlivingworld.world.FactionRole.ENFORCER ? 0xFFE3B8FF
                : entity.getFactionRole() == com.dmzlivingworld.world.FactionRole.RECRUIT ? 0xFFC4C4C4
                : entity.isNonCombatant() ? 0xFFD2D2D2 : 0xFFFFFFFF;
        font.drawInBatch(name, -nameWidth / 2.0F, 0.0F, color, false,
                poseStack.last().pose(), buffers, Font.DisplayMode.NORMAL, 0x55000000, packedLight);

        String factionName = entity.getFactionDisplayName();
        if (!factionName.isBlank() && minecraft.player.distanceToSqr(entity) <= 900.0D) {
            Component faction = Component.literal(factionName);
            float fw = font.width(faction);
            font.drawInBatch(faction, -fw / 2.0F, 10.5F, 0xFFB8B8B8, false,
                    poseStack.last().pose(), buffers, Font.DisplayMode.NORMAL, 0x44000000, packedLight);
        }
        poseStack.popPose();
    }

    private void renderSpeech(AmbientFighterEntity entity, PoseStack poseStack,
                              MultiBufferSource buffers, int packedLight) {
        Minecraft minecraft = Minecraft.getInstance();
        if (entity.isInvisible() || (minecraft.player != null && entity.isInvisibleTo(minecraft.player))) return;
        String speech = entity.getSpeech();
        if (speech == null || speech.isBlank()) return;
        if (minecraft.player == null || minecraft.player.distanceToSqr(entity) > 1600.0D) return;

        Font font = minecraft.font;
        Component text = Component.literal(speech);
        float width = font.width(text);

        poseStack.pushPose();
        double speechHeight = entity.getBbHeight() + 1.68D + Math.max(0.0F, entity.getDisplayScale() - 1.0F) * 0.50D;
        poseStack.translate(0.0D, speechHeight, 0.0D);
        poseStack.mulPose(minecraft.getEntityRenderDispatcher().cameraOrientation());
        poseStack.scale(-0.025F, -0.025F, 0.025F);
        font.drawInBatch(text, -width / 2.0F, 0.0F, 0xFFFFFFFF, false,
                poseStack.last().pose(), buffers, Font.DisplayMode.NORMAL, 0x66000000, packedLight);
        poseStack.popPose();
    }
}
