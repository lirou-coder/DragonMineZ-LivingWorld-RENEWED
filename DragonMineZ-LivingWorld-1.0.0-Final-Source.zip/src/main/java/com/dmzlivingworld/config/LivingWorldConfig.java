package com.dmzlivingworld.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** World-specific Living World settings. Registered as a Forge SERVER config. */
public final class LivingWorldConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.IntValue ACTIVITY_PRESET;
    public static final ForgeConfigSpec.IntValue NEARBY_FIGHTER_CAP;
    public static final ForgeConfigSpec.IntValue NEARBY_HOSTILE_CAP;
    public static final ForgeConfigSpec.BooleanValue FACTION_ENCOUNTERS;
    public static final ForgeConfigSpec.BooleanValue DYNAMIC_ENCOUNTERS;
    public static final ForgeConfigSpec.BooleanValue RECURRING_FIGHTERS;
    public static final ForgeConfigSpec.BooleanValue AUTOMATIC_POWER_SENSING;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.comment(
                "Dragon Mine Z: Living World — per-world settings.",
                "These values are saved with this world/server, not globally for every Minecraft world.")
                .push("world");

        ACTIVITY_PRESET = builder
                .comment(
                        "Natural Living World activity level.",
                        "0 = Off.",
                        "1 = 25% activity roll every 30 seconds.",
                        "2 = 40% activity roll every 20 seconds (default).",
                        "3 = 55% activity roll every 12 seconds.",
                        "Population caps and encounter rules still apply; debug spawns are unaffected.")
                .defineInRange("activityPreset", 2, 0, 3);

        NEARBY_FIGHTER_CAP = builder
                .comment(
                        "Maximum Living World fighters naturally maintained near each player.",
                        "Existing/debug-spawned fighters are never deleted just because this value is lowered.")
                .defineInRange("nearbyFighterCap", 20, 0, 64);

        NEARBY_HOSTILE_CAP = builder
                .comment("Maximum naturally generated hostile Living World fighters near each player.")
                .defineInRange("nearbyHostileCap", 6, 0, 32);

        FACTION_ENCOUNTERS = builder
                .comment("Allow natural faction patrols/parties and regional faction presence.")
                .define("factionEncounters", true);

        DYNAMIC_ENCOUNTERS = builder
                .comment("Allow natural small scenes such as duels, clashes, rescues and ambushes.")
                .define("dynamicEncounters", true);

        RECURRING_FIGHTERS = builder
                .comment("Allow previously encountered persistent fighters to naturally reappear near the player.")
                .define("recurringFighters", true);

        AUTOMATIC_POWER_SENSING = builder
                .comment("Show automatic nearby-power sensing notifications. Manual /lw sense is unaffected.")
                .define("automaticPowerSensing", true);

        builder.pop();
        SPEC = builder.build();
    }

    private LivingWorldConfig() {}

    public static int activityPreset() { return ACTIVITY_PRESET.get(); }
    public static int nearbyFighterCap() { return NEARBY_FIGHTER_CAP.get(); }
    public static int nearbyHostileCap() { return Math.min(NEARBY_HOSTILE_CAP.get(), nearbyFighterCap()); }
    public static boolean factionEncounters() { return FACTION_ENCOUNTERS.get(); }
    public static boolean dynamicEncounters() { return DYNAMIC_ENCOUNTERS.get(); }
    public static boolean recurringFighters() { return RECURRING_FIGHTERS.get(); }
    public static boolean automaticPowerSensing() { return AUTOMATIC_POWER_SENSING.get(); }

    public static int naturalCheckIntervalTicks() {
        return switch (activityPreset()) {
            case 1 -> 600; // 30 seconds
            case 3 -> 240; // 12 seconds
            default -> 400; // 20 seconds
        };
    }

    public static double naturalSpawnRoll() {
        return switch (activityPreset()) {
            case 0 -> 0.0D;
            case 1 -> 0.25D;
            case 3 -> 0.55D;
            default -> 0.40D;
        };
    }

    public static Snapshot snapshot() {
        return new Snapshot(activityPreset(), nearbyFighterCap(), nearbyHostileCap(), factionEncounters(),
                dynamicEncounters(), recurringFighters(), automaticPowerSensing());
    }

    public static void apply(Snapshot value) {
        if (value == null) return;
        ACTIVITY_PRESET.set(clamp(value.activityPreset(), 0, 3));
        int nearby = clamp(value.nearbyFighterCap(), 0, 64);
        NEARBY_FIGHTER_CAP.set(nearby);
        // Store a valid relationship, not only a clamped getter result. This keeps the
        // TOML, network snapshot and GUI in agreement after lowering the local cap.
        NEARBY_HOSTILE_CAP.set(clamp(value.nearbyHostileCap(), 0, Math.min(32, nearby)));
        FACTION_ENCOUNTERS.set(value.factionEncounters());
        DYNAMIC_ENCOUNTERS.set(value.dynamicEncounters());
        RECURRING_FIGHTERS.set(value.recurringFighters());
        AUTOMATIC_POWER_SENSING.set(value.automaticPowerSensing());
        // One save flushes the entire spec after the in-memory values are updated.
        ACTIVITY_PRESET.save();
    }

    public static Snapshot defaults() {
        return new Snapshot(2, 20, 6, true, true, true, true);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    public record Snapshot(int activityPreset, int nearbyFighterCap, int nearbyHostileCap,
                           boolean factionEncounters, boolean dynamicEncounters,
                           boolean recurringFighters, boolean automaticPowerSensing) {}
}
