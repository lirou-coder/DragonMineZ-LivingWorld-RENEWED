package com.dmzlivingworld.world;

import com.dmzlivingworld.entity.AmbientFighterEntity;
import com.dmzlivingworld.network.FactionDossierPacket;
import com.dmzlivingworld.network.LWNetwork;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/**
 * In-world fighter profile. Sneak + right-clicking a Living World fighter opens a read-only
 * profile screen instead of dumping commands/chat. A DMZ scouter adds tactical detail.
 * Normal right-click remains untouched for Minecraft/DMZ interactions.
 */
public final class FighterInspectionManager {
    private FighterInspectionManager() {}

    public static boolean isScouter(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(stack.getItem());
        return id != null && "dragonminez".equals(id.getNamespace()) && id.getPath().contains("scouter");
    }

    public static void inspect(ServerPlayer player, AmbientFighterEntity fighter, boolean scouter) {
        if (player == null || fighter == null) return;
        FighterGoalManager.summary(fighter); // lazily assigns a valid individual goal server-side

        String titlePrefix = fighter.getLegacyTitle().isBlank() ? "" : fighter.getLegacyTitle() + " ";
        List<String> lines = new ArrayList<>();

        lines.add("## Identity");
        lines.add("* " + fighter.getRace().displayName() + " • " + fighter.getRank().displayName()
                + " • " + fighter.getArchetype().displayName() + " • " + fighter.getAlignment().displayName());
        lines.add("* Temperament: " + fighter.getPersonality().displayName()
                + " • fighting style: " + FighterCombatDirector.signatureLabel(fighter));
        if (fighter.isFactionMember()) {
            WorldFaction faction = fighter.level() instanceof net.minecraft.server.level.ServerLevel level
                    ? FactionManager.byId(level, fighter.getFactionId()) : null;
            String factionLine = fighter.getFactionDisplayName().isBlank() ? fighter.getFactionId() : fighter.getFactionDisplayName();
            if (!fighter.getFactionTitle().isBlank()) factionLine += " • " + fighter.getFactionTitle();
            lines.add("* Faction: " + factionLine);
            if (faction != null) lines.add("* Weapon tradition: " + FighterArsenalManager.factionArsenalIdentity(faction));
        }
        if (scouter) {
            lines.add("~ Scouter PL: " + fighter.getBattlePower());
            lines.add("~ Flight: " + (fighter.hasFlightUnlocked() ? "learned" : "not learned")
                    + " • racial training " + fighter.getRacialSkillLevel() + "/"
                    + com.dmzlivingworld.entity.RacialFormProfile.maxSkillLevel(fighter.getRace()));
        }

        lines.add("## Relationships");
        if (fighter.isRememberedFor(player)) {
            lines.add("* Encounters with you: " + Math.max(1, fighter.getMemoryEncounters())
                    + " • relationship " + fighter.getMemoryRelationship());
        }
        if (!fighter.getMentorName().isBlank()) lines.add("* Mentor: " + fighter.getMentorName());
        if (!fighter.getRivalName().isBlank()) lines.add("* Rival: " + fighter.getRivalName());
        if (fighter.getNemesisStage() > 0) {
            lines.add("!! Rivalry level " + fighter.getNemesisStage() + "/5 • battles with you "
                    + fighter.getLegacyData().getInt("NemesisBattles") + " • wins " + fighter.getLegacyData().getInt("NemesisWins"));
        }

        lines.add("## Current Goal");
        String progress = FighterGoalManager.progress(fighter);
        lines.add("+ " + FighterGoalManager.summary(fighter) + (progress.isBlank() ? "" : " • " + progress));
        if (FighterGoalManager.completedCount(fighter) > 0) {
            lines.add(". Completed goals: " + FighterGoalManager.completedCount(fighter)
                    + " • last: " + FighterGoalManager.lastCompleted(fighter));
        }

        lines.add("## Equipment");
        List<String> gear = FighterArsenalManager.detailedEquipment(fighter);
        for (String line : gear) lines.add("* " + line);

        lines.add("## Techniques");
        lines.add("* Learned: " + FighterTechniqueManager.summary(fighter));
        String lineage = FighterTechniqueManager.lineageSummary(fighter);
        if (!"none".equals(lineage)) lines.add("~ Passed down through: " + lineage);

        lines.add("## Battle Record");
        int wins = fighter.getLegacyData().getInt("Wins");
        int losses = fighter.getLegacyData().getInt("Losses");
        int kills = fighter.getLegacyData().getInt("Kills");
        int deaths = fighter.getLegacyData().getInt("Deaths");
        lines.add("* Record: " + wins + " wins / " + losses + " losses • lethal " + kills + "/" + deaths);
        if (fighter.getLegacyData().getInt("StrongestWinPower") > 0) {
            lines.add("* Strongest victory: " + fighter.getLegacyData().getString("StrongestWinName")
                    + " • PL " + fighter.getLegacyData().getInt("StrongestWinPower"));
        }
        if (fighter.getLegacyData().getInt("Fusions") > 0) {
            lines.add("* Fusions: " + fighter.getLegacyData().getInt("Fusions")
                    + " • last partner " + fighter.getLegacyData().getString("LastFusionPartner"));
        }
        String lastOpponent = fighter.getLegacyData().getString("LastOpponent");
        if (!lastOpponent.isBlank()) lines.add("* Last battle: " + fighter.getLegacyData().getString("LastResult") + " vs " + lastOpponent);

        ListTag events = fighter.getLegacyData().getList("Events", Tag.TAG_STRING);
        if (!events.isEmpty()) {
            lines.add("## Important Events");
            int start = Math.max(0, events.size() - 8);
            for (int i = start; i < events.size(); i++) {
                String event = events.getString(i);
                if (!event.isBlank()) lines.add(". " + event);
            }
        }

        String subtitle = scouter ? "Scouter analysis" : "Fighter profile";
        LWNetwork.sendFactionDossier(player, new FactionDossierPacket(
                "fighter", 0, titlePrefix + fighter.getFighterName(), subtitle, lines));
    }
}
