package com.dmzlivingworld.world;

import com.dmzlivingworld.LivingWorldMod;
import com.dmzlivingworld.entity.AmbientFighterEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;
import java.util.UUID;

/** Rare, simulation-backed allied calls for help and prisoner rescues. */
@Mod.EventBusSubscriber(modid = LivingWorldMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class FactionRequestManager {
    private static final String ROOT = "DMZLivingWorldFactionRequest";
    private static long lastWarCaptureDay = -1L;

    private FactionRequestManager() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        ServerLevel overworld = event.getServer().overworld();
        long now = overworld.getGameTime();
        long day = now / 24000L;
        if (day != lastWarCaptureDay) {
            lastWarCaptureDay = day;
            simulateRareCaptures(overworld, now, day);
            resolveOldPrisoners(overworld, now);
        }
        if (now % 20L != 0L) return;
        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            if (!(player.level() instanceof ServerLevel level) || !LivingWorldDimensions.isSupported(level)) continue;
            tickPlayer(player, level, now);
        }
    }

    private static void simulateRareCaptures(ServerLevel overworld, long now, long day) {
        FactionWorldData data = FactionWorldData.get(overworld);
        data.tickOrganizations(overworld);
        // World-seeded daily roll: rare enough that captures remain notable.
        var random = net.minecraft.util.RandomSource.create(FactionWorldData.mix(overworld.getSeed() ^ day * 0xB5297A4D1B56C4E9L));
        if (PrisonerWorldData.get(overworld).active().size() >= 5 || random.nextFloat() > 0.075F) return;
        List<WorldFaction> atWar = data.activeFactions().stream().filter(f -> !data.warEnemies(f, now).isEmpty()).toList();
        if (atWar.isEmpty()) return;
        WorldFaction victim = atWar.get(random.nextInt(atWar.size()));
        List<WorldFaction> enemies = data.warEnemies(victim, now);
        if (enemies.isEmpty()) return;
        WorldFaction captor = enemies.get(random.nextInt(enemies.size()));
        PrisonerWorldData.get(overworld).capture(overworld, victim, captor, now);
    }

    private static void resolveOldPrisoners(ServerLevel overworld, long now) {
        PrisonerWorldData prisoners = PrisonerWorldData.get(overworld);
        for (PrisonerWorldData.Prisoner p : prisoners.active()) {
            long age = now - p.capturedAt;
            long deadline = 120000L + Math.floorMod(p.id.hashCode(), 72001); // ~5-8 days
            if (age < deadline) continue;

            ServerLevel realmLevel = LivingWorldDimensions.levelFor(overworld.getServer(), p.realm);
            AmbientFighterEntity physical = realmLevel == null || p.entityId == null ? null : entity(realmLevel, p.entityId);
            if (physical != null) {
                // Do not resolve somebody out from under a player who is actively at the prison scene.
                boolean witnessed = !realmLevel.getEntitiesOfClass(ServerPlayer.class, physical.getBoundingBox().inflate(96.0D)).isEmpty();
                if (witnessed) continue;
                physical.setCaptive(false);
                physical.discard();
                p.entityId = null;
                prisoners.setDirty();
            }
            prisoners.resolveExpired(overworld, p, now);
        }
    }

    private static void tickPlayer(ServerPlayer player, ServerLevel level, long now) {
        CompoundTag req = request(player);
        if (!req.getString("Type").isBlank()) {
            tickActive(player, level, now, req);
            return;
        }
        CompoundTag root = root(player);
        long next = root.getLong("NextOffer");
        if (next == 0L) {
            root.putLong("NextOffer", now + 72000L + player.getRandom().nextInt(72001)); // 3-6 days before first chance
            save(player, root); return;
        }
        if (now < next) return;
        root.putLong("NextOffer", now + 120000L + player.getRandom().nextInt(120001)); // then ~5-10 days
        save(player, root);
        createRareOffer(player, level, now);
    }

    private static void createRareOffer(ServerPlayer player, ServerLevel level, long now) {
        FactionWorldData data = FactionWorldData.get(level);
        // Rescue opportunities get priority because they involve an actual missing person.
        List<PrisonerWorldData.Prisoner> prisoners = PrisonerWorldData.get(level).active().stream()
                .filter(p -> p.realm == LivingWorldDimensions.realm(level))
                .filter(p -> {
                    WorldFaction victim = data.byId(p.victimFactionId);
                    return victim != null && FactionManager.getReputation(player, victim) >= FactionManager.FRIENDLY_REP;
                }).toList();
        if (!prisoners.isEmpty() && player.getRandom().nextFloat() < 0.62F) {
            PrisonerWorldData.Prisoner prisoner = prisoners.get(player.getRandom().nextInt(prisoners.size()));
            WorldFaction victim = data.byId(prisoner.victimFactionId), captor = data.byId(prisoner.captorFactionId);
            if (victim != null && captor != null) {
                setRequest(player, "RESCUE", victim, captor, prisoner.id, now + 72000L);
                notify(player, victim.name() + " has asked for help. " + prisoner.name + " is being held by " + captor.name() + ".");
                return;
            }
        }

        List<WorldFaction> friendlyWars = data.activeFactions().stream()
                .filter(f -> f.realm() == LivingWorldDimensions.realm(level))
                .filter(f -> FactionManager.getReputation(player, f) >= FactionManager.FRIENDLY_REP)
                .filter(f -> !data.warEnemies(f, now).isEmpty()).toList();
        if (friendlyWars.isEmpty() || player.getRandom().nextFloat() > 0.55F) return;
        WorldFaction ally = friendlyWars.get(player.getRandom().nextInt(friendlyWars.size()));
        List<WorldFaction> enemies = data.warEnemies(ally, now);
        if (enemies.isEmpty()) return;
        WorldFaction enemy = enemies.get(player.getRandom().nextInt(enemies.size()));
        String type = player.getRandom().nextBoolean() ? "DEFEND" : "ASSAULT";
        setRequest(player, type, ally, enemy, "", now + 48000L);
        notify(player, type.equals("DEFEND") ? ally.name() + " expects an enemy strike and has quietly asked for your help."
                : ally.name() + " is preparing a strike against " + enemy.name() + " and asked if you'll stand with them.");
    }

    private static void tickActive(ServerPlayer player, ServerLevel level, long now, CompoundTag req) {
        FactionWorldData data = FactionWorldData.get(level);
        WorldFaction ally = data.byId(req.getString("Source"));
        WorldFaction enemy = data.byId(req.getString("Target"));
        String type = req.getString("Type");
        boolean startedRescue = "RESCUE".equals(type) && req.getBoolean("Started");
        if (ally == null || enemy == null || (now > req.getLong("Expires") && !startedRescue)) {
            clearRequest(player); return;
        }
        if (ally.realm() != LivingWorldDimensions.realm(level)) return;
        int targetX = type.equals("DEFEND") ? ally.roamX() : enemy.roamX();
        int targetZ = type.equals("DEFEND") ? ally.roamZ() : enemy.roamZ();
        double d2 = (player.getX()-targetX)*(player.getX()-targetX) + (player.getZ()-targetZ)*(player.getZ()-targetZ);
        boolean debugImmediate = req.getBoolean("DebugImmediate");
        if (!debugImmediate && d2 > 300.0D * 300.0D) {
            if (now % 100L < 20L) {
                int blocks = (int)Math.round(Math.sqrt(d2));
                String destination = type.equals("DEFEND") ? ally.name() : enemy.name();
                player.displayClientMessage(Component.literal("Living World • " + type + " • " + destination
                        + " • " + FactionManager.direction(player.getX(), player.getZ(), targetX, targetZ) + " • " + blocks + " blocks"), true);
            }
            return;
        }

        if (type.equals("RESCUE")) {
            tickRescue(player, level, now, req, ally, enemy);
            return;
        }
        if (!req.getBoolean("Started")) {
            // A story request should begin in the player's visual field, not at the normal
            // ambient 38-62 block encounter radius. Combat choreography itself is unchanged.
            int spawned = FactionEncounterManager.spawnFactionClash(player, ally, enemy, true);
            if (spawned > 0) {
                markStorySides(level, player, ally, enemy);
                req.putBoolean("Started", true); req.putLong("StartedAt", now); req.putInt("Presence", 0);
                req.putBoolean("DebugImmediate", false); saveRequest(player, req);
                player.displayClientMessage(Component.literal("Living World • ALLY: " + ally.name() + " • ENEMY: " + enemy.name()), true);
            } else if (debugImmediate && now % 40L < 20L) {
                player.displayClientMessage(Component.literal("Living World • request ready • waiting for an existing faction scene/activity to clear"), true);
            }
            return;
        }
        if (d2 <= 220.0D * 220.0D) req.putInt("Presence", req.getInt("Presence") + 20);
        if (req.getInt("Presence") >= 600) {
            FactionManager.adjustReputation(player, ally, 8);
            PlayerWorldManager.addHeroic(player, ally.alignment() == com.dmzlivingworld.entity.FighterAlignment.GOOD ? 4 : 1);
            PlayerWorldManager.addFame(player, 3);
            data.addHistory(ally, now, "A trusted outsider answered the call during the war with " + enemy.name() + ".");
            notify(player, ally.name() + " will remember that you answered their call.");
            clearRequest(player);
        } else saveRequest(player, req);
    }

    private static void tickRescue(ServerPlayer player, ServerLevel level, long now, CompoundTag req,
                                   WorldFaction ally, WorldFaction captor) {
        PrisonerWorldData store = PrisonerWorldData.get(level);
        PrisonerWorldData.Prisoner p = store.byId(req.getString("Prisoner"));
        if (p == null || !p.active()) { clearRequest(player); return; }
        AmbientFighterEntity captive = p.entityId == null ? null : entity(level, p.entityId);
        UUID party = req.hasUUID("GuardParty") ? req.getUUID("GuardParty") : null;
        if (captive == null && !req.getBoolean("Started")) {
            BlockPos anchor = AmbientFighterSpawner.findEncounterAnchor(player, true);
            if (anchor == null) return;
            WorldFaction victim = FactionWorldData.get(level).byId(p.victimFactionId);
            if (victim == null) return;
            party = UUID.randomUUID();
            AmbientFighterEntity spawned = AmbientFighterSpawner.spawnAt(level, anchor, victim.alignment(), p.rank,
                    p.personality, p.race, p.archetype, player.getRandom());
            if (spawned == null) return;
            spawned.setFighterName(p.name); spawned.forceGender(p.female); spawned.setBattlePower(p.battlePower);
            spawned.assignFaction(victim, p.role, party, false, false); spawned.setCaptive(true); spawned.setStoryRole(AmbientFighterEntity.STORY_CAPTIVE); spawned.setPersistenceRequired();
            p.entityId = spawned.getUUID(); captive = spawned;
            int guards = 3 + player.getRandom().nextInt(3);
            for (int i=0;i<guards;i++) {
                AmbientFighterEntity guard = FactionEncounterManager.spawnMember(player, captor, anchor, party, i==0,
                        i==0 ? FactionRole.ENFORCER : FactionRole.MEMBER, null, false);
                if (guard != null) guard.setStoryRole(AmbientFighterEntity.STORY_ENEMY);
            }
            req.putBoolean("Started", true); req.putBoolean("DebugImmediate", false); req.putUUID("GuardParty", party); saveRequest(player, req); store.setDirty();
            spawned.speak("You came...", 62);
            player.displayClientMessage(Component.literal("Living World • CAPTIVE: " + p.name + " • ENEMY guards: " + captor.name()), true);
            return;
        }
        if (captive == null) return;
        if (now % 80L < 20L) player.displayClientMessage(Component.literal("RESCUE • CAPTIVE: " + p.name + " • defeat the ENEMY guards"), true);
        final UUID guardParty = party;
        boolean guardsAlive = !level.getEntitiesOfClass(AmbientFighterEntity.class, captive.getBoundingBox().inflate(120.0D),
                f -> f.isAlive() && f.getPartyId() != null && guardParty != null && guardParty.equals(f.getPartyId())
                        && f.isFactionMember() && captor.id().equals(f.getFactionId())).isEmpty();
        if (!guardsAlive) {
            captive.setCaptive(false);
            captive.setStoryRole(AmbientFighterEntity.STORY_ALLY);
            store.markRescued(level, p, now);
            FactionManager.adjustReputation(player, ally, 22);
            PlayerWorldManager.addHeroic(player, 10); PlayerWorldManager.addFame(player, 7);
            FighterMemoryManager.rememberRescue(player, captive);
            captive.speak("I owe you. Really.", 72);
            notify(player, p.name + " is free. " + ally.name() + " will remember this.");
            clearRequest(player);
        }
    }

    public static String summary(ServerPlayer player) {
        CompoundTag req = request(player);
        if (req.getString("Type").isBlank()) return "No allied faction is currently asking anything of you.";
        FactionWorldData data = FactionWorldData.get(player.serverLevel());
        WorldFaction a=data.byId(req.getString("Source")), b=data.byId(req.getString("Target"));
        if (a==null||b==null) return "An old request is no longer relevant.";
        String type=req.getString("Type");
        if (type.equals("RESCUE")) {
            PrisonerWorldData.Prisoner p=PrisonerWorldData.get(player.serverLevel()).byId(req.getString("Prisoner"));
            return "RESCUE • " + (p==null?"captured fighter":p.name) + " • #" + a.slot() + " " + a.name() + " → held by #" + b.slot() + " " + b.name();
        }
        return type + " • #" + a.slot() + " " + a.name() + " vs #" + b.slot() + " " + b.name();
    }

    public static int force(ServerPlayer player, String type) {
        if (!(player.level() instanceof ServerLevel level)) return 0;
        clearRequest(player);
        FactionWorldData data=FactionWorldData.get(level); long now=level.getServer().overworld().getGameTime();
        List<WorldFaction> friendly=data.activeFactions().stream().filter(f->f.realm()==LivingWorldDimensions.realm(level))
                .filter(f->FactionManager.getReputation(player,f)>=FactionManager.FRIENDLY_REP).toList();
        if (friendly.isEmpty()) friendly=data.factions(LivingWorldDimensions.realm(level));
        if (friendly.isEmpty()) return 0;
        WorldFaction ally=friendly.get(0);
        WorldFaction enemy=data.activeFactions().stream().filter(f->f.realm()==ally.realm()&&!f.id().equals(ally.id()))
                .filter(f->FactionManager.relation(level,ally,f).hostile()).findFirst().orElse(null);
        if (enemy==null) enemy=data.activeFactions().stream().filter(f->f.realm()==ally.realm()&&!f.id().equals(ally.id())).findFirst().orElse(null);
        if (enemy==null) return 0;
        if ("RESCUE".equalsIgnoreCase(type)) {
            PrisonerWorldData.Prisoner p=PrisonerWorldData.get(level).capture(level,ally,enemy,now);
            if(p==null)return 0; setRequest(player,"RESCUE",ally,enemy,p.id,now+72000L);
        } else setRequest(player,"DEFEND".equalsIgnoreCase(type)?"DEFEND":"ASSAULT",ally,enemy,"",now+48000L);
        CompoundTag forced = request(player);
        forced.putBoolean("DebugImmediate", true);
        saveRequest(player, forced);
        tickActive(player, level, now, forced);
        notify(player,"Debug accelerated rare request: "+summary(player)); return 1;
    }

    private static void markStorySides(ServerLevel level, ServerPlayer player, WorldFaction ally, WorldFaction enemy) {
        for (AmbientFighterEntity fighter : level.getEntitiesOfClass(AmbientFighterEntity.class,
                player.getBoundingBox().inflate(96.0D), f -> f.isAlive() && f.isFactionMember() && !f.isRegionalPresence())) {
            if (ally.id().equals(fighter.getFactionId())) fighter.setStoryRole(AmbientFighterEntity.STORY_ALLY);
            else if (enemy.id().equals(fighter.getFactionId())) fighter.setStoryRole(AmbientFighterEntity.STORY_ENEMY);
        }
    }

    private static void setRequest(ServerPlayer player,String type,WorldFaction source,WorldFaction target,String prisoner,long expires){
        CompoundTag root=root(player), req=new CompoundTag(); req.putString("Type",type); req.putString("Source",source.id()); req.putString("Target",target.id());
        req.putString("Prisoner",prisoner==null?"":prisoner); req.putLong("Expires",expires); root.put("Active",req); save(player,root);
        PlayerWorldManager.discoverFaction(player,source); PlayerWorldManager.discoverFaction(player,target);
    }
    private static CompoundTag request(ServerPlayer p){return root(p).getCompound("Active");}
    private static void saveRequest(ServerPlayer p,CompoundTag req){CompoundTag root=root(p);root.put("Active",req);save(p,root);}
    private static void clearRequest(ServerPlayer p){
        if (p.level() instanceof ServerLevel level) {
            for (AmbientFighterEntity fighter : level.getEntitiesOfClass(AmbientFighterEntity.class, p.getBoundingBox().inflate(180.0D),
                    f -> f.getStoryRole() >= AmbientFighterEntity.STORY_ALLY && f.getStoryRole() <= AmbientFighterEntity.STORY_CAPTIVE))
                fighter.setStoryRole(AmbientFighterEntity.STORY_NONE);
        }
        CompoundTag root=root(p);root.remove("Active");save(p,root);
    }
    private static CompoundTag root(ServerPlayer p){CompoundTag d=p.getPersistentData();if(!d.contains(ROOT,net.minecraft.nbt.Tag.TAG_COMPOUND))d.put(ROOT,new CompoundTag());return d.getCompound(ROOT);}
    private static void save(ServerPlayer p,CompoundTag root){p.getPersistentData().put(ROOT,root);}
    private static AmbientFighterEntity entity(ServerLevel l,UUID id){var e=l.getEntity(id);return e instanceof AmbientFighterEntity f?f:null;}
    private static void notify(ServerPlayer p,String text){p.displayClientMessage(Component.literal("[Living World] ").withStyle(ChatFormatting.GOLD).append(Component.literal(text).withStyle(ChatFormatting.WHITE)),false);}

    @SubscribeEvent public static void onClone(PlayerEvent.Clone e){if(e.getOriginal() instanceof ServerPlayer o&&e.getEntity() instanceof ServerPlayer c&&o.getPersistentData().contains(ROOT,net.minecraft.nbt.Tag.TAG_COMPOUND))c.getPersistentData().put(ROOT,o.getPersistentData().getCompound(ROOT).copy());}
}
