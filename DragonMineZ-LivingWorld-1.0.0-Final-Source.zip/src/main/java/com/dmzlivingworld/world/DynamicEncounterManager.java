package com.dmzlivingworld.world;

import com.dmzlivingworld.entity.AmbientFighterEntity;
import com.dmzlivingworld.entity.FighterAlignment;
import com.dmzlivingworld.entity.FighterPersonality;
import com.dmzlivingworld.entity.FighterRank;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.npc.Villager;

import java.util.ArrayList;
import java.util.List;

/**
 * Small encounter compositions. These are deliberately scenes, not structures or quests:
 * a few compatible entities are placed near one another and given an initial motive.
 */
public final class DynamicEncounterManager {
    private DynamicEncounterManager() {}

    public static boolean trySpawnNaturalEncounter(ServerPlayer player, int capacity, int remainingBadSlots) {
        RandomSource random = player.getRandom();
        List<EncounterType> eligible = new ArrayList<>();

        if (capacity >= 2) eligible.add(EncounterType.DUEL);
        if (capacity >= 2 && remainingBadSlots >= 1) {
            eligible.add(EncounterType.CLASH);
            eligible.add(EncounterType.MUGGING);
        }
        if (capacity >= 3 && remainingBadSlots >= 1) eligible.add(EncounterType.RESCUE);
        if (capacity >= 2 && remainingBadSlots >= 2 && random.nextDouble() < 0.20D) eligible.add(EncounterType.AMBUSH);
        if (capacity >= 4 && remainingBadSlots >= 2 && random.nextDouble() < 0.14D) eligible.add(EncounterType.BRAWL);
        if (capacity >= 1 && random.nextDouble() < 0.14D) eligible.add(EncounterType.FRIEZA_SKIRMISH);

        if (eligible.isEmpty()) return false;
        EncounterType chosen = eligible.get(random.nextInt(eligible.size()));
        return spawnEncounter(player, chosen, false) > 0;
    }

    public static int spawnEncounter(ServerPlayer player, EncounterType type, boolean debug) {
        BlockPos anchor = AmbientFighterSpawner.findEncounterAnchor(player, debug);
        if (anchor == null) return 0;

        return switch (type) {
            case DUEL -> spawnDuel(player, anchor);
            case CLASH -> spawnClash(player, anchor);
            case MUGGING -> spawnMugging(player, anchor);
            case RESCUE -> spawnRescue(player, anchor);
            case AMBUSH -> spawnAmbush(player, anchor);
            case BRAWL -> spawnBrawl(player, anchor);
            case FRIEZA_SKIRMISH -> spawnFriezaSkirmish(player, anchor);
        };
    }

    private static int spawnDuel(ServerPlayer player, BlockPos anchor) {
        FighterRank rank = player.getRandom().nextDouble() < 0.72D ? FighterRank.TRAINED : FighterRank.ROOKIE;
        AmbientFighterEntity first = spawn(player, anchor, FighterAlignment.NEUTRAL, rank, FighterPersonality.PROUD);
        AmbientFighterEntity second = spawn(player, anchor, FighterAlignment.NEUTRAL, rank, FighterPersonality.CALM);
        if (!complete(first, second)) return cleanup(first, second);

        first.startDuel(second);
        second.startDuel(first);
        return 2;
    }

    private static int spawnClash(ServerPlayer player, BlockPos anchor) {
        AmbientFighterEntity good = spawn(player, anchor, FighterAlignment.GOOD, FighterRank.TRAINED, FighterPersonality.HEROIC);
        AmbientFighterEntity bad = spawn(player, anchor, FighterAlignment.BAD, FighterRank.TRAINED, FighterPersonality.AGGRESSIVE);
        if (!complete(good, bad)) return cleanup(good, bad);

        good.setTarget(bad);
        bad.setTarget(good);
        return 2;
    }

    private static int spawnMugging(ServerPlayer player, BlockPos anchor) {
        AmbientFighterEntity bad = spawn(player, anchor, FighterAlignment.BAD, FighterRank.TRAINED, FighterPersonality.AGGRESSIVE);
        if (bad == null) return 0;

        // If this scene happens near an existing village, use an existing civilian rather
        // than creating permanent villagers. Otherwise another Earth fighter is the victim.
        if (player.level() instanceof ServerLevel level) {
            List<Villager> villagers = level.getEntitiesOfClass(
                    Villager.class,
                    bad.getBoundingBox().inflate(22.0D, 10.0D, 22.0D),
                    Villager::isAlive
            );
            if (!villagers.isEmpty()) {
                bad.setTarget(villagers.get(0));
                return 1;
            }
        }

        AmbientFighterEntity victim = spawn(player, anchor, FighterAlignment.NEUTRAL, FighterRank.ROOKIE, FighterPersonality.CAUTIOUS);
        if (victim == null) return cleanup(bad);
        bad.setTarget(victim);
        return 2;
    }

    private static int spawnRescue(ServerPlayer player, BlockPos anchor) {
        AmbientFighterEntity victim = spawn(player, anchor, FighterAlignment.NEUTRAL, FighterRank.ROOKIE, FighterPersonality.CAUTIOUS);
        AmbientFighterEntity bad = spawn(player, anchor, FighterAlignment.BAD, FighterRank.TRAINED, FighterPersonality.AGGRESSIVE);
        AmbientFighterEntity good = spawn(player, anchor, FighterAlignment.GOOD, FighterRank.TRAINED, FighterPersonality.HEROIC);
        if (!complete(victim, bad, good)) return cleanup(victim, bad, good);

        bad.setTarget(victim);
        good.setTarget(bad);
        return 3;
    }

    private static int spawnAmbush(ServerPlayer player, BlockPos anchor) {
        AmbientFighterEntity first = spawn(player, anchor, FighterAlignment.BAD, FighterRank.ROOKIE, FighterPersonality.AGGRESSIVE);
        FighterRank secondRank = player.getRandom().nextDouble() < 0.72D ? FighterRank.ROOKIE : FighterRank.TRAINED;
        AmbientFighterEntity second = spawn(player, anchor, FighterAlignment.BAD, secondRank, FighterPersonality.AGGRESSIVE);
        if (!complete(first, second)) return cleanup(first, second);

        first.setTarget(player);
        second.setTarget(player);
        return 2;
    }

    private static int spawnBrawl(ServerPlayer player, BlockPos anchor) {
        // 0.6.10: brawl is a readable 2v2 skirmish rather than three bodies collapsing
        // onto one target. Native target acquisition can still reshuffle the fight later.
        AmbientFighterEntity goodOne = spawn(player, anchor, FighterAlignment.GOOD, FighterRank.TRAINED, FighterPersonality.HEROIC);
        AmbientFighterEntity goodTwo = spawn(player, anchor, FighterAlignment.GOOD,
                player.getRandom().nextBoolean() ? FighterRank.ROOKIE : FighterRank.TRAINED, FighterPersonality.CALM);
        AmbientFighterEntity badOne = spawn(player, anchor, FighterAlignment.BAD, FighterRank.TRAINED, FighterPersonality.AGGRESSIVE);
        AmbientFighterEntity badTwo = spawn(player, anchor, FighterAlignment.BAD,
                player.getRandom().nextBoolean() ? FighterRank.ROOKIE : FighterRank.TRAINED, FighterPersonality.PROUD);
        if (!complete(goodOne, goodTwo, badOne, badTwo)) return cleanup(goodOne, goodTwo, badOne, badTwo);

        goodOne.setTarget(badOne);
        badOne.setTarget(goodOne);
        goodTwo.setTarget(badTwo);
        badTwo.setTarget(goodTwo);
        return 4;
    }

    private static int spawnFriezaSkirmish(ServerPlayer player, BlockPos anchor) {
        AmbientFighterEntity fighter = spawn(player, anchor, FighterAlignment.GOOD, FighterRank.TRAINED, FighterPersonality.HEROIC);
        if (fighter == null || !(player.level() instanceof ServerLevel level)) return cleanup(fighter);
        BlockPos soldierPos = AmbientFighterSpawner.findSafeGroundAround(level, anchor, player.getRandom(), 5, 10, 16);
        if (soldierPos == null) return cleanup(fighter);
        String type = player.getRandom().nextBoolean() ? "saga_friezasoldier01" : "saga_friezasoldier02";
        Mob soldier = FriezaNpcUtil.spawnSoldier(level, soldierPos, fighter, player.getRandom(), type,
                "lw_frieza_skirmish");
        if (soldier == null) return cleanup(fighter);
        fighter.setTarget(soldier);
        return 2;
    }

    private static AmbientFighterEntity spawn(ServerPlayer player, BlockPos anchor, FighterAlignment alignment,
                                               FighterRank rank, FighterPersonality personality) {
        return AmbientFighterSpawner.spawnAroundAnchor(player, anchor, alignment, rank, personality, 3, 8);
    }

    private static boolean complete(AmbientFighterEntity... fighters) {
        for (AmbientFighterEntity fighter : fighters) if (fighter == null) return false;
        return true;
    }

    /** Returns zero so partial failed scenes never count as successfully spawned. */
    private static int cleanup(AmbientFighterEntity... fighters) {
        for (AmbientFighterEntity fighter : fighters) {
            if (fighter != null && fighter.isAlive()) fighter.discard();
        }
        return 0;
    }
}
