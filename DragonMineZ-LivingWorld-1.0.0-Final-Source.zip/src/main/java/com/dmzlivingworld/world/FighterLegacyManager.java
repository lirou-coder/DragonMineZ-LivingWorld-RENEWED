package com.dmzlivingworld.world;

import com.dmzlivingworld.LivingWorldMod;
import com.dmzlivingworld.entity.AmbientFighterEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Records only events that actually happened in-world. */
@Mod.EventBusSubscriber(modid = LivingWorldMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class FighterLegacyManager {
    private static final String FUSION_BACKUP = "DMZLWFusionPartnerState";
    private FighterLegacyManager() {}

    public static void recordConcession(AmbientFighterEntity victor, AmbientFighterEntity defeated) {
        if (victor == null || defeated == null || victor.level().isClientSide) return;
        victor.recordLegacyBattle(defeated.getFighterName(), defeated.getBattlePower(), true, false, false);
        defeated.recordLegacyBattle(victor.getFighterName(), victor.getBattlePower(), false, false, false);
        FighterGoalManager.onBattleVictory(victor, defeated);
        // Technique lineage emerges from real training/rival fights. A student can learn
        // from their mentor after the round; a surviving rival may copy something they saw.
        if (defeated.getMentorName().equals(victor.getFighterName()) && defeated.getRandom().nextFloat() < 0.45F) {
            FighterTechniqueManager.tryLearnFrom(defeated, victor, "mentor sparring");
        } else if (defeated.getRivalName().equals(victor.getFighterName()) && defeated.getRandom().nextFloat() < 0.18F) {
            FighterTechniqueManager.tryLearnFrom(defeated, victor, "rival observation");
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        Entity attacker = event.getSource().getEntity();
        if (event.getEntity() instanceof AmbientFighterEntity victim && victim.level() instanceof ServerLevel level) {
            if (victim.getPersistentData().contains("DMZLWNpcFusionTemp", Tag.TAG_COMPOUND)
                    && victim.getPersistentData().getCompound("DMZLWNpcFusionTemp").getBoolean("Active")) return;
            String killerName = attacker == null ? "" : attacker.getName().getString();
            AmbientFighterEntity heir = FighterArsenalManager.inheritFromFallen(victim);
            if (heir != null && heir.getMentorName().equals(victim.getFighterName()) && heir.getRandom().nextFloat() < 0.65F) {
                FighterTechniqueManager.tryLearnFrom(heir, victim, "inheritance");
            }
            int killerPower = 0;
            boolean killerIsPlayer = false;
            if (attacker instanceof AmbientFighterEntity other) {
                killerPower = other.getBattlePower();
                other.recordLegacyBattle(victim.getFighterName(), victim.getBattlePower(), true, true, false);
                FighterGoalManager.onBattleVictory(other, victim);
            } else if (attacker instanceof ServerPlayer player) {
                killerPower = (int)Math.min(Integer.MAX_VALUE - 1L, Math.round(PlayerWorldManager.playerBattlePower(player)));
                killerIsPlayer = true;
            }
            victim.recordLegacyBattle(killerName.isBlank() ? "Unknown" : killerName, killerPower, false, true, killerIsPlayer);
            FighterLegacyWorldData legacyWorld = FighterLegacyWorldData.get(level);
            legacyWorld.markDeadRecord(victim.getMemoryRecordId());
            legacyWorld.archive(victim, killerName, level.getServer().overworld().getGameTime());
            return;
        }

        if (event.getEntity() instanceof ServerPlayer player && attacker instanceof AmbientFighterEntity fighter) {
            int playerPower = (int)Math.min(Integer.MAX_VALUE - 1L, Math.round(PlayerWorldManager.playerBattlePower(player)));
            fighter.recordLegacyBattle(player.getGameProfile().getName(), playerPower, true, false, true);
        }
    }

    /**
     * Optional Fusion Bridge integration without a hard dependency. The bridge
     * already writes a crash-safe partner-state tag; LW simply observes the
     * transition once and records the real participant.
     */
    public static void tickFusionObservation(AmbientFighterEntity fighter) {
        if (fighter == null || fighter.level().isClientSide || fighter.tickCount % 20 != 0) return;
        CompoundTag persistent = fighter.getPersistentData();
        boolean active = persistent.contains(FUSION_BACKUP, Tag.TAG_COMPOUND)
                && persistent.getCompound(FUSION_BACKUP).getBoolean("Active");
        CompoundTag legacy = fighter.getLegacyData();
        boolean seen = legacy.getBoolean("FusionSessionSeen");
        if (!active) {
            if (seen) legacy.putBoolean("FusionSessionSeen", false);
            return;
        }
        if (seen) return;

        CompoundTag backup = persistent.getCompound(FUSION_BACKUP);
        String partner = "unknown partner";
        if (backup.hasUUID("Host") && fighter.level() instanceof ServerLevel level) {
            ServerPlayer host = level.getServer().getPlayerList().getPlayer(backup.getUUID("Host"));
            if (host != null) partner = host.getGameProfile().getName();
        } else if (backup.hasUUID("PairOther") && fighter.level() instanceof ServerLevel level) {
            Entity other = level.getEntity(backup.getUUID("PairOther"));
            if (other != null) partner = other.getName().getString();
        }
        fighter.recordFusion(partner);
        legacy.putBoolean("FusionSessionSeen", true);
    }

    public static boolean isNotable(AmbientFighterEntity fighter) {
        if (fighter == null) return false;
        CompoundTag l = fighter.getLegacyData();
        return fighter.isRemembered() || fighter.isFactionLeader() || l.getInt("Fights") >= 3
                || l.getInt("NemesisStage") > 0 || l.getInt("Fusions") > 0
                || !FighterArsenalManager.summary(fighter).equals("none");
    }
}
