package com.dmzlivingworld.world;

import com.dmzlivingworld.LivingWorldMod;
import com.dmzlivingworld.entity.AmbientFighterEntity;
import com.dmzlivingworld.entity.FighterPersonality;
import com.dragonminez.common.stats.StatsCapability;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

/** Player-facing memory: discovery, rumors and the world's broad perception of the player. */
@Mod.EventBusSubscriber(modid = LivingWorldMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PlayerWorldManager {
    private static final String ROOT = "DMZLivingWorldPlayerWorld";
    private static final String DISCOVERED = "DiscoveredFactions";
    private static final String RUMORS = "Rumors";

    private PlayerWorldManager() {}

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)
                || !(player.level() instanceof ServerLevel level) || !LivingWorldDimensions.isSupported(level)) return;
        long now = level.getServer().overworld().getGameTime();
        PeacekeeperManager.tickPlayer(player);
        int offset = Math.floorMod(player.getUUID().hashCode(), 100);
        if (Math.floorMod((int)(now % 100L), 100) == offset) {
            for (AmbientFighterEntity fighter : level.getEntitiesOfClass(AmbientFighterEntity.class,
                    player.getBoundingBox().inflate(96.0D), f -> f.isAlive() && f.isFactionMember())) {
                WorldFaction faction = FactionManager.byId(level, fighter.getFactionId());
                if (faction != null) discoverFaction(player, faction);
            }
        }
        // Rumors are intentionally slow: at most one meaningful whisper every ~2 MC days.
        CompoundTag root = root(player);
        long next = root.getLong("NextRumor");
        if (now >= next && Math.floorMod(now + player.getUUID().hashCode(), 1200L) == 0L) {
            root.putLong("NextRumor", now + 36000L + player.getRandom().nextInt(24001));
            tryLearnRumor(player, level);
            save(player, root);
        }
    }

    public static void discoverFaction(ServerPlayer player, WorldFaction faction) {
        if (player == null || faction == null) return;
        CompoundTag root = root(player);
        ListTag list = root.getList(DISCOVERED, Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) if (faction.id().equals(list.getString(i))) return;
        list.add(StringTag.valueOf(faction.id()));
        root.put(DISCOVERED, list);
        save(player, root);
    }

    public static boolean knowsFaction(ServerPlayer player, WorldFaction faction) {
        if (player == null || faction == null) return false;
        ListTag list = root(player).getList(DISCOVERED, Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) if (faction.id().equals(list.getString(i))) return true;
        return false;
    }

    public static void addHeroic(ServerPlayer player, int amount) { adjust(player, "Heroic", amount); }
    public static void addInfamy(ServerPlayer player, int amount) { adjust(player, "Infamy", amount); }
    public static void addFame(ServerPlayer player, int amount) { adjust(player, "Fame", amount); }
    public static int heroic(ServerPlayer player) { return root(player).getInt("Heroic"); }
    public static int infamy(ServerPlayer player) { return root(player).getInt("Infamy"); }
    public static int fame(ServerPlayer player) { return root(player).getInt("Fame"); }

    public static double playerBattlePower(ServerPlayer player) {
        if (player == null) return 1.0D;
        final double[] out = {1.0D};
        player.getCapability(StatsCapability.INSTANCE).ifPresent(stats -> out[0] = Math.max(1.0D, stats.getBattlePowerExact()));
        return out[0];
    }

    /** Weak hostile NPCs sometimes recognize that attacking a famous monster is suicidal. */
    public static boolean shouldFearPlayer(AmbientFighterEntity fighter, ServerPlayer player) {
        if (fighter == null || player == null || fame(player) < 18) return false;
        if (fighter.getPersonality() == FighterPersonality.PROUD || fighter.getPersonality() == FighterPersonality.AGGRESSIVE) return false;
        double ratio = playerBattlePower(player) / Math.max(1.0D, fighter.getBattlePower());
        if (ratio < 2.8D) return false;
        long day = player.serverLevel().getServer().overworld().getGameTime() / 24000L;
        long stable = FactionWorldData.mix(fighter.getUUID().getMostSignificantBits() ^ player.getUUID().getLeastSignificantBits() ^ day);
        return Math.floorMod(stable, 100L) < Math.min(88L, 48L + fame(player));
    }

    public static String reputationTitle(ServerPlayer player) {
        int hero = heroic(player), bad = infamy(player), fame = fame(player);
        if (bad >= 60 && bad > hero + 20) return "Feared Destroyer";
        if (bad >= 30 && bad > hero) return "Dangerous Name";
        if (hero >= 70) return "Known Protector";
        if (hero >= 35) return "Trusted Fighter";
        if (fame >= 55) return "Renowned Martial Artist";
        if (fame >= 22) return "Rising Fighter";
        return "Unknown Wanderer";
    }

    public static List<String> rumors(ServerPlayer player) {
        ListTag list = root(player).getList(RUMORS, Tag.TAG_STRING);
        List<String> out = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) out.add(list.getString(i));
        return out;
    }

    private static void tryLearnRumor(ServerPlayer player, ServerLevel level) {
        // Rumors only travel through a friendly local presence.
        AmbientFighterEntity source = level.getEntitiesOfClass(AmbientFighterEntity.class,
                player.getBoundingBox().inflate(72.0D), f -> f.isAlive() && f.isFactionMember()
                        && FactionManager.getReputation(player, f.getFactionId()) >= FactionManager.FRIENDLY_REP)
                .stream().findAny().orElse(null);
        if (source == null) return;
        FactionWorldData data = FactionWorldData.get(level);
        long now = level.getServer().overworld().getGameTime();
        List<WorldFaction> candidates = data.activeFactions().stream().filter(f -> f.realm() == LivingWorldDimensions.realm(level)).toList();
        if (candidates.isEmpty()) return;
        WorldFaction faction = candidates.get(player.getRandom().nextInt(candidates.size()));
        discoverFaction(player, faction);
        String rumor;
        List<WorldFaction> wars = data.warEnemies(faction, now);
        if (!wars.isEmpty()) rumor = "Word is spreading: " + faction.name() + " is at war with " + wars.get(0).name() + ".";
        else {
            List<String> history = data.history(faction);
            rumor = history.isEmpty() ? "People have been talking about " + faction.name() + " on " + faction.realm().displayName() + "."
                    : "Rumor: " + history.get(history.size() - 1);
        }
        addRumor(player, rumor);
        if (source.getSpeech().isEmpty()) source.speak("I heard something you might want to know.", 64);
    }

    private static void addRumor(ServerPlayer player, String rumor) {
        CompoundTag root = root(player);
        ListTag list = root.getList(RUMORS, Tag.TAG_STRING);
        if (!list.isEmpty() && list.getString(list.size() - 1).equals(rumor)) return;
        list.add(StringTag.valueOf(rumor));
        while (list.size() > 8) list.remove(0);
        root.put(RUMORS, list);
        save(player, root);
    }

    private static void adjust(ServerPlayer player, String key, int delta) {
        if (player == null || delta == 0) return;
        CompoundTag root = root(player);
        root.putInt(key, Math.max(0, Math.min(100, root.getInt(key) + delta)));
        save(player, root);
    }

    private static CompoundTag root(ServerPlayer player) {
        CompoundTag persistent = player.getPersistentData();
        if (!persistent.contains(ROOT, Tag.TAG_COMPOUND)) persistent.put(ROOT, new CompoundTag());
        CompoundTag root = persistent.getCompound(ROOT);
        if (!root.contains(DISCOVERED, Tag.TAG_LIST)) root.put(DISCOVERED, new ListTag());
        if (!root.contains(RUMORS, Tag.TAG_LIST)) root.put(RUMORS, new ListTag());
        return root;
    }

    private static void save(ServerPlayer player, CompoundTag root) { player.getPersistentData().put(ROOT, root); }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (!(event.getOriginal() instanceof ServerPlayer old) || !(event.getEntity() instanceof ServerPlayer copy)) return;
        if (old.getPersistentData().contains(ROOT, Tag.TAG_COMPOUND))
            copy.getPersistentData().put(ROOT, old.getPersistentData().getCompound(ROOT).copy());
    }
}
