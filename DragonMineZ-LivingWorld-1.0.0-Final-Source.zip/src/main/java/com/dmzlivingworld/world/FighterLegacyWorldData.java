package com.dmzlivingworld.world;

import com.dmzlivingworld.entity.AmbientFighterEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.List;

/**
 * Compact world archive for notable fallen Living World fighters.
 * This is SavedData only: removing Living World leaves an inert data file and
 * does not strand any registry objects in the save.
 */
public final class FighterLegacyWorldData extends SavedData {
    private static final String DATA_NAME = "dmzlivingworld_fighter_legacy_v1";
    private static final int MAX_FALLEN = 64;
    private static final int MAX_DEAD_RECORD_IDS = 2048;

    private final List<CompoundTag> fallen;
    private final List<java.util.UUID> deadRecordIds;

    private FighterLegacyWorldData(List<CompoundTag> fallen, List<java.util.UUID> deadRecordIds) {
        this.fallen = fallen;
        this.deadRecordIds = deadRecordIds;
    }

    public static FighterLegacyWorldData get(ServerLevel anyLevel) {
        ServerLevel overworld = anyLevel.getServer().overworld();
        return overworld.getDataStorage().computeIfAbsent(
                FighterLegacyWorldData::load,
                () -> new FighterLegacyWorldData(new ArrayList<>(), new ArrayList<>()),
                DATA_NAME);
    }

    private static FighterLegacyWorldData load(CompoundTag tag) {
        List<CompoundTag> out = new ArrayList<>();
        ListTag list = tag.getList("Fallen", Tag.TAG_COMPOUND);
        int start = Math.max(0, list.size() - MAX_FALLEN);
        for (int i = start; i < list.size(); i++) out.add(sanitizeRecord(list.getCompound(i)));
        List<java.util.UUID> dead = new ArrayList<>();
        ListTag deadList = tag.getList("DeadRecords", Tag.TAG_COMPOUND);
        int deadStart = Math.max(0, deadList.size() - MAX_DEAD_RECORD_IDS);
        for (int i = deadStart; i < deadList.size(); i++) {
            CompoundTag entry = deadList.getCompound(i);
            if (entry.hasUUID("Id")) {
                java.util.UUID id = entry.getUUID("Id");
                if (!dead.contains(id)) dead.add(id);
            }
        }
        return new FighterLegacyWorldData(out, dead);
    }

    private static CompoundTag sanitizeRecord(CompoundTag raw) {
        CompoundTag r = new CompoundTag();
        r.putString("Name", limit(raw.getString("Name"), 64));
        r.putString("Race", limit(raw.getString("Race"), 32));
        r.putInt("BattlePower", Math.max(0, raw.getInt("BattlePower")));
        r.putString("Title", limit(raw.getString("Title"), 48));
        r.putString("Summary", limit(raw.getString("Summary"), 192));
        r.putString("Equipment", limit(raw.getString("Equipment"), 192));
        r.putString("Killer", limit(raw.getString("Killer"), 64));
        r.putLong("FallenAt", Math.max(0L, raw.getLong("FallenAt")));
        return r;
    }

    private static String limit(String value, int max) {
        if (value == null) return "";
        return value.length() <= max ? value : value.substring(0, max);
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (CompoundTag record : fallen) list.add(record.copy());
        tag.put("Fallen", list);
        ListTag dead = new ListTag();
        for (java.util.UUID id : deadRecordIds) {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("Id", id);
            dead.add(entry);
        }
        tag.put("DeadRecords", dead);
        return tag;
    }

    public void markDeadRecord(java.util.UUID recordId) {
        if (recordId == null || deadRecordIds.contains(recordId)) return;
        deadRecordIds.add(recordId);
        while (deadRecordIds.size() > MAX_DEAD_RECORD_IDS) deadRecordIds.remove(0);
        setDirty();
    }

    public boolean isDeadRecord(java.util.UUID recordId) {
        return recordId != null && deadRecordIds.contains(recordId);
    }

    public void archive(AmbientFighterEntity fighter, String killerName, long gameTime) {
        if (fighter == null || !FighterLegacyManager.isNotable(fighter)) return;
        CompoundTag record = new CompoundTag();
        record.putString("Name", fighter.getFighterName());
        record.putString("Race", fighter.getRace().displayName());
        record.putInt("BattlePower", fighter.getBattlePower());
        record.putString("Title", fighter.getLegacyTitle());
        record.putString("Summary", fighter.getLegacySummary());
        record.putString("Equipment", FighterArsenalManager.summary(fighter));
        record.putString("Killer", killerName == null ? "" : killerName);
        record.putLong("FallenAt", gameTime);
        fallen.add(record);
        while (fallen.size() > MAX_FALLEN) fallen.remove(0);
        setDirty();
    }

    public List<String> recentLines(int limit) {
        List<String> out = new ArrayList<>();
        int start = Math.max(0, fallen.size() - Math.max(1, limit));
        for (int i = fallen.size() - 1; i >= start; i--) {
            CompoundTag r = fallen.get(i);
            String title = r.getString("Title");
            String line = "† " + (title.isBlank() ? "" : title + " ") + r.getString("Name")
                    + " — " + r.getString("Race") + " • PL " + r.getInt("BattlePower");
            String killer = r.getString("Killer");
            if (!killer.isBlank()) line += " • fell to " + killer;
            out.add(line);
        }
        return out;
    }

    public int count() { return fallen.size(); }
}
