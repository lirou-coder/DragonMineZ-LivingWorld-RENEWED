package com.dmzlivingworld.world;

import com.dmzlivingworld.LivingWorldMod;
import com.dmzlivingworld.entity.AmbientFighterEntity;
import com.dmzlivingworld.entity.FighterAlignment;
import com.dmzlivingworld.entity.FighterRank;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

/**
 * Lightweight per-player world memory. Only a handful of meaningful fighters are
 * retained as records; ordinary ambient population remains disposable/despawnable.
 */
@Mod.EventBusSubscriber(modid = LivingWorldMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class FighterMemoryManager {
    private static final String ROOT_KEY = "DMZLivingWorldMemory";
    private static final String RIVALS_KEY = "KnownFighters";
    private static final int MAX_RECORDS = 12;
    private static final int MEMORY_DATA_VERSION = 2;

    private FighterMemoryManager() {}

    public static void rememberEscape(ServerPlayer player, AmbientFighterEntity fighter) {
        if (player == null || fighter == null || !fighter.isAlive() || fighter.isFactionLeader()) return;
        if (!fighter.isRemembered()) {
            float chance = switch (fighter.getRank()) {
                case ROOKIE -> 0.18F;
                case TRAINED -> 0.46F;
                case VETERAN -> 0.82F;
            };
            if (fighter.getRandom().nextFloat() > chance) return;
        }
        int relationshipDelta = fighter.getAlignment() == FighterAlignment.BAD ? -28 : 12;
        CompoundTag record = upsert(player, fighter, relationshipDelta, false, "Escaped your fight", false);
        if (record != null && fighter.getAlignment() == FighterAlignment.BAD) noteNemesisEncounter(player, fighter, record, false);
        if (fighter.getSpeech().isEmpty()) {
            fighter.speak(fighter.getAlignment() == FighterAlignment.BAD ? "I'll remember you." : "We'll meet again.", 62);
        }
    }

    public static void rememberRescue(ServerPlayer player, AmbientFighterEntity fighter) {
        if (player == null || fighter == null || !fighter.isAlive()) return;
        FactionManager.onMemberRescued(player, fighter);
        if (fighter.isFactionLeader()) return;
        upsert(player, fighter, 70, true, "Rescued from Frieza", true);
    }

    public static void rememberPlayerDefeat(ServerPlayer player, AmbientFighterEntity fighter) {
        if (player == null || fighter == null || !fighter.isAlive() || fighter.isFactionLeader()) return;
        if (!fighter.isRemembered() && fighter.getRank() == FighterRank.ROOKIE && fighter.getRandom().nextFloat() > 0.45F) return;
        CompoundTag record = upsert(player, fighter,
                fighter.getAlignment() == FighterAlignment.BAD ? -35 : 18,
                false, "Defeated you", true);
        if (record != null) {
            noteNemesisEncounter(player, fighter, record, true);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        Entity attacker = event.getSource().getEntity();
        if (event.getEntity() instanceof ServerPlayer player && attacker instanceof AmbientFighterEntity fighter) {
            rememberPlayerDefeat(player, fighter);
            return;
        }
        if (event.getEntity() instanceof AmbientFighterEntity fighter && attacker instanceof ServerPlayer player) {
            forgetIfKilled(player, fighter);
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (!(event.getOriginal() instanceof ServerPlayer original) || !(event.getEntity() instanceof ServerPlayer copy)) return;
        CompoundTag old = original.getPersistentData();
        if (old.contains(ROOT_KEY, Tag.TAG_COMPOUND)) {
            copy.getPersistentData().put(ROOT_KEY, old.getCompound(ROOT_KEY).copy());
        }
    }

    /** Called by natural population before creating a fresh stranger. */
    public static boolean trySpawnRecurring(ServerPlayer player, boolean force) {
        if (!(player.level() instanceof ServerLevel level) || !LivingWorldDimensions.isSupported(level)) return false;
        CompoundTag root = getRoot(player);
        ListTag list = root.getList(RIVALS_KEY, Tag.TAG_COMPOUND);
        if (list.isEmpty()) return false;

        long now = level.getGameTime();
        int start = player.getRandom().nextInt(list.size());
        for (int offset = 0; offset < list.size(); offset++) {
            int index = (start + offset) % list.size();
            CompoundTag record = list.getCompound(index);
            if (!force && now < record.getLong("NextEligible")) continue;
            if (!record.hasUUID("RecordId") || !record.contains("Profile", Tag.TAG_COMPOUND)) continue;
            UUID recordId = record.getUUID("RecordId");
            if (isRecordAlreadyLoaded(player, recordId)) continue;

            CompoundTag profile = record.getCompound("Profile").copy();
            // Affiliated recurring characters remain tied to their organization's home
            // realm. Independent rivals can reappear on either supported world.
            if (profile.contains("FactionId")) {
                WorldFaction faction = FactionManager.byId(level, profile.getString("FactionId"));
                if (faction != null && faction.realm() != LivingWorldDimensions.realm(level)) continue;
            }
            int evolvedPower = evolvePower(level, player, profile.getInt("BattlePower"), record.getInt("Encounters"));
            profile.putInt("BattlePower", evolvedPower);
            AmbientFighterEntity fighter = AmbientFighterSpawner.spawnRemembered(
                    player, profile, recordId, record.getInt("Encounters") + 1,
                    record.getInt("Relationship"), record.getBoolean("Rescued"), force);
            if (fighter == null) continue;
            syncNemesisState(player, fighter, record);

            record.putInt("Encounters", record.getInt("Encounters") + 1);
            record.putLong("LastSeen", now);
            record.putLong("NextEligible", now + 12000L + player.getRandom().nextInt(18001));
            record.put("Profile", fighter.writeMemoryProfile());
            list.set(index, record);
            root.put(RIVALS_KEY, list);
            saveRoot(player, root);

            String line;
            if (record.getBoolean("Rescued")) line = "I remember you. You saved me.";
            else if (record.getInt("Relationship") <= -20) line = "You again. Good.";
            else line = "We meet again.";
            fighter.speak(line, 78);
            if (record.getInt("Relationship") <= -25 && fighter.getAlignment() == FighterAlignment.BAD) {
                fighter.setTarget(player);
            }
            return true;
        }
        return false;
    }


    public static void strengthenRelationship(ServerPlayer player, AmbientFighterEntity fighter, int delta, String outcome) {
        if (player == null || fighter == null || !fighter.isAlive() || fighter.isFactionLeader()) return;
        upsert(player, fighter, delta, fighter.wasRescuedByMemoryOwner(), outcome == null ? "Spent time together" : outcome, true);
    }

    public static java.util.List<String> peopleLines(ServerPlayer player) {
        java.util.List<String> out = new java.util.ArrayList<>();
        ListTag list = getRoot(player).getList(RIVALS_KEY, Tag.TAG_COMPOUND);
        if (list.isEmpty()) {
            out.add(". You have not formed any lasting bonds yet.");
            return out;
        }
        for (int i = 0; i < list.size(); i++) {
            CompoundTag record = list.getCompound(i);
            CompoundTag profile = record.getCompound("Profile");
            int rel = record.getInt("Relationship");
            String bond = rel >= 70 ? "Close ally" : rel >= 40 ? "Friend" : rel >= 15 ? "Familiar" : rel <= -35 ? "Enemy" : rel < 0 ? "Tense" : "Known fighter";
            String faction = profile.getString("FactionName");
            String role = profile.getString("FactionTitle");
            String extra = faction.isBlank() ? "Independent" : (role.isBlank() ? faction : role + " • " + faction);
            String title = profile.getString("LegacyTitle");
            String gear = FighterArsenalManager.summaryProfile(profile);
            out.add((rel >= 40 ? "+ " : rel < 0 ? "!! " : "* ") + (title.isBlank() ? "" : title + " ")
                    + profile.getString("Name") + " — " + bond + " • " + extra + " • PL " + profile.getInt("BattlePower")
                    + " • met " + Math.max(1, record.getInt("Encounters")) + "x" + (gear.equals("none") ? "" : " • gear: " + gear));
            if (record.getBoolean("Rescued")) out.add(". You rescued " + profile.getString("Name") + " from Frieza forces.");
            if (record.getInt("NemesisStage") > 0) out.add("!! Rivalry level " + record.getInt("NemesisStage")
                    + "/5 • battles with you " + record.getInt("BattlesVsPlayer") + " • wins over you " + record.getInt("WinsVsPlayer"));
            String outcome = record.getString("LastOutcome");
            if (!outcome.isBlank()) out.add(". Last notable bond event: " + outcome + ".");
        }
        return out;
    }

    public static boolean rememberForDebug(ServerPlayer player, AmbientFighterEntity fighter) {
        if (player == null || fighter == null || !fighter.isAlive() || fighter.isFactionLeader()) return false;
        return upsert(player, fighter, 5, false, "Marked for testing", true) != null;
    }

    public static String status(ServerPlayer player) {
        ListTag list = getRoot(player).getList(RIVALS_KEY, Tag.TAG_COMPOUND);
        if (list.isEmpty()) return "No recurring fighters are remembered yet.";
        StringBuilder out = new StringBuilder("Known fighters: ").append(list.size()).append('/').append(MAX_RECORDS).append(" — ");
        for (int i = 0; i < list.size(); i++) {
            CompoundTag record = list.getCompound(i);
            CompoundTag profile = record.getCompound("Profile");
            if (i > 0) out.append(" | ");
            out.append(profile.getString("Name"))
                    .append(" (PL ").append(profile.getInt("BattlePower"))
                    .append(", met ").append(Math.max(1, record.getInt("Encounters"))).append('x');
            if (record.getBoolean("Rescued")) out.append(", rescued");
            if (record.getInt("NemesisStage") > 0) out.append(", rivalry ").append(record.getInt("NemesisStage")).append("/5");
            out.append(')');
        }
        return out.toString();
    }

    /** Debug only: advances one real rivalry encounter using the same progression path. */
    public static boolean forceNemesisProgress(ServerPlayer player, AmbientFighterEntity fighter) {
        if (player == null || fighter == null || !fighter.isAlive() || fighter.getAlignment() != FighterAlignment.BAD) return false;
        CompoundTag record = upsert(player, fighter, -25, false, "Debug rivalry encounter", true);
        if (record == null) return false;
        // Debug should be observable: one command advances exactly one stage. Natural
        // gameplay still uses the real 2/3/5/7/10 battle thresholds below.
        int stage = clamp(record.getInt("NemesisStage"), 0, 5);
        int[] thresholds = {2, 3, 5, 7, 10};
        if (stage < 5) record.putInt("BattlesVsPlayer", Math.max(record.getInt("BattlesVsPlayer"), thresholds[stage] - 1));
        noteNemesisEncounter(player, fighter, record, false);
        return true;
    }

    public static int count(ServerPlayer player) {
        return getRoot(player).getList(RIVALS_KEY, Tag.TAG_COMPOUND).size();
    }

    public static boolean summonKnown(ServerPlayer player) {
        return trySpawnRecurring(player, true);
    }

    public static void clear(ServerPlayer player) {
        CompoundTag root = getRoot(player);
        root.put(RIVALS_KEY, new ListTag());
        saveRoot(player, root);
    }

    private static CompoundTag upsert(ServerPlayer player, AmbientFighterEntity fighter, int relationshipDelta,
                                      boolean rescued, String outcome, boolean forceCreate) {
        CompoundTag root = getRoot(player);
        ListTag list = root.getList(RIVALS_KEY, Tag.TAG_COMPOUND);
        int index = findRecordIndex(list, fighter.getMemoryRecordId());

        if (index < 0 && !forceCreate && list.size() >= MAX_RECORDS) return null;
        if (index < 0 && list.size() >= MAX_RECORDS) {
            index = oldestRecordIndex(list);
            list.remove(index);
            index = -1;
        }

        CompoundTag record = index >= 0 ? list.getCompound(index) : new CompoundTag();
        UUID recordId = record.hasUUID("RecordId") ? record.getUUID("RecordId") : UUID.randomUUID();
        int encounters = Math.max(1, record.getInt("Encounters"));
        if (index < 0) encounters = 1;

        record.putUUID("RecordId", recordId);
        record.put("Profile", fighter.writeMemoryProfile());
        record.putInt("Relationship", clamp(record.getInt("Relationship") + relationshipDelta, -100, 100));
        record.putBoolean("Rescued", rescued || record.getBoolean("Rescued"));
        record.putInt("Encounters", encounters);
        record.putString("LastOutcome", outcome);
        long now = player.serverLevel().getGameTime();
        record.putLong("LastSeen", now);
        record.putLong("NextEligible", now + 12000L + player.getRandom().nextInt(18001));

        if (index >= 0) list.set(index, record); else list.add(record);
        root.put(RIVALS_KEY, list);
        saveRoot(player, root);
        fighter.bindMemory(player.getUUID(), recordId, encounters, record.getInt("Relationship"), record.getBoolean("Rescued"));
        return record;
    }

    public static void refreshLoadedProfile(AmbientFighterEntity fighter) {
        if (fighter == null || !fighter.isRemembered() || fighter.getMemoryOwnerId() == null
                || !(fighter.level() instanceof ServerLevel level)) return;
        ServerPlayer owner = level.getServer().getPlayerList().getPlayer(fighter.getMemoryOwnerId());
        if (owner == null) return;
        CompoundTag root = getRoot(owner);
        ListTag list = root.getList(RIVALS_KEY, Tag.TAG_COMPOUND);
        int index = findRecordIndex(list, fighter.getMemoryRecordId());
        if (index < 0) return;
        CompoundTag record = list.getCompound(index);
        record.put("Profile", fighter.writeMemoryProfile());
        list.set(index, record);
        root.put(RIVALS_KEY, list);
        saveRoot(owner, root);
    }

    private static void saveRecord(ServerPlayer player, CompoundTag updated) {
        if (!updated.hasUUID("RecordId")) return;
        CompoundTag root = getRoot(player);
        ListTag list = root.getList(RIVALS_KEY, Tag.TAG_COMPOUND);
        int index = findRecordIndex(list, updated.getUUID("RecordId"));
        if (index >= 0) list.set(index, updated);
        root.put(RIVALS_KEY, list);
        saveRoot(player, root);
    }

    private static void forgetIfKilled(ServerPlayer player, AmbientFighterEntity fighter) {
        UUID recordId = fighter.getMemoryRecordId();
        if (recordId == null) return;
        CompoundTag root = getRoot(player);
        ListTag list = root.getList(RIVALS_KEY, Tag.TAG_COMPOUND);
        int index = findRecordIndex(list, recordId);
        if (index < 0) return;
        String name = list.getCompound(index).getCompound("Profile").getString("Name");
        list.remove(index);
        root.put(RIVALS_KEY, list);
        saveRoot(player, root);
        player.displayClientMessage(Component.literal("[Living World] ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal(name + " will not return.").withStyle(ChatFormatting.DARK_GRAY)), false);
    }

    private static boolean isRecordAlreadyLoaded(ServerPlayer player, UUID recordId) {
        return !player.level().getEntitiesOfClass(AmbientFighterEntity.class,
                player.getBoundingBox().inflate(512.0D),
                fighter -> recordId.equals(fighter.getMemoryRecordId())).isEmpty();
    }

    private static int evolvePower(ServerLevel level, ServerPlayer player, int oldPower, int encounters) {
        // Recurring people improve because time/encounters passed, not because the player
        // became stronger. The world anchor is only a ceiling, never a catch-up floor.
        double growth = 1.018D + Math.min(0.050D, encounters * 0.006D) + player.getRandom().nextDouble() * 0.018D;
        double anchor = WorldPowerScaler.resolveWorldAnchor(level, player.blockPosition());
        double grown = oldPower * growth;
        return (int)Math.min(Integer.MAX_VALUE - 1L, Math.max(120L, Math.round(Math.min(grown, Math.max(oldPower, anchor * 3.2D)))));
    }

    private static void noteNemesisEncounter(ServerPlayer player, AmbientFighterEntity fighter, CompoundTag record, boolean fighterWon) {
        if (player == null || fighter == null || record == null || fighter.getAlignment() != FighterAlignment.BAD) return;
        int battles = record.getInt("BattlesVsPlayer") + 1;
        int wins = record.getInt("WinsVsPlayer") + (fighterWon ? 1 : 0);
        record.putInt("BattlesVsPlayer", battles);
        record.putInt("WinsVsPlayer", wins);

        int oldStage = record.getInt("NemesisStage");
        int stage = oldStage;
        int[] thresholds = {2, 3, 5, 7, 10};
        while (stage < 5 && battles >= thresholds[stage]) stage++;
        record.putInt("NemesisStage", stage);
        if (stage > oldStage) {
            // Use Living World's existing diminishing training progression. This is
            // earned adaptation, not rubber-band scaling to player BP.
            fighter.applyTrainingGrowth(520 + stage * 190, false);
            FighterArsenalManager.applyNemesisUpgrade(fighter, stage);
            fighter.recordLegacyEvent("Rivalry with " + player.getGameProfile().getName() + " reached stage " + stage);
            if (fighter.getSpeech().isEmpty()) {
                fighter.speak(stage >= 4 ? "I've been preparing for you." : "I learned from our last fight.", 72);
            }
        }
        fighter.setNemesisState(player.getUUID(), player.getGameProfile().getName(), stage, battles, wins);
        record.put("Profile", fighter.writeMemoryProfile());
        saveRecord(player, record);
    }

    private static void syncNemesisState(ServerPlayer player, AmbientFighterEntity fighter, CompoundTag record) {
        if (player == null || fighter == null || record == null) return;
        int stage = record.getInt("NemesisStage");
        if (stage <= 0 && record.getInt("BattlesVsPlayer") <= 0) return;
        fighter.setNemesisState(player.getUUID(), player.getGameProfile().getName(), stage,
                record.getInt("BattlesVsPlayer"), record.getInt("WinsVsPlayer"));
    }

    private static int findRecordIndex(ListTag list, UUID recordId) {
        if (recordId == null) return -1;
        for (int i = 0; i < list.size(); i++) {
            CompoundTag record = list.getCompound(i);
            if (record.hasUUID("RecordId") && recordId.equals(record.getUUID("RecordId"))) return i;
        }
        return -1;
    }

    private static int oldestRecordIndex(ListTag list) {
        int index = 0;
        long oldest = Long.MAX_VALUE;
        for (int i = 0; i < list.size(); i++) {
            long seen = list.getCompound(i).getLong("LastSeen");
            if (seen < oldest) {
                oldest = seen;
                index = i;
            }
        }
        return index;
    }

    private static CompoundTag getRoot(ServerPlayer player) {
        CompoundTag persistent = player.getPersistentData();
        if (!persistent.contains(ROOT_KEY, Tag.TAG_COMPOUND)) persistent.put(ROOT_KEY, new CompoundTag());
        CompoundTag root = persistent.getCompound(ROOT_KEY);
        sanitizeRoot(root);
        purgeDeadRecords(player, root);
        return root;
    }

    private static void purgeDeadRecords(ServerPlayer player, CompoundTag root) {
        if (!(player.level() instanceof ServerLevel level)) return;
        FighterLegacyWorldData legacy = FighterLegacyWorldData.get(level);
        ListTag list = root.getList(RIVALS_KEY, Tag.TAG_COMPOUND);
        boolean changed = false;
        for (int i = list.size() - 1; i >= 0; i--) {
            CompoundTag record = list.getCompound(i);
            if (record.hasUUID("RecordId") && legacy.isDeadRecord(record.getUUID("RecordId"))) {
                list.remove(i);
                changed = true;
            }
        }
        if (changed) {
            root.put(RIVALS_KEY, list);
            player.getPersistentData().put(ROOT_KEY, root);
        }
    }

    private static void sanitizeRoot(CompoundTag root) {
        if (!root.contains(RIVALS_KEY, Tag.TAG_LIST)) root.put(RIVALS_KEY, new ListTag());
        ListTag source = root.getList(RIVALS_KEY, Tag.TAG_COMPOUND);
        ListTag clean = new ListTag();
        int start = Math.max(0, source.size() - MAX_RECORDS);
        for (int i = start; i < source.size(); i++) {
            CompoundTag r = source.getCompound(i).copy();
            if (!r.hasUUID("RecordId")) r.putUUID("RecordId", UUID.randomUUID());
            r.putInt("Relationship", clamp(r.getInt("Relationship"), -100, 100));
            r.putInt("Encounters", Math.max(1, r.getInt("Encounters")));
            r.putInt("BattlesVsPlayer", Math.max(0, r.getInt("BattlesVsPlayer")));
            r.putInt("WinsVsPlayer", Math.max(0, r.getInt("WinsVsPlayer")));
            r.putInt("NemesisStage", clamp(r.getInt("NemesisStage"), 0, 5));
            r.putLong("LastSeen", Math.max(0L, r.getLong("LastSeen")));
            r.putLong("NextEligible", Math.max(0L, r.getLong("NextEligible")));
            if (r.contains("LastOutcome", Tag.TAG_STRING) && r.getString("LastOutcome").length() > 160)
                r.putString("LastOutcome", r.getString("LastOutcome").substring(0, 160));
            clean.add(r);
        }
        root.put(RIVALS_KEY, clean);
        root.putInt("DataVersion", MEMORY_DATA_VERSION);
    }

    private static void saveRoot(ServerPlayer player, CompoundTag root) {
        player.getPersistentData().put(ROOT_KEY, root);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
