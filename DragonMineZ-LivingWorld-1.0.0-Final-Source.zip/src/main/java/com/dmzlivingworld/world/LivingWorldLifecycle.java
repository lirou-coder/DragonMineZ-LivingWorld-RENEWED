package com.dmzlivingworld.world;

import com.dmzlivingworld.LivingWorldMod;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Clears process-local state between players/worlds; persistent state stays in NBT/SavedData. */
@Mod.EventBusSubscriber(modid = LivingWorldMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class LivingWorldLifecycle {
    private LivingWorldLifecycle() {}

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        PowerSensingManager.clearRuntime(player.getUUID());
        LivingBondManager.clearRuntime(player.getUUID());
        RescueMissionManager.clearRuntime(player);
    }

    @SubscribeEvent
    public static void onStarted(ServerStartedEvent event) { clearProcessState(); }

    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent event) { clearProcessState(); }

    public static String runtimeSummary() {
        return "transient entries — sensing " + PowerSensingManager.runtimeEntries()
                + " • bonds " + LivingBondManager.runtimeEntries()
                + " • rescue " + RescueMissionManager.runtimeEntries()
                + " • combat " + FighterCombatDirector.runtimeEntries()
                + " • faction locks " + FactionActivityRegistry.runtimeEntries();
    }

    private static void clearProcessState() {
        PowerSensingManager.clearRuntime();
        LivingBondManager.clearRuntime();
        RescueMissionManager.clearRuntime();
        FighterCombatDirector.clearRuntime();
        FactionActivityRegistry.clearRuntime();
    }
}
