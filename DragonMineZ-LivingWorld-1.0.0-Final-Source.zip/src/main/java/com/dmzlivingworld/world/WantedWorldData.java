package com.dmzlivingworld.world;

import com.dmzlivingworld.entity.FighterArchetype;
import com.dmzlivingworld.entity.FighterNames;
import com.dmzlivingworld.entity.FighterPersonality;
import com.dmzlivingworld.entity.FighterRace;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.List;

/** Persistent rogues/bounties. They are people in the world, not disposable quest markers. */
public final class WantedWorldData extends SavedData {
    private static final String DATA_NAME = "dmzlivingworld_wanted_v1";
    private static final String[] CRIMES = {
            "attacking travelers", "raiding supply parties", "murdering wandering fighters",
            "betraying former allies", "terrorizing local factions", "stealing Senzu supplies",
            "starting uncontrolled Ki fights", "hunting weaker martial artists", "ambushing patrols",
            "serving as a violent mercenary", "destroying property with Ki blasts"
    };

    private final List<WantedProfile> profiles;
    private long lastSimDay;

    private WantedWorldData(List<WantedProfile> profiles, long lastSimDay) {
        this.profiles = profiles;
        this.lastSimDay = lastSimDay;
    }

    public static WantedWorldData get(ServerLevel anyLevel) {
        ServerLevel overworld = anyLevel.getServer().overworld();
        return overworld.getDataStorage().computeIfAbsent(
                tag -> load(tag, overworld), () -> create(overworld), DATA_NAME);
    }

    private static WantedWorldData create(ServerLevel overworld) {
        List<WantedProfile> list = new ArrayList<>();
        WantedWorldData data = new WantedWorldData(list, -1L);
        int total = 8 + Math.floorMod((int)(overworld.getSeed() >>> 17), 5); // 8-12 living rogues initially.
        for (int i = 0; i < total; i++) {
            FactionRealm realm = i < Math.max(3, Math.round(total * 0.36F)) ? FactionRealm.NAMEK : FactionRealm.EARTH;
            data.addNew(overworld, realm, 0L);
        }
        data.setDirty();
        return data;
    }

    private static WantedWorldData load(CompoundTag tag, ServerLevel overworld) {
        List<WantedProfile> list = new ArrayList<>();
        ListTag saved = tag.getList("Wanted", Tag.TAG_COMPOUND);
        for (int i = 0; i < saved.size(); i++) list.add(WantedProfile.load(saved.getCompound(i)));
        WantedWorldData data = new WantedWorldData(list, tag.contains("LastSimDay") ? tag.getLong("LastSimDay") : -1L);
        if (list.isEmpty()) return create(overworld);
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (WantedProfile profile : profiles) list.add(profile.save());
        tag.put("Wanted", list);
        tag.putLong("LastSimDay", lastSimDay);
        return tag;
    }

    public List<WantedProfile> profiles() { return List.copyOf(profiles); }
    public List<WantedProfile> active(FactionRealm realm) {
        return profiles.stream().filter(p -> p.realm == realm && !p.eliminated).toList();
    }
    public WantedProfile bySlot(int slot) {
        for (WantedProfile p : profiles) if (p.slot == slot) return p;
        return null;
    }
    public WantedProfile byId(String id) {
        for (WantedProfile p : profiles) if (p.id.equals(id)) return p;
        return null;
    }

    public void tick(ServerLevel anyLevel) {
        long gameTime = anyLevel.getServer().overworld().getGameTime();
        long day = Math.max(0L, gameTime / 24000L);
        if (day == lastSimDay) return;
        lastSimDay = day;
        ServerLevel overworld = anyLevel.getServer().overworld();
        int desired = 8 + Math.floorMod((int)(overworld.getSeed() >>> 17), 5);
        long active = profiles.stream().filter(p -> !p.eliminated).count();
        RandomSource random = RandomSource.create(FactionWorldData.mix(overworld.getSeed() ^ day * 0x7F4A7C159E3779B9L));
        if (active < desired && random.nextFloat() < 0.42F) {
            FactionRealm realm = random.nextFloat() < 0.38F ? FactionRealm.NAMEK : FactionRealm.EARTH;
            addNew(overworld, realm, gameTime);
        }
        setDirty();
    }

    public void markSpawned(WantedProfile p, BlockPos pos) {
        p.spawned = true;
        p.lastX = pos.getX(); p.lastY = pos.getY(); p.lastZ = pos.getZ();
        setDirty();
    }

    public void updatePosition(WantedProfile p, BlockPos pos) {
        p.lastX = pos.getX(); p.lastY = pos.getY(); p.lastZ = pos.getZ();
        setDirty();
    }

    public void markEliminated(WantedProfile p, long gameTime) {
        p.eliminated = true;
        p.spawned = false;
        p.eliminatedAt = gameTime;
        setDirty();
    }

    public WantedProfile addNew(ServerLevel overworld, FactionRealm realm, long gameTime) {
        int slot = profiles.stream().mapToInt(p -> p.slot).max().orElse(0) + 1;
        long seed = FactionWorldData.mix(overworld.getSeed() ^ gameTime ^ slot * 0xD1B54A32D192ED03L);
        RandomSource random = RandomSource.create(seed);
        FighterRace race = FactionWorldData.rollFactionRace(random, realm);
        boolean female = race.gendered() && random.nextFloat() < 0.46F;
        String name = FighterNames.roll(random, race, female);
        FighterArchetype style = FighterArchetype.values()[random.nextInt(FighterArchetype.values().length)];
        FighterPersonality personality = random.nextFloat() < 0.55F ? FighterPersonality.AGGRESSIVE
                : random.nextBoolean() ? FighterPersonality.PROUD : FighterPersonality.CAUTIOUS;
        int severity = 2 + random.nextInt(4);
        String crime = CRIMES[random.nextInt(CRIMES.length)];
        int radius = realm == FactionRealm.EARTH ? 900 + random.nextInt(7001) : 700 + random.nextInt(5401);
        double angle = random.nextDouble() * Math.PI * 2.0D;
        BlockPos spawn = overworld.getSharedSpawnPos();
        int bx = realm == FactionRealm.EARTH ? spawn.getX() : 0;
        int bz = realm == FactionRealm.EARTH ? spawn.getZ() : 0;
        WantedProfile p = new WantedProfile(slot, "wanted_" + slot, name, realm, race, female,
                personality, style, severity, crime,
                bx + (int)Math.round(Math.cos(angle) * radius), bz + (int)Math.round(Math.sin(angle) * radius));
        profiles.add(p);
        setDirty();
        return p;
    }

    public static final class WantedProfile {
        public final int slot;
        public final String id;
        public final String name;
        public final FactionRealm realm;
        public final FighterRace race;
        public final boolean female;
        public final FighterPersonality personality;
        public final FighterArchetype archetype;
        public final int severity;
        public final String crime;
        public final int anchorX;
        public final int anchorZ;
        public boolean spawned;
        public boolean eliminated;
        public long eliminatedAt;
        public int lastX;
        public int lastY;
        public int lastZ;

        WantedProfile(int slot, String id, String name, FactionRealm realm, FighterRace race, boolean female,
                      FighterPersonality personality, FighterArchetype archetype, int severity, String crime,
                      int anchorX, int anchorZ) {
            this.slot=slot; this.id=id; this.name=name; this.realm=realm; this.race=race; this.female=female;
            this.personality=personality; this.archetype=archetype; this.severity=severity; this.crime=crime;
            this.anchorX=anchorX; this.anchorZ=anchorZ;
        }

        CompoundTag save() {
            CompoundTag t = new CompoundTag();
            t.putInt("Slot", slot); t.putString("Id", id); t.putString("Name", name); t.putInt("Realm", realm.id());
            t.putInt("Race", race.id()); t.putBoolean("Female", female); t.putInt("Personality", personality.id());
            t.putInt("Archetype", archetype.id()); t.putInt("Severity", severity); t.putString("Crime", crime);
            t.putInt("AnchorX", anchorX); t.putInt("AnchorZ", anchorZ); t.putBoolean("Spawned", spawned);
            t.putBoolean("Eliminated", eliminated); t.putLong("EliminatedAt", eliminatedAt);
            t.putInt("LastX", lastX); t.putInt("LastY", lastY); t.putInt("LastZ", lastZ);
            return t;
        }

        static WantedProfile load(CompoundTag t) {
            WantedProfile p = new WantedProfile(t.getInt("Slot"), t.getString("Id"), t.getString("Name"),
                    FactionRealm.byId(t.getInt("Realm")), FighterRace.byId(t.getInt("Race")), t.getBoolean("Female"),
                    FighterPersonality.byId(t.getInt("Personality")), FighterArchetype.byId(t.getInt("Archetype")),
                    t.getInt("Severity"), t.getString("Crime"), t.getInt("AnchorX"), t.getInt("AnchorZ"));
            p.spawned=t.getBoolean("Spawned"); p.eliminated=t.getBoolean("Eliminated"); p.eliminatedAt=t.getLong("EliminatedAt");
            p.lastX=t.getInt("LastX"); p.lastY=t.getInt("LastY"); p.lastZ=t.getInt("LastZ");
            return p;
        }
    }
}
