package com.dmzlivingworld.world;

import com.dmzlivingworld.LivingWorldMod;
import com.dmzlivingworld.entity.AmbientFighterEntity;
import com.dmzlivingworld.entity.FighterAlignment;
import com.dmzlivingworld.entity.FighterRank;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/** Natural manifestation, persistence and elimination rules for world rogues. */
@Mod.EventBusSubscriber(modid = LivingWorldMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class WantedManager {
    private static final String TRACK_KEY = "DMZLivingWorldWantedTrack";
    private WantedManager() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        // Wanted profiles are shared through overworld SavedData, so advance the daily
        // scheduler at most once while a supported world is active, rather than repeating
        // the same no-op day check for every player.
        boolean wantedTicked = false;
        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            if (!(player.level() instanceof ServerLevel level) || !LivingWorldDimensions.isSupported(level)) continue;
            WantedWorldData data = WantedWorldData.get(level);
            if (!wantedTicked) {
                data.tick(level);
                wantedTicked = true;
            }
            if (player.isCreative() || player.isSpectator()) continue;
            long time = level.getGameTime();
            if (Math.floorMod(time + player.getUUID().hashCode(), 80) == 0) tickTracker(player, data);
            if (Math.floorMod(time + player.getUUID().hashCode(), 200) != 0) continue;
            for (WantedWorldData.WantedProfile profile : data.active(LivingWorldDimensions.realm(level))) {
                if (profile.spawned) continue;
                double dx = profile.anchorX - player.getX(), dz = profile.anchorZ - player.getZ();
                if (dx * dx + dz * dz <= 180.0D * 180.0D) {
                    if (spawn(player, profile, false) != null) break;
                }
            }
        }
    }

    public static boolean track(ServerPlayer player, WantedWorldData.WantedProfile profile) {
        if (player == null || profile == null || profile.eliminated) return false;
        player.getPersistentData().putInt(TRACK_KEY, profile.slot);
        tickTracker(player, WantedWorldData.get(player.serverLevel()));
        return true;
    }

    public static void clearTrack(ServerPlayer player) {
        if (player != null) player.getPersistentData().remove(TRACK_KEY);
    }

    public static int trackedSlot(ServerPlayer player) {
        return player == null ? 0 : player.getPersistentData().getInt(TRACK_KEY);
    }

    private static void tickTracker(ServerPlayer player, WantedWorldData data) {
        int slot = trackedSlot(player);
        if (slot <= 0 || RescueMissionManager.hasMission(player)) return;
        WantedWorldData.WantedProfile profile = data.bySlot(slot);
        if (profile == null || profile.eliminated) {
            clearTrack(player);
            if (profile != null) player.displayClientMessage(Component.literal("WANTED TRACK • " + profile.name + " • eliminated"), true);
            return;
        }
        if (!(player.level() instanceof ServerLevel current) || LivingWorldDimensions.realm(current) != profile.realm) {
            player.displayClientMessage(Component.literal("WANTED TRACK • " + profile.name + " • " + profile.realm.displayName()
                    + " • threat " + "★".repeat(profile.severity)), true);
            return;
        }
        int x = profile.spawned && profile.lastX != 0 ? profile.lastX : profile.anchorX;
        int z = profile.spawned && profile.lastZ != 0 ? profile.lastZ : profile.anchorZ;
        int distance = (int)Math.round(Math.hypot(x - player.getX(), z - player.getZ()));
        String direction = FactionManager.direction(player.getX(), player.getZ(), x, z);
        String confidence = profile.spawned ? "last known" : distance <= 320 ? "strong trail" : "rumored area";
        player.displayClientMessage(Component.literal("WANTED TRACK • " + profile.name + " • " + direction + " • "
                + distance + "b • " + confidence + " • " + "★".repeat(profile.severity)), true);
    }

    public static AmbientFighterEntity spawn(ServerPlayer player, WantedWorldData.WantedProfile profile, boolean debug) {
        if (!(player.level() instanceof ServerLevel level) || profile == null || profile.eliminated) return null;
        if (profile.realm != LivingWorldDimensions.realm(level)) return null;
        WantedWorldData data = WantedWorldData.get(level);
        if (profile.spawned && !debug) return null;

        BlockPos center = debug ? player.blockPosition()
                : new BlockPos(profile.anchorX, player.blockPosition().getY(), profile.anchorZ);
        BlockPos pos = AmbientFighterSpawner.findSafeGroundAround(level, center, player.getRandom(), debug ? 8 : 0,
                debug ? 16 : 48, 48);
        if (pos == null) return null;
        FighterRank rank = profile.severity >= 4 ? FighterRank.VETERAN : FighterRank.TRAINED;
        AmbientFighterEntity rogue = AmbientFighterSpawner.spawnAt(level, pos, FighterAlignment.BAD, rank,
                profile.personality, profile.race, profile.archetype, player.getRandom());
        if (rogue == null) return null;
        rogue.setFighterName(profile.name);
        rogue.markWanted(profile.id, profile.severity, profile.crime);
        long scaled = Math.round(Math.max(1, rogue.getBattlePower()) * (1.18D + profile.severity * 0.18D));
        rogue.setBattlePower((int)Math.min(Integer.MAX_VALUE - 1L, scaled));
        rogue.flareAura(70 + profile.severity * 18);
        rogue.speak(profile.severity >= 4 ? "You actually found me." : "Looking for trouble?", 70);
        data.markSpawned(profile, rogue.blockPosition());
        return rogue;
    }

    public static void update(AmbientFighterEntity rogue) {
        if (!rogue.isWanted() || !(rogue.level() instanceof ServerLevel level)) return;
        WantedWorldData.WantedProfile profile = WantedWorldData.get(level).byId(rogue.getWantedId());
        if (profile != null && !profile.eliminated) WantedWorldData.get(level).updatePosition(profile, rogue.blockPosition());
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof AmbientFighterEntity rogue) || !rogue.isWanted()) return;
        if (!(rogue.level() instanceof ServerLevel level)) return;
        WantedWorldData data = WantedWorldData.get(level);
        WantedWorldData.WantedProfile profile = data.byId(rogue.getWantedId());
        if (profile == null || profile.eliminated) return;
        data.markEliminated(profile, level.getServer().overworld().getGameTime());
        if (event.getSource().getEntity() instanceof ServerPlayer player) {
            if (trackedSlot(player) == profile.slot) clearTrack(player);
            player.displayClientMessage(Component.literal("[Living World] WANTED eliminated: " + profile.name
                    + " — " + profile.crime + "."), false);
            PlayerWorldManager.addHeroic(player, 4 + profile.severity * 2);
            PlayerWorldManager.addFame(player, 5 + profile.severity * 3);
            // Protector/guard factions appreciate removing known threats on their own world.
            List<WorldFaction> factions = FactionManager.factionsForRealm(level);
            for (WorldFaction faction : factions) {
                if (faction.alignment() == FighterAlignment.GOOD
                        && (faction.structure() == FactionStructure.GUARD || faction.ethos() == FactionEthos.WANDERING_GUARD
                        || faction.ethos() == FactionEthos.NAMEK_WARDENS)) {
                    FactionManager.adjustReputation(player, faction, 2 + profile.severity);
                }
            }
        }
    }
}
