package com.dmzlivingworld.world;

import com.dmzlivingworld.LivingWorldMod;
import com.dmzlivingworld.compat.MeditationCompat;
import com.dmzlivingworld.entity.AmbientFighterEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Sparse personal bonds. Nothing here turns a fighter into a tame pet: invites
 * are voluntary, one companion can travel with a player, and the companion keeps
 * self-preservation/faction loyalties while supporting genuine threats.
 */
@Mod.EventBusSubscriber(modid = LivingWorldMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class LivingBondManager {
    private static final String ROOT = "DMZLivingWorldBonds";
    private static final Map<UUID, Invite> INVITES = new HashMap<>();
    private enum InviteType { MEDITATE, TRAVEL }
    private record Invite(UUID npc, InviteType type, long expires) {}

    private LivingBondManager() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) {
            if (!(player.level() instanceof ServerLevel level) || !LivingWorldDimensions.isSupported(level)) continue;
            long now = level.getServer().overworld().getGameTime();
            tickInvite(player, level, now);
            tickCompanion(player, level, now);
            if (now % 20L == Math.floorMod(player.getUUID().hashCode(), 20)) tickSharedMeditation(player, level, now);
        }
        long now = event.getServer().overworld().getGameTime();
        INVITES.entrySet().removeIf(e -> e.getValue().expires < now);
    }

    public static void clearRuntime(UUID playerId) { if (playerId != null) INVITES.remove(playerId); }
    public static void clearRuntime() { INVITES.clear(); }
    public static int runtimeEntries() { return INVITES.size(); }

    private static void tickInvite(ServerPlayer player, ServerLevel level, long now) {
        Invite active = INVITES.get(player.getUUID());
        if (active != null) {
            AmbientFighterEntity npc = entity(level, active.npc);
            if (npc == null || !npc.isAlive()) { INVITES.remove(player.getUUID()); return; }
            if (player.distanceToSqr(npc) > 7.0D * 7.0D && player.distanceToSqr(npc) < 36.0D * 36.0D && !npc.isMeditating()) {
                npc.getNavigation().moveTo(player, 1.05D);
            }
            // If the player starts MediMod manually after the invitation, the NPC joins without another click.
            if (active.type == InviteType.MEDITATE && MeditationCompat.isPlayerMeditating(player)
                    && player.distanceToSqr(npc) <= 8.0D * 8.0D && !npc.isMeditating()) {
                npc.beginMeditation(1800 + npc.getRandom().nextInt(1801), true);
                if (npc.getSpeech().isEmpty()) npc.speak("Good. Let's clear our heads.", 62);
                INVITES.remove(player.getUUID());
            }
            return;
        }

        CompoundTag root = root(player);
        if (MeditationCompat.isAvailable() && now >= root.getLong("NextMeditationInvite") && !MeditationCompat.isPlayerMeditating(player)) {
            root.putLong("NextMeditationInvite", now + 36000L + player.getRandom().nextInt(36001));
            AmbientFighterEntity candidate = nearbyMeditationFriend(player, level);
            if (candidate != null) {
                INVITES.put(player.getUUID(), new Invite(candidate.getUUID(), InviteType.MEDITATE, now + 700L));
                candidate.speak("Want to meditate together for a while?", 105);
                candidate.getNavigation().moveTo(player, 1.0D);
                save(player, root);
                return;
            }
        }

        if (now >= root.getLong("NextCompanionOffer") && companionId(player) == null) {
            root.putLong("NextCompanionOffer", now + 72000L + player.getRandom().nextInt(72001));
            AmbientFighterEntity friend = level.getEntitiesOfClass(AmbientFighterEntity.class,
                    player.getBoundingBox().inflate(30.0D), f -> f.isAlive() && !f.isNonCombatant() && f.isRememberedFor(player)
                            && f.getMemoryRelationship() >= 45 && !f.isCaptive() && !f.isDefeated())
                    .stream().findAny().orElse(null);
            if (friend != null) {
                INVITES.put(player.getUUID(), new Invite(friend.getUUID(), InviteType.TRAVEL, now + 800L));
                friend.speak("You're heading out again? Want some company?", 110);
                friend.getNavigation().moveTo(player, 1.05D);
            }
            save(player, root);
        }
    }

    /** Called before normal sneak-inspection. */
    public static boolean tryHandleInteraction(ServerPlayer player, AmbientFighterEntity npc) {
        Invite invite = INVITES.get(player.getUUID());
        if (invite == null || !invite.npc.equals(npc.getUUID())) return false;
        INVITES.remove(player.getUUID());
        if (invite.type == InviteType.MEDITATE) {
            if (!MeditationCompat.isAvailable()) {
                npc.speak("Maybe another time.", 45);
                return true;
            }
            boolean started = MeditationCompat.startPlayerMeditation(player);
            if (started) {
                npc.beginMeditation(1800 + npc.getRandom().nextInt(1801), true);
                npc.speak("Breathe. Don't force it.", 64);
                FighterMemoryManager.strengthenRelationship(player, npc, 2, "Meditated together");
            }
            return true;
        }
        if (invite.type == InviteType.TRAVEL) {
            setCompanion(player, npc);
            npc.speak("I'll come with you. But I'm making my own calls.", 86);
            FighterMemoryManager.strengthenRelationship(player, npc, 3, "Travelled together");
            return true;
        }
        return false;
    }

    private static void tickSharedMeditation(ServerPlayer player, ServerLevel level, long now) {
        if (!MeditationCompat.isPlayerMeditating(player)) {
            CompoundTag root = root(player);
            if (root.getLong("SharedMeditationTicks") != 0L) {
                root.putLong("SharedMeditationTicks", 0L);
                save(player, root);
            }
            return;
        }
        int partners = level.getEntitiesOfClass(AmbientFighterEntity.class, player.getBoundingBox().inflate(14.0D),
                f -> f.isAlive() && f.isMeditating()).size();
        if (partners <= 0) return;
        CompoundTag root = root(player);
        long shared = root.getLong("SharedMeditationTicks") + 20L;
        root.putLong("SharedMeditationTicks", shared);
        MeditationCompat.applyNpcHarmony(player, partners, shared);
        if (shared % 200L == 0L) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    "LIVING WORLD • Harmony with " + partners + " meditating fighter" + (partners == 1 ? "" : "s")), true);
        }
        save(player, root);
    }

    private static AmbientFighterEntity nearbyMeditationFriend(ServerPlayer player, ServerLevel level) {
        return level.getEntitiesOfClass(AmbientFighterEntity.class, player.getBoundingBox().inflate(28.0D), f -> {
            if (!f.isAlive() || f.isCaptive() || f.isDefeated() || f.isMeditating() || f.getTarget() != null) return false;
            if (f.isRememberedFor(player) && f.getMemoryRelationship() >= 20) return true;
            if (f.isFactionMember() && FactionManager.getReputation(player, f.getFactionId()) >= FactionManager.FRIENDLY_REP) return true;
            return false;
        }).stream().filter(f -> f.getPersonality() != com.dmzlivingworld.entity.FighterPersonality.AGGRESSIVE
                        || player.getRandom().nextFloat() < 0.25F)
                .findAny().orElse(null);
    }

    private static void tickCompanion(ServerPlayer player, ServerLevel level, long now) {
        UUID id = companionId(player);
        if (id == null) return;
        AmbientFighterEntity companion = entity(level, id);
        if (companion == null) return; // persistent entity may simply be in an unloaded chunk.
        if (!companion.isAlive()) { clearCompanion(player); return; }

        CompoundTag root = root(player);
        long joined = root.getLong("CompanionJoined");
        if (joined > 0 && now - joined > 96000L) {
            companion.speak("I should head back for a while. We'll meet again.", 82);
            clearCompanion(player);
            return;
        }
        if (companion.isFactionMember()) {
            WorldFaction faction = FactionManager.byId(level, companion.getFactionId());
            if (faction != null && !FactionWorldData.get(level).warEnemies(faction, now).isEmpty()
                    && now - joined > 24000L && Math.floorMod(now + companion.getUUID().hashCode(), 24000L) == 0L
                    && companion.getRandom().nextFloat() < 0.35F) {
                companion.speak("My people are at war. I need to go back.", 82);
                clearCompanion(player);
                return;
            }
        }

        if (companion.getHealth() < companion.getMaxHealth() * 0.18F) {
            companion.setTarget(null);
            if (player.distanceToSqr(companion) > 7.0D * 7.0D) companion.getNavigation().moveTo(player, 1.15D);
            return;
        }

        LivingEntity threat = player.getLastHurtByMob();
        if (threat == null || !threat.isAlive() || player.distanceToSqr(threat) > 80.0D * 80.0D) {
            LivingEntity attacked = player.getLastHurtMob();
            if (attacked != null && attacked.isAlive() && player.distanceToSqr(attacked) < 64.0D * 64.0D) threat = attacked;
        }
        if (threat != null && threat.isAlive() && !loyaltyConflict(companion, threat)) {
            companion.setTarget(threat);
        } else if (companion.getTarget() == null) {
            double distance = player.distanceToSqr(companion);
            if (distance > 18.0D * 18.0D) companion.getNavigation().moveTo(player, 1.20D);
            else if (distance > 8.0D * 8.0D) companion.getNavigation().moveTo(player, 1.0D);
        }
    }

    private static boolean loyaltyConflict(AmbientFighterEntity companion, LivingEntity target) {
        if (!(target instanceof AmbientFighterEntity other)) return false;
        if (companion.isFactionMember() && other.isFactionMember()) return FactionManager.areAllies(companion, other);
        return false;
    }

    private static void setCompanion(ServerPlayer player, AmbientFighterEntity npc) {
        CompoundTag root = root(player);
        root.putUUID("Companion", npc.getUUID());
        root.putString("CompanionName", npc.getFighterName());
        root.putLong("CompanionJoined", player.serverLevel().getServer().overworld().getGameTime());
        save(player, root);
        npc.setPersistenceRequired();
    }

    public static UUID companionId(ServerPlayer player) {
        CompoundTag root = root(player);
        return root.hasUUID("Companion") ? root.getUUID("Companion") : null;
    }

    public static String companionName(ServerPlayer player) { return root(player).getString("CompanionName"); }

    /** Debug hook: uses the same interaction path as a naturally occurring invitation. */
    public static int forceMeditationInvite(ServerPlayer player) {
        if (!(player.level() instanceof ServerLevel level) || !MeditationCompat.isAvailable()) return 0;
        AmbientFighterEntity npc = level.getEntitiesOfClass(AmbientFighterEntity.class,
                player.getBoundingBox().inflate(48.0D), f -> f.isAlive() && !f.isCaptive() && !f.isDefeated()
                        && !f.isNonCombatant() && f.getTarget() == null && !f.isMeditating())
                .stream().min(java.util.Comparator.comparingDouble(player::distanceToSqr)).orElse(null);
        if (npc == null) return 0;
        long now = level.getServer().overworld().getGameTime();
        INVITES.put(player.getUUID(), new Invite(npc.getUUID(), InviteType.MEDITATE, now + 1200L));
        npc.speak("Want to meditate together for a while?", 110);
        npc.getNavigation().moveTo(player, 1.0D);
        return 1;
    }

    /** Debug hook: invites the nearest suitable fighter without bypassing the companion rules after acceptance. */
    public static int forceCompanionInvite(ServerPlayer player) {
        if (!(player.level() instanceof ServerLevel level) || companionId(player) != null) return 0;
        AmbientFighterEntity npc = level.getEntitiesOfClass(AmbientFighterEntity.class,
                player.getBoundingBox().inflate(48.0D), f -> f.isAlive() && !f.isCaptive() && !f.isDefeated()
                        && !f.isNonCombatant() && f.getTarget() == null)
                .stream().min(java.util.Comparator.comparingDouble(player::distanceToSqr)).orElse(null);
        if (npc == null) return 0;
        long now = level.getServer().overworld().getGameTime();
        INVITES.put(player.getUUID(), new Invite(npc.getUUID(), InviteType.TRAVEL, now + 1200L));
        npc.speak("You're heading out again? Want some company?", 110);
        npc.getNavigation().moveTo(player, 1.05D);
        return 1;
    }

    public static String status(ServerPlayer player) {
        Invite invite = INVITES.get(player.getUUID());
        String invitation = invite == null ? "none" : invite.type.name().toLowerCase(java.util.Locale.ROOT);
        String companion = companionName(player);
        return "companion=" + (companion.isBlank() ? "none" : companion)
                + " • pending invite=" + invitation
                + " • MediMod=" + (MeditationCompat.isAvailable() ? "active" : "not loaded");
    }

    public static void clearCompanion(ServerPlayer player) {
        CompoundTag root = root(player);
        root.remove("Companion"); root.remove("CompanionName"); root.remove("CompanionJoined");
        save(player, root);
    }

    private static AmbientFighterEntity entity(ServerLevel level, UUID id) {
        if (level == null || id == null) return null;
        var entity = level.getEntity(id);
        return entity instanceof AmbientFighterEntity fighter ? fighter : null;
    }

    private static CompoundTag root(ServerPlayer player) {
        CompoundTag p = player.getPersistentData();
        if (!p.contains(ROOT, net.minecraft.nbt.Tag.TAG_COMPOUND)) p.put(ROOT, new CompoundTag());
        return p.getCompound(ROOT);
    }
    private static void save(ServerPlayer player, CompoundTag root) { player.getPersistentData().put(ROOT, root); }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof AmbientFighterEntity npc) || !(npc.level() instanceof ServerLevel level)) return;
        for (ServerPlayer player : level.getServer().getPlayerList().getPlayers()) {
            UUID id = companionId(player);
            if (id != null && id.equals(npc.getUUID())) clearCompanion(player);
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (!(event.getOriginal() instanceof ServerPlayer old) || !(event.getEntity() instanceof ServerPlayer copy)) return;
        if (old.getPersistentData().contains(ROOT, net.minecraft.nbt.Tag.TAG_COMPOUND))
            copy.getPersistentData().put(ROOT, old.getPersistentData().getCompound(ROOT).copy());
    }
}
