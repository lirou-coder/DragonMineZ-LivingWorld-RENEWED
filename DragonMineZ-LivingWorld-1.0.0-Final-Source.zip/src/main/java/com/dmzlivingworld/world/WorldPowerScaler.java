package com.dmzlivingworld.world;

import com.dmzlivingworld.entity.FighterRank;
import com.dragonminez.common.stats.StatsCapability;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

/**
 * Makes procedural fighter battle power follow the actual world/player instead of
 * living forever inside a fixed 250-12500 box. The spread is intentionally broad:
 * most fighters are below/around the local player, veterans can exceed them, and a
 * very small number become scary outliers.
 */
public final class WorldPowerScaler {
    private static final double SEARCH_RADIUS_SQ = 2048.0D * 2048.0D;

    private WorldPowerScaler() {}

    public static int rollBattlePower(ServerLevel level, BlockPos pos, FighterRank rank, RandomSource random) {
        double anchor = resolveWorldAnchor(level, pos);

        double minFactor;
        double maxFactor;
        switch (rank) {
            case ROOKIE -> {
                minFactor = 0.16D;
                maxFactor = 0.52D;
            }
            case TRAINED -> {
                minFactor = 0.42D;
                maxFactor = 1.08D;
            }
            case VETERAN -> {
                minFactor = 0.82D;
                maxFactor = 1.85D;
            }
            default -> {
                minFactor = 0.25D;
                maxFactor = 1.0D;
            }
        }

        // Bias toward the middle rather than uniformly filling the whole range.
        double t = (random.nextDouble() + random.nextDouble()) * 0.5D;
        double factor = Mth.lerp(t, minFactor, maxFactor);

        // Rare world-level monsters. They are not a separate boss system; they're
        // simply memorable procedural fighters the player may choose not to engage.
        if (rank == FighterRank.VETERAN && random.nextFloat() < 0.055F) {
            factor *= 1.55D + random.nextDouble() * 1.15D;
        }

        // World age is only a gentle pressure, never the main scaler. A long-term
        // world gets somewhat more dangerous even if the player is between builds.
        double days = level.getDayTime() / 24000.0D;
        factor *= 1.0D + Math.min(0.30D, days / 700.0D);

        long result = Math.round(Math.max(120.0D, anchor * factor));
        return (int)Math.min(Integer.MAX_VALUE - 1L, result);
    }

    public static double resolveWorldAnchor(ServerLevel level, BlockPos pos) {
        double best = 0.0D;
        double nearestDistance = Double.MAX_VALUE;

        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) continue;
            double distance = player.distanceToSqr(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
            if (distance > SEARCH_RADIUS_SQ) continue;

            final double[] bp = {0.0D};
            player.getCapability(StatsCapability.INSTANCE).ifPresent(stats -> bp[0] = stats.getBattlePowerExact());
            if (bp[0] <= 0.0D) continue;

            // Prefer the closest real player as the local progression reference, but
            // don't let a second much stronger nearby player be completely ignored.
            if (distance < nearestDistance) {
                nearestDistance = distance;
                best = Math.max(best * 0.70D, bp[0]);
            } else {
                best = Math.max(best, bp[0] * 0.80D);
            }
        }

        // Sensible early-world fallback if capability data is unavailable for a tick.
        return Math.max(650.0D, best);
    }
}
