package com.dmzlivingworld.world;

import com.dmzlivingworld.LivingWorldMod;
import com.dmzlivingworld.entity.AmbientFighterEntity;
import com.dmzlivingworld.entity.FighterAlignment;
import com.dmzlivingworld.entity.FighterArchetype;
import com.dmzlivingworld.entity.FighterDialogue;
import com.dmzlivingworld.entity.FighterPersonality;
import com.dmzlivingworld.entity.FighterRace;
import com.dmzlivingworld.entity.FighterRank;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Long-range Frieza-force rescue objectives without generated structures. */
@Mod.EventBusSubscriber(modid = LivingWorldMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class RescueMissionManager {
    private static final Map<UUID, Mission> MISSIONS = new HashMap<>();
    private static final Map<UUID, Long> NEXT_NATURAL = new HashMap<>();
    private static final int MIN_DISTANCE = 200;
    private static final int MAX_DISTANCE = 1500;
    private static final int BEACON_DISTANCE = 190;
    private static final int RESOLVE_DISTANCE = 112;
    private static final int MISSION_TIMEOUT = 20 * 60 * 20; // 20 minutes.

    private RescueMissionManager() {}

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        for (ServerPlayer player : event.getServer().getPlayerList().getPlayers()) tickPlayer(player);
    }

    private static void tickPlayer(ServerPlayer player) {
        Mission mission = MISSIONS.get(player.getUUID());
        if (mission != null) {
            tickMission(player, mission);
            return;
        }

        if (player.isCreative() || player.isSpectator()) return;
        if (!(player.level() instanceof ServerLevel level) || !LivingWorldDimensions.isSupported(level)) return;
        if (level.getGameTime() % 200L != Math.floorMod(player.getUUID().hashCode(), 200)) return;

        long now = level.getGameTime();
        long next = NEXT_NATURAL.computeIfAbsent(player.getUUID(), ignored -> now + 7200L + player.getRandom().nextInt(7201));
        if (now < next) return;

        if (player.getRandom().nextFloat() < 0.34F) {
            startRescue(player, false);
        } else {
            NEXT_NATURAL.put(player.getUUID(), now + 2400L + player.getRandom().nextInt(3601));
        }
    }

    public static void clearRuntime(ServerPlayer player) {
        if (player == null) return;
        Mission mission = MISSIONS.remove(player.getUUID());
        NEXT_NATURAL.remove(player.getUUID());
        if (mission != null) {
            ServerLevel missionLevel = LivingWorldDimensions.levelFor(player.getServer(), mission.realm);
            if (missionLevel != null) cleanupMissionEntities(missionLevel, mission);
        }
    }

    public static void clearRuntime() { MISSIONS.clear(); NEXT_NATURAL.clear(); }
    public static int runtimeEntries() { return MISSIONS.size() + NEXT_NATURAL.size(); }

    public static boolean startRescue(ServerPlayer player, boolean debug) {
        if (!(player.level() instanceof ServerLevel level) || !LivingWorldDimensions.isSupported(level)) return false;
        if (MISSIONS.containsKey(player.getUUID())) return false;

        int distance = Mth.nextInt(player.getRandom(), MIN_DISTANCE, MAX_DISTANCE);
        double angle = player.getRandom().nextDouble() * Math.PI * 2.0D;
        int x = Mth.floor(player.getX() + Math.cos(angle) * distance);
        int z = Mth.floor(player.getZ() + Math.sin(angle) * distance);
        BlockPos target = new BlockPos(x, player.blockPosition().getY(), z);
        if (!level.getWorldBorder().isWithinBounds(target)) {
            x = Mth.floor(player.getX() - Math.cos(angle) * distance);
            z = Mth.floor(player.getZ() - Math.sin(angle) * distance);
            target = new BlockPos(x, player.blockPosition().getY(), z);
            if (!level.getWorldBorder().isWithinBounds(target)) return false;
        }

        Mission mission = new Mission(target, level.getGameTime(), debug, LivingWorldDimensions.realm(level));
        MISSIONS.put(player.getUUID(), mission);
        NEXT_NATURAL.put(player.getUUID(), level.getGameTime() + 14400L + player.getRandom().nextInt(15601));

        player.displayClientMessage(Component.literal("[Living World] ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal("You sense a weak power surrounded by hostile signatures...")
                        .withStyle(ChatFormatting.LIGHT_PURPLE)), false);
        announceSignal(player, mission);
        level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.55F, 0.68F);
        return true;
    }

    public static boolean cancel(ServerPlayer player) {
        Mission mission = MISSIONS.remove(player.getUUID());
        if (mission == null) return false;
        ServerLevel missionLevel = LivingWorldDimensions.levelFor(player.getServer(), mission.realm);
        if (missionLevel != null) cleanupMissionEntities(missionLevel, mission);
        action(player, Component.literal("Rescue objective cancelled.").withStyle(ChatFormatting.DARK_GRAY));
        return true;
    }

    public static boolean hasMission(ServerPlayer player) {
        return player != null && MISSIONS.containsKey(player.getUUID());
    }

    public static String status(ServerPlayer player) {
        Mission mission = MISSIONS.get(player.getUUID());
        if (mission == null) return "No active rescue objective.";
        if (!(player.level() instanceof ServerLevel current) || LivingWorldDimensions.realm(current) != mission.realm) {
            return "Distress signal remains on " + mission.realm.displayName() + " • target X "
                    + mission.target.getX() + " Z " + mission.target.getZ() + ".";
        }
        int distance = horizontalDistance(player, mission.target);
        if (mission.spawned) {
            return "Rescue active on " + mission.realm.displayName() + " — Frieza patrol engaged, "
                    + Math.max(0, livingGuards(current, mission))
                    + " guards remain. Target X " + mission.target.getX() + " Z " + mission.target.getZ() + ".";
        }
        return "Distress signal on " + mission.realm.displayName() + " • " + compassDirection(player, mission.target)
                + " • " + relativeCue(player, mission.target) + " • " + distance
                + " blocks • target X " + mission.target.getX() + " Z " + mission.target.getZ() + ".";
    }

    private static void tickMission(ServerPlayer player, Mission mission) {
        if (!(player.level() instanceof ServerLevel level) || !LivingWorldDimensions.isSupported(level)
                || LivingWorldDimensions.realm(level) != mission.realm) {
            if (player.tickCount % 100 == 0) {
                action(player, Component.literal("Rescue signal remains on " + mission.realm.displayName() + ".")
                        .withStyle(ChatFormatting.GRAY));
            }
            return;
        }

        if (level.getGameTime() - mission.startedAt > MISSION_TIMEOUT && !mission.spawned) {
            MISSIONS.remove(player.getUUID());
            action(player, Component.literal("The distress signal has gone silent.").withStyle(ChatFormatting.DARK_GRAY));
            return;
        }

        if (!mission.spawned) {
            int distance = horizontalDistance(player, mission.target);
            if (player.tickCount % 40 == 0) announceSignal(player, mission);

            if (distance <= BEACON_DISTANCE && level.hasChunkAt(mission.target)) {
                if (player.tickCount % 20 == 0) emitDistressBeacon(level, mission.target);
                if (player.tickCount % 100 == 0) {
                    float pitch = distance < 80 ? 1.45F : distance < 140 ? 1.15F : 0.92F;
                    level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                            SoundSource.PLAYERS, 0.28F, pitch);
                }
            }

            if (distance <= RESOLVE_DISTANCE) resolveScene(player, level, mission);
            return;
        }

        Entity captiveEntity = mission.captiveId == null ? null : level.getEntity(mission.captiveId);
        if (!(captiveEntity instanceof AmbientFighterEntity captive) || !captive.isAlive()) {
            MISSIONS.remove(player.getUUID());
            action(player, Component.literal("Rescue failed — the captive is gone.").withStyle(ChatFormatting.RED));
            return;
        }

        int remaining = livingGuards(level, mission);
        if (remaining <= 0) {
            captive.setCaptive(false);
            FighterMemoryManager.rememberRescue(player, captive);
            captive.speak(FighterDialogue.rescued(captive.getRandom()), 100);
            MISSIONS.remove(player.getUUID());
            action(player, Component.literal("Rescue complete — ")
                    .withStyle(ChatFormatting.GOLD)
                    .append(Component.literal(captive.getFighterName()).withStyle(ChatFormatting.WHITE))
                    .append(Component.literal(" is safe.").withStyle(ChatFormatting.GREEN)));
            return;
        }

        if (player.tickCount % 80 == 0) {
            action(player, Component.literal("Frieza patrol: " + remaining + " guard" + (remaining == 1 ? "" : "s") + " remaining")
                    .withStyle(ChatFormatting.LIGHT_PURPLE));
        }
    }

    private static void emitDistressBeacon(ServerLevel level, BlockPos target) {
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, target.getX(), target.getZ());
        double x = target.getX() + 0.5D;
        double z = target.getZ() + 0.5D;
        for (int i = 0; i < 9; i++) {
            double py = y + 2.0D + i * 2.4D;
            level.sendParticles(i % 3 == 0 ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.END_ROD,
                    x, py, z, 2, 0.28D, 0.55D, 0.28D, 0.015D);
        }
    }

    private static void resolveScene(ServerPlayer player, ServerLevel level, Mission mission) {
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, mission.target.getX(), mission.target.getZ());
        BlockPos surface = new BlockPos(mission.target.getX(), y, mission.target.getZ());
        BlockPos captivePos = AmbientFighterSpawner.findSafeGroundAround(level, surface, player.getRandom(), 0, 10, 24);
        if (captivePos == null) return;

        FighterRank captiveRank = player.getRandom().nextFloat() < 0.72F ? FighterRank.ROOKIE : FighterRank.TRAINED;
        // Some rescue signals now belong to the world's generated social map. Saving
        // a faction member feeds directly into that faction's reputation and Living Memory.
        WorldFaction faction = player.getRandom().nextFloat() < 0.46F ? FactionManager.pickFactionFor(player) : null;
        FighterRace race = faction == null ? AmbientFighterSpawner.rollRaceForLevel(level, player.getRandom())
                : FactionWorldData.rollFactionRace(player.getRandom(), faction.realm());
        FighterArchetype style = faction == null ? FighterArchetype.roll(player.getRandom(), captiveRank)
                : faction.ethos().rollArchetype(player.getRandom());
        FighterAlignment alignment = faction == null ? FighterAlignment.NEUTRAL : faction.alignment();
        AmbientFighterEntity captive = AmbientFighterSpawner.spawnAt(
                level, captivePos, alignment, captiveRank, FighterPersonality.CAUTIOUS,
                race, style, player.getRandom());
        if (captive == null) return;
        if (faction != null) captive.assignFaction(faction, FactionRole.MEMBER, null, false, false);
        captive.setCaptive(true);
        mission.captiveId = captive.getUUID();

        int wantedGuards = 2 + (player.getRandom().nextFloat() < 0.38F ? 1 : 0);
        String[] types = {"saga_friezasoldier01", "saga_friezasoldier02", "saga_friezasoldier03"};
        for (int i = 0; i < wantedGuards; i++) {
            BlockPos guardPos = AmbientFighterSpawner.findSafeGroundAround(level, captivePos, player.getRandom(), 4, 10, 18);
            if (guardPos == null) guardPos = captivePos.offset(3 + i * 2, 0, 2);
            var guard = FriezaNpcUtil.spawnSoldier(level, guardPos, player, player.getRandom(), types[i % types.length],
                    "lw_rescue_guard", "lw_frieza_mission");
            if (guard != null) mission.guardIds.add(guard.getUUID());
        }

        if (mission.guardIds.size() < 2) {
            cleanupMissionEntities(level, mission);
            mission.captiveId = null;
            mission.guardIds.clear();
            return;
        }

        mission.spawned = true;
        captive.speak(FighterDialogue.captive(captive.getRandom()), 75);
        action(player, Component.literal("Frieza patrol located — free the captive!").withStyle(ChatFormatting.LIGHT_PURPLE));
    }

    private static int livingGuards(ServerLevel level, Mission mission) {
        int living = 0;
        for (UUID id : mission.guardIds) {
            Entity entity = level.getEntity(id);
            if (entity != null && entity.isAlive()) living++;
        }
        return living;
    }

    private static void cleanupMissionEntities(ServerLevel level, Mission mission) {
        if (mission.captiveId != null) {
            Entity captive = level.getEntity(mission.captiveId);
            if (captive != null) captive.discard();
        }
        for (UUID id : mission.guardIds) {
            Entity guard = level.getEntity(id);
            if (guard != null) guard.discard();
        }
    }

    private static void announceSignal(ServerPlayer player, Mission mission) {
        int distance = horizontalDistance(player, mission.target);
        Component message = Component.literal("DISTRESS • ").withStyle(ChatFormatting.LIGHT_PURPLE)
                .append(Component.literal(compassDirection(player, mission.target)).withStyle(ChatFormatting.WHITE))
                .append(Component.literal(" • " + relativeCue(player, mission.target)).withStyle(ChatFormatting.GOLD))
                .append(Component.literal(" • " + distance + " blocks").withStyle(ChatFormatting.GRAY));
        if (mission.debug) {
            message = message.copy().append(Component.literal(" • X " + mission.target.getX() + " Z " + mission.target.getZ())
                    .withStyle(ChatFormatting.DARK_GRAY));
        }
        action(player, message);
    }

    private static int horizontalDistance(ServerPlayer player, BlockPos target) {
        double dx = target.getX() + 0.5D - player.getX();
        double dz = target.getZ() + 0.5D - player.getZ();
        return Mth.floor(Math.sqrt(dx * dx + dz * dz));
    }

    /** Minecraft-yaw-compatible absolute compass bearing. */
    private static String compassDirection(ServerPlayer player, BlockPos target) {
        double yaw = targetYaw(player, target);
        String[] names = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        return names[Math.floorMod((int)Math.round(yaw / 45.0D), 8)];
    }

    /** Direction relative to where the player is looking, so navigation works while moving. */
    private static String relativeCue(ServerPlayer player, BlockPos target) {
        double wantedYaw = targetYaw(player, target);
        double playerYaw = Mth.wrapDegrees(player.getYRot());
        double delta = Mth.wrapDegrees((float)(wantedYaw - playerYaw));
        double abs = Math.abs(delta);
        if (abs <= 18.0D) return "↑ AHEAD";
        if (abs >= 162.0D) return "↓ BEHIND";
        if (delta > 0.0D) {
            if (abs <= 62.0D) return "↙ FRONT-LEFT";
            return "← LEFT";
        }
        if (abs <= 62.0D) return "↘ FRONT-RIGHT";
        return "→ RIGHT";
    }

    private static double targetYaw(ServerPlayer player, BlockPos target) {
        double dx = target.getX() + 0.5D - player.getX();
        double dz = target.getZ() + 0.5D - player.getZ();
        double angle = Math.toDegrees(Math.atan2(-dx, dz));
        if (angle < 0.0D) angle += 360.0D;
        return angle;
    }

    private static void action(ServerPlayer player, Component message) {
        player.displayClientMessage(message, true);
    }

    private static final class Mission {
        private final BlockPos target;
        private final long startedAt;
        private final boolean debug;
        private final FactionRealm realm;
        private boolean spawned;
        private UUID captiveId;
        private final List<UUID> guardIds = new ArrayList<>();

        private Mission(BlockPos target, long startedAt, boolean debug, FactionRealm realm) {
            this.target = target;
            this.startedAt = startedAt;
            this.debug = debug;
            this.realm = realm;
        }
    }
}
