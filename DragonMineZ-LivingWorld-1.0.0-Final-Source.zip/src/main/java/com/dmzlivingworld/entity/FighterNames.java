package com.dmzlivingworld.entity;

import net.minecraft.util.RandomSource;

/** Original short names with small race-flavoured pools; no canon character copies. */
public final class FighterNames {
    private static final String[] HUMAN_MALE = {
            "Renso", "Daiki", "Kado", "Toma", "Riku", "Boro", "Jin", "Kenta",
            "Sato", "Ramon", "Teo", "Miro", "Kiro", "Naro", "Daro", "Renji",
            "Taro", "Kobi", "Rado", "Seki", "Niko", "Haru", "Keno", "Beni"
    };
    private static final String[] HUMAN_FEMALE = {
            "Nami", "Mika", "Rina", "Ami", "Yuna", "Sena", "Lina", "Mara",
            "Kira", "Tali", "Nera", "Sora", "Mina", "Rumi", "Kari", "Aira",
            "Nori", "Meli", "Hana", "Reni", "Tera", "Yori", "Kumi", "Sari"
    };
    private static final String[] SAIYAN_MALE = {"Cabro", "Ruga", "Taroq", "Vesso", "Kress", "Zukal", "Bruss", "Korat", "Tubar", "Paret", "Celon", "Onio"};
    private static final String[] SAIYAN_FEMALE = {"Cassa", "Roka", "Tressa", "Tomae", "Salla", "Leeka", "Peppa", "Yama", "Mizu", "Chira"};
    private static final String[] NAMEKIAN = {"Neru", "Kargo", "Voro", "Caden", "Pira", "Tuno", "Garo", "Rema", "Loru", "Sargo", "Nali", "Temba"};
    private static final String[] MAJIN_MALE = {"Mubo", "Bemi", "Poro", "Jubu", "Maji", "Bono", "Kubu", "Dumi", "Pabu", "Moro"};
    private static final String[] MAJIN_FEMALE = {"Bibi", "Mimi", "Juna", "Pomi", "Lulu", "Bena", "Maja", "Riri", "Pina", "Sumi"};
    private static final String[] FROST = {"Cryon", "Vyre", "Sleet", "Arctis", "Nival", "Glace", "Kryos", "Vanta", "Rime", "Zeric"};
    private static final String[] BIO = {"Cera", "Nex", "Viro", "Kell", "Syn", "Orin", "Mera", "Zeta", "Crix", "Iona"};

    private FighterNames() {}

    public static String roll(RandomSource random, FighterRace race, boolean female) {
        String[] pool = switch (race) {
            case HUMAN -> female ? HUMAN_FEMALE : HUMAN_MALE;
            case SAIYAN -> female ? SAIYAN_FEMALE : SAIYAN_MALE;
            case NAMEKIAN -> NAMEKIAN;
            case MAJIN -> female ? MAJIN_FEMALE : MAJIN_MALE;
            case FROST_DEMON -> FROST;
            case BIO_ANDROID -> BIO;
        };
        return pool[random.nextInt(pool.length)];
    }

    public static String roll(RandomSource random, boolean female) {
        return roll(random, FighterRace.HUMAN, female);
    }
}
