package com.dmzlivingworld.entity;

import net.minecraft.util.RandomSource;

/** Sparse overhead dialogue tied to visible fight events, never normal chat spam. */
public final class FighterDialogue {
    private FighterDialogue() {}

    private static final String[] OPEN_GOOD = {"Back off.", "Leave them alone.", "I'm stopping this.", "You picked the wrong target."};
    private static final String[] OPEN_NEUTRAL = {"All right.", "Show me your technique.", "Let's see what you've got.", "Come on, then."};
    private static final String[] OPEN_BAD = {"Wrong place to wander.", "You look easy.", "Try to keep up.", "This won't take long."};
    private static final String[] OPEN_REPLY = {"Enough talk.", "Then come on.", "We'll see.", "Don't blink."};

    private static final String[] CHARGE_REACT = {"Charging now?", "I won't give you time!", "You're wide open.", "Bad idea."};
    private static final String[] CHARGE_REACT_PROUD = {"Go ahead.", "Power up. I don't care.", "Show me everything.", "Don't hold back."};
    private static final String[] CHARGE_REACT_CALM = {"So that's your answer.", "I see.", "Then I'll respond.", "Take your time."};
    private static final String[] MIRROR_CHARGE = {"Then I'll raise mine too.", "Fine. Together, then.", "Let's see whose Ki breaks first.", "I can do that too."};
    private static final String[] LET_CHARGE = {"Go on. Power up.", "I'll wait.", "Show me your full strength.", "Don't disappoint me."};

    private static final String[] CAST_REACT = {"Too obvious!", "I see it!", "Not that easy.", "Here it comes..."};
    private static final String[] CAST_REACT_AGGRESSIVE = {"Too slow!", "I'll break through it!", "Try it!", "You're mine!"};
    private static final String[] CAST_REACT_CALM = {"There it is.", "I was waiting for that.", "Predictable.", "Now."};

    private static final String[] MIDFIGHT = {"Not bad.", "You're tougher than you look.", "Good hit.", "Now we're fighting."};
    private static final String[] MIDFIGHT_PROUD = {"Finally. Something interesting.", "That's more like it.", "You might entertain me yet.", "Don't slow down now."};
    private static final String[] MIDFIGHT_CALM = {"Your rhythm changed.", "I understand your style now.", "You're adapting.", "Good."};
    private static final String[] LOW_HEALTH = {"I'm not done yet.", "Still standing.", "One more round.", "Tch..."};
    private static final String[] LOW_HEALTH_PROUD = {"I refuse to fall here.", "You haven't won anything yet.", "I'm still standing!", "Again!"};
    private static final String[] LOW_HEALTH_CAUTIOUS = {"This is getting bad...", "I need an opening.", "Too much power...", "I can't trade hits like this."};

    private static final String[] RETREAT = {"This isn't worth dying for.", "I'm out.", "Another time.", "I know when I'm beaten."};
    private static final String[] DEFEAT = {"I yield.", "That's enough...", "You win.", "Damn..."};
    private static final String[] MAJOR = {"Take this!", "Try this one!", "Don't blink!", "Now!"};
    private static final String[] MAJOR_PROUD = {"Survive this.", "Let's end the warm-up.", "Take my full power!", "Don't look away."};
    private static final String[] MAJOR_CALM = {"This decides it.", "Opening found.", "Now.", "Your guard is gone."};

    private static final String[] POWER_UP = {"HAAAAA!", "I'm raising my Ki!", "Then let's get serious.", "No more holding back."};
    private static final String[] POWER_UP_PROUD = {"Watch closely.", "This is my real power.", "Try not to collapse.", "I'll show you the difference."};
    private static final String[] POWER_UP_REPLY = {"So you're finally serious.", "Good. Keep going.", "I can feel it rising...", "Now this is interesting."};
    private static final String[] POWER_READY = {"Come on!", "Now!", "Your turn.", "Let's continue."};

    private static final String[] AFTER_LAUNCH = {"Get up.", "We're not finished.", "Come back here!", "Too slow."};
    private static final String[] AFTER_LAUNCH_PROUD = {"Get up. I'm not finished with you.", "That can't be all.", "Stand up.", "Don't disappoint me now."};
    private static final String[] LAUNCH_REPLY = {"Still here.", "That hurt...", "Again!", "Not enough."};
    private static final String[] LAUNCH_REPLY_CALM = {"I see the timing now.", "I won't take that twice.", "Understood.", "So that's the angle."};

    private static final String[] VICTORY_GOOD = {"That's enough.", "Stay down. It's over.", "We're done here.", "No more."};
    private static final String[] VICTORY_NEUTRAL = {"Good fight.", "That's enough for me.", "You fought well.", "We'll stop here."};
    private static final String[] VICTORY_BAD = {"Pathetic.", "That's all?", "Stay down.", "You never had a chance."};

    private static final String[] RESCUED = {"You came... thank you.", "I thought I was finished.", "You got me out. Thanks.", "I owe you one."};
    private static final String[] CAPTIVE = {"Help!", "Frieza's soldiers have me pinned!", "Over here!", "Get these soldiers off me!"};

    public static String opening(RandomSource random, FighterAlignment alignment) {
        return opening(random, alignment, FighterPersonality.CALM);
    }

    public static String opening(RandomSource random, FighterAlignment alignment, FighterPersonality personality) {
        if (personality == FighterPersonality.PROUD && random.nextBoolean()) {
            return pick(random, new String[]{"You can make the first move.", "Try to impress me.", "I hope you're worth this.", "Show me."});
        }
        if (personality == FighterPersonality.AGGRESSIVE && random.nextBoolean()) {
            return pick(random, new String[]{"I'm done talking!", "Come here!", "You're finished!", "Let's go!"});
        }
        return pick(random, switch (alignment) {
            case GOOD -> OPEN_GOOD;
            case NEUTRAL -> OPEN_NEUTRAL;
            case BAD -> OPEN_BAD;
        });
    }

    public static String openingReply(RandomSource random, FighterAlignment alignment, FighterPersonality personality) {
        if (personality == FighterPersonality.PROUD) return pick(random, new String[]{"You first.", "Don't regret saying that.", "Good.", "Then begin."});
        if (personality == FighterPersonality.AGGRESSIVE) return pick(random, new String[]{"Gladly!", "Enough!", "Here I come!", "Too late!"});
        return pick(random, OPEN_REPLY);
    }

    public static String chargeReaction(RandomSource random) { return pick(random, CHARGE_REACT); }
    public static String chargeReaction(RandomSource random, FighterPersonality personality) {
        return pick(random, switch (personality) {
            case PROUD -> CHARGE_REACT_PROUD;
            case CALM -> CHARGE_REACT_CALM;
            default -> CHARGE_REACT;
        });
    }
    public static String mirrorCharge(RandomSource random) { return pick(random, MIRROR_CHARGE); }
    public static String letThemCharge(RandomSource random) { return pick(random, LET_CHARGE); }

    public static String castReaction(RandomSource random) { return pick(random, CAST_REACT); }
    public static String castReaction(RandomSource random, FighterPersonality personality) {
        return pick(random, switch (personality) {
            case AGGRESSIVE -> CAST_REACT_AGGRESSIVE;
            case CALM -> CAST_REACT_CALM;
            default -> CAST_REACT;
        });
    }

    public static String midfight(RandomSource random) { return pick(random, MIDFIGHT); }
    public static String midfight(RandomSource random, FighterPersonality personality) {
        return pick(random, switch (personality) {
            case PROUD -> MIDFIGHT_PROUD;
            case CALM -> MIDFIGHT_CALM;
            default -> MIDFIGHT;
        });
    }

    public static String lowHealth(RandomSource random) { return pick(random, LOW_HEALTH); }
    public static String lowHealth(RandomSource random, FighterPersonality personality) {
        return pick(random, switch (personality) {
            case PROUD, AGGRESSIVE -> LOW_HEALTH_PROUD;
            case CAUTIOUS -> LOW_HEALTH_CAUTIOUS;
            default -> LOW_HEALTH;
        });
    }

    public static String retreat(RandomSource random) { return pick(random, RETREAT); }
    public static String defeat(RandomSource random) { return pick(random, DEFEAT); }

    public static String major(RandomSource random) { return pick(random, MAJOR); }
    public static String major(RandomSource random, FighterPersonality personality) {
        return pick(random, switch (personality) {
            case PROUD, AGGRESSIVE -> MAJOR_PROUD;
            case CALM -> MAJOR_CALM;
            default -> MAJOR;
        });
    }

    public static String powerUp(RandomSource random, FighterPersonality personality) {
        return pick(random, personality == FighterPersonality.PROUD ? POWER_UP_PROUD : POWER_UP);
    }
    public static String powerUpReply(RandomSource random, FighterPersonality personality) {
        if (personality == FighterPersonality.AGGRESSIVE) return pick(random, new String[]{"I won't let you!", "Too slow!", "I'm coming in!", "Not happening!"});
        if (personality == FighterPersonality.PROUD) return pick(random, new String[]{"Keep going.", "More.", "Is that all?", "Good. Don't stop."});
        return pick(random, POWER_UP_REPLY);
    }
    public static String powerReady(RandomSource random, FighterPersonality personality) { return pick(random, POWER_READY); }

    public static String afterLaunch(RandomSource random, FighterPersonality personality) {
        return pick(random, personality == FighterPersonality.PROUD ? AFTER_LAUNCH_PROUD : AFTER_LAUNCH);
    }
    public static String launchReply(RandomSource random, FighterPersonality personality) {
        return pick(random, personality == FighterPersonality.CALM ? LAUNCH_REPLY_CALM : LAUNCH_REPLY);
    }

    public static String victory(RandomSource random, FighterAlignment alignment, FighterPersonality personality) {
        return pick(random, switch (alignment) {
            case GOOD -> VICTORY_GOOD;
            case NEUTRAL -> VICTORY_NEUTRAL;
            case BAD -> VICTORY_BAD;
        });
    }

    public static String rescued(RandomSource random) { return pick(random, RESCUED); }
    public static String captive(RandomSource random) { return pick(random, CAPTIVE); }

    private static String pick(RandomSource random, String[] pool) {
        return pool[random.nextInt(pool.length)];
    }
}
