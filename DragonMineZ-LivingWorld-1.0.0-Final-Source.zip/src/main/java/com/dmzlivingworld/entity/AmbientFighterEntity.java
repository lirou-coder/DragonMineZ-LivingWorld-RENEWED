package com.dmzlivingworld.entity;

import com.dragonminez.common.hair.CustomHair;
import com.dragonminez.common.hair.HairManager;
import com.dragonminez.common.init.entities.IBattlePower;
import com.dragonminez.common.init.MainSounds;
import com.dragonminez.common.init.entities.sagas.DBSagasEntity;
import com.dragonminez.common.stats.StatsCapability;
import com.dragonminez.common.stats.character.Character;
import com.dmzlivingworld.world.FighterCombatDirector;
import com.dmzlivingworld.world.FighterMemoryManager;
import com.dmzlivingworld.world.FighterArsenalManager;
import com.dmzlivingworld.world.FighterLegacyManager;
import com.dmzlivingworld.world.FighterGoalManager;
import com.dmzlivingworld.world.FighterInspectionManager;
import com.dmzlivingworld.world.FighterTechniqueManager;
import com.dmzlivingworld.world.FactionManager;
import com.dmzlivingworld.world.FactionRole;
import com.dmzlivingworld.world.FactionStructure;
import com.dmzlivingworld.world.FactionWorldData;
import com.dmzlivingworld.world.WorldFaction;
import com.dmzlivingworld.world.WantedManager;
import com.dmzlivingworld.world.WorldPowerScaler;
import com.dmzlivingworld.world.LivingBondManager;
import com.dmzlivingworld.world.PeacekeeperManager;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * Generic Earth fighter driven by DragonMineZ's DBSagasEntity combat brain.
 *
 * Living World supplies identity and high-level intent only. Once combat starts,
 * chasing, melee, dashing, aerial pursuit and Ki execution stay native to DMZ.
 */
public final class AmbientFighterEntity extends DBSagasEntity {
    private static final int DATA_VERSION = 16;
    private static final int TARGET_SCAN_INTERVAL = 20;
    private static final int SPECTATE_SCAN_INTERVAL = 40;
    private static final int RECOVERY_GRACE_TICKS = 100;

    private static final EntityDataAccessor<Boolean> READY =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> ALIGNMENT =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> RANK =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> PERSONALITY =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> RACE =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> ARCHETYPE =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> CAPTIVE =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<String> SPEECH =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> DEFEATED =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<String> FIGHTER_NAME =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> LEGACY_TITLE =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> AWAKENED =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> DISPLAY_SCALE =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<String> FACTION_ID =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> FACTION_LEADER =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> FACTION_ROLE =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<String> FACTION_NAME =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> FACTION_TITLE =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> AURA_FLARED =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> NON_COMBATANT =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<String> WANTED_ID =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> WANTED_LEVEL =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<String> WANTED_CRIME =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> MEDITATING =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> KAIOKEN_LEVEL =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> STORY_ROLE =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> FLIGHT_UNLOCKED =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> RACIAL_SKILL_LEVEL =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> ACTIVE_RACIAL_FORM_LEVEL =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);

    private static final EntityDataAccessor<Integer> GENDER =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> BODY_TYPE =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> EYES_TYPE =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> NOSE_TYPE =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> MOUTH_TYPE =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> HAIR_ID =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> OUTFIT =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<String> BODY_COLOR =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> BODY_COLOR2 =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> BODY_COLOR3 =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> HAIR_COLOR =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> EYE1_COLOR =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> EYE2_COLOR =
            SynchedEntityData.defineId(AmbientFighterEntity.class, EntityDataSerializers.STRING);

    private static final String[] SKIN_COLORS = {
            "#F5C9A6", "#E9B18D", "#D99A72", "#C17B58", "#9C6045", "#754531"
    };
    private static final String[] HAIR_COLORS = {
            "#151515", "#2A1C17", "#4B2A1A", "#70482A", "#B77A31", "#D9B75A", "#243A67", "#542B57"
    };
    private static final String[] EYE_COLORS = {
            "#2B211B", "#503522", "#6B4A2B", "#3E5F43", "#355C7D", "#566B85", "#6B456E"
    };
    private static final String[] NAMEK_GREEN = {"#1FAA24", "#2FB43A", "#168B24", "#49C451"};
    private static final String[] NAMEK_ACCENT = {"#BB2024", "#D13835", "#8F1A25", "#D85B42"};
    private static final String[] NAMEK_PINK = {"#FF86A6", "#EA6F96", "#FF9DB7"};
    private static final String[] MAJIN_COLORS = {"#FFA4FF", "#F18BEA", "#D979DF", "#FFB2D8"};
    private static final String[] FROST_MAIN = {"#FFFFFF", "#E9EEFF", "#ECE4F5", "#DDEEFF"};
    private static final String[] FROST_SECOND = {"#E8A2FF", "#B99CFF", "#88C8FF", "#F0B0E6"};
    private static final String[] FROST_ACCENT = {"#FF39A9", "#7E59FF", "#44BCEB", "#D92774"};
    private static final String[] BIO_MAIN = {"#187600", "#247E16", "#326B24", "#0D6446"};
    private static final String[] BIO_SECOND = {"#9FE321", "#7FCF27", "#B1D54E", "#5EBF69"};
    private static final String[] BIO_ACCENT = {"#FF7600", "#E84C20", "#E9BD25", "#C84639"};

    private boolean combatConfigured;
    private int defeatedTicks;
    private int recoveryGraceTicks;
    private int retreatTicks;
    private UUID retreatThreatId;
    private UUID duelOpponentId;
    private int speechTicks;
    private int cinematicLaunchCooldown;
    private int awakeningTicks;
    private UUID memoryOwnerId;
    private UUID memoryRecordId;
    private int memoryEncounters;
    private int memoryRelationship;
    private boolean memoryRescued;
    private UUID partyId;
    private boolean partyCaptain;
    private long lastFactionRepHitTick = Long.MIN_VALUE;
    private int auraFlareTicks;
    private UUID lastAuraTargetId;
    private boolean angerAuraUsed;
    private int foodSupplies;
    private int senzuBeans;
    private int supplyCooldown;
    private boolean regionalPresence;
    private int factionMerit;
    private int meditationTicks;
    private int meditationSessionLength;
    private int meditationHarmonyTicks;
    private int meditationCooldown;
    private int trainingSessions;
    private String mentorName = "";
    private String rivalName = "";
    private boolean kaiokenPotential;
    private int kaiokenTicks;
    private int kaiokenBasePower;
    private double kaiokenBaseAttack;
    private double kaiokenBaseSpeed;
    private float kaiokenBaseKiDamage;
    private String kaiokenBaseAuraType = "";
    private int kaiokenBaseAuraColor = 0xFFFFFF;
    private int racialTrainingProgress;
    private boolean racialTransformPending;
    private int racialCalmTicks;
    private int racialBasePower;
    private double racialBaseAttack;
    private double racialBaseSpeed;
    private double racialBaseAttackSpeed;
    private float racialBaseKiDamage;
    private float racialBaseScale = 1.0F;
    private String racialBaseHairColor = "";
    private String racialBaseEye1Color = "";
    private String racialBaseEye2Color = "";
    private String racialBaseAuraType = "";
    private int racialBaseAuraColor = 0xFFFFFF;
    private boolean racialBaseLightning;
    // 0.8.0: persistent, event-derived character history and real DMZ equipment state.
    private CompoundTag legacyData = new CompoundTag();
    private boolean arsenalInitialized;
    private int arsenalWeaponCooldown;

    public static final int STORY_NONE = 0;
    public static final int STORY_ALLY = 1;
    public static final int STORY_ENEMY = 2;
    public static final int STORY_CAPTIVE = 3;
    public static final int STORY_PEACEKEEPER = 4;

    public AmbientFighterEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        setTransformationDisabled(true);
        setDBZStyle(0);

        // DBSagasEntity normally auto-acquires players/villagers/golems. Remove only
        // those target goals; DMZ movement, melee, dash, flight and HurtByTargetGoal stay.
        removeAutomaticHostilityGoals();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return DBSagasEntity.createAttributes();
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(READY, false);
        entityData.define(ALIGNMENT, FighterAlignment.NEUTRAL.id());
        entityData.define(RANK, FighterRank.ROOKIE.id());
        entityData.define(PERSONALITY, FighterPersonality.CALM.id());
        entityData.define(RACE, FighterRace.HUMAN.id());
        entityData.define(ARCHETYPE, FighterArchetype.MARTIAL_ARTIST.id());
        entityData.define(CAPTIVE, false);
        entityData.define(SPEECH, "");
        entityData.define(DEFEATED, false);
        entityData.define(FIGHTER_NAME, "Fighter");
        entityData.define(LEGACY_TITLE, "");
        entityData.define(AWAKENED, false);
        entityData.define(DISPLAY_SCALE, 1.0F);
        entityData.define(FACTION_ID, "");
        entityData.define(FACTION_LEADER, false);
        entityData.define(FACTION_ROLE, FactionRole.MEMBER.id());
        entityData.define(FACTION_NAME, "");
        entityData.define(FACTION_TITLE, "");
        entityData.define(AURA_FLARED, false);
        entityData.define(NON_COMBATANT, false);
        entityData.define(WANTED_ID, "");
        entityData.define(WANTED_LEVEL, 0);
        entityData.define(WANTED_CRIME, "");
        entityData.define(MEDITATING, false);
        entityData.define(KAIOKEN_LEVEL, 0);
        entityData.define(STORY_ROLE, STORY_NONE);
        entityData.define(FLIGHT_UNLOCKED, false);
        entityData.define(RACIAL_SKILL_LEVEL, 0);
        entityData.define(ACTIVE_RACIAL_FORM_LEVEL, 0);

        entityData.define(GENDER, 0);
        entityData.define(BODY_TYPE, 1);
        entityData.define(EYES_TYPE, 0);
        entityData.define(NOSE_TYPE, 0);
        entityData.define(MOUTH_TYPE, 0);
        entityData.define(HAIR_ID, 1);
        entityData.define(OUTFIT, 0);
        entityData.define(BODY_COLOR, "#E9B18D");
        entityData.define(BODY_COLOR2, "#E9B18D");
        entityData.define(BODY_COLOR3, "#E9B18D");
        entityData.define(HAIR_COLOR, "#151515");
        entityData.define(EYE1_COLOR, "#503522");
        entityData.define(EYE2_COLOR, "#2B211B");
    }

    /** Called by the encounter manager or debug command for a freshly created fighter. */
    public void initializeAs(FighterAlignment alignment, FighterRank rank) {
        RandomSource random = getRandom();
        initializeAs(alignment, rank, FighterPersonality.roll(random, alignment),
                FighterRace.roll(random), FighterArchetype.roll(random, rank));
    }

    public void initializeAs(FighterAlignment alignment, FighterRank rank, FighterPersonality personality) {
        RandomSource random = getRandom();
        initializeAs(alignment, rank, personality, FighterRace.roll(random), FighterArchetype.roll(random, rank));
    }

    public void initializeAs(FighterAlignment alignment, FighterRank rank, FighterPersonality personality,
                             FighterRace race, FighterArchetype archetype) {
        RandomSource random = getRandom();
        entityData.set(ALIGNMENT, alignment.id());
        entityData.set(RANK, rank.id());
        entityData.set(PERSONALITY, personality.id());
        entityData.set(RACE, race.id());
        entityData.set(ARCHETYPE, archetype.id());
        entityData.set(CAPTIVE, false);
        entityData.set(SPEECH, "");
        entityData.set(DEFEATED, false);
        entityData.set(AWAKENED, false);
        randomizeNativeAppearance(random);
        entityData.set(FIGHTER_NAME, FighterNames.roll(random, race, isFemale()));
        setBattlePower(rank.rollBattlePower(random));
        entityData.set(READY, true);
        defeatedTicks = 0;
        recoveryGraceTicks = 0;
        retreatTicks = 0;
        retreatThreatId = null;
        duelOpponentId = null;
        speechTicks = 0;
        cinematicLaunchCooldown = 0;
        awakeningTicks = 0;
        memoryOwnerId = null;
        memoryRecordId = null;
        memoryEncounters = 0;
        memoryRelationship = 0;
        memoryRescued = false;
        entityData.set(FACTION_ID, "");
        entityData.set(FACTION_LEADER, false);
        entityData.set(FACTION_ROLE, FactionRole.MEMBER.id());
        entityData.set(FACTION_NAME, "");
        entityData.set(FACTION_TITLE, "");
        entityData.set(AURA_FLARED, false);
        entityData.set(NON_COMBATANT, false);
        entityData.set(WANTED_ID, "");
        entityData.set(WANTED_LEVEL, 0);
        entityData.set(WANTED_CRIME, "");
        entityData.set(MEDITATING, false);
        entityData.set(KAIOKEN_LEVEL, 0);
        entityData.set(STORY_ROLE, STORY_NONE);
        entityData.set(FLIGHT_UNLOCKED, rollInitialFlight(random, rank));
        entityData.set(RACIAL_SKILL_LEVEL, rollInitialRacialSkill(random, rank, race));
        entityData.set(ACTIVE_RACIAL_FORM_LEVEL, 0);
        racialTrainingProgress = 0;
        racialTransformPending = false;
        racialCalmTicks = 0;
        auraFlareTicks = 0;
        lastAuraTargetId = null;
        angerAuraUsed = false;
        foodSupplies = 0;
        senzuBeans = 0;
        supplyCooldown = 0;
        regionalPresence = false;
        factionMerit = 0;
        meditationTicks = 0;
        meditationSessionLength = 0;
        meditationHarmonyTicks = 0;
        meditationCooldown = 100 + random.nextInt(301);
        trainingSessions = 0;
        mentorName = "";
        rivalName = "";
        kaiokenPotential = rollKaiokenPotential(random);
        kaiokenTicks = 0;
        kaiokenBasePower = 0;
        partyId = null;
        partyCaptain = false;
        lastFactionRepHitTick = Long.MIN_VALUE;
        legacyData = new CompoundTag();
        entityData.set(LEGACY_TITLE, "");
        arsenalInitialized = false;
        arsenalWeaponCooldown = 0;
        setTransforming(false);
        setLightning(false);
        combatConfigured = false;
        configureCombatProfile(true);
    }

    @Override
    public void aiStep() {
        // Clear intent before native AI gets another chance to act while conceding.
        if (!level().isClientSide && (isDefeated() || isCaptive())) {
            suppressCombatIntent();
        }

        super.aiStep();
        if (level().isClientSide) return;

        if (!entityData.get(READY)) {
            FighterAlignment alignment = FighterAlignment.roll(getRandom());
            FighterRank rank = FighterRank.roll(getRandom());
            initializeAs(alignment, rank, FighterPersonality.roll(getRandom(), alignment), FighterRace.roll(getRandom()), FighterArchetype.roll(getRandom(), rank));
        } else if (!combatConfigured) {
            configureCombatProfile(false);
        }

        if (!arsenalInitialized) FighterArsenalManager.initializeNaturalLoadout(this);
        FighterLegacyManager.tickFusionObservation(this);
        FighterGoalManager.tick(this);
        if (tickCount % 60 == Math.floorMod(getUUID().hashCode(), 60)) FighterArsenalManager.tryPickupNearby(this);

        if (arsenalWeaponCooldown > 0) arsenalWeaponCooldown--;
        if (recoveryGraceTicks > 0) recoveryGraceTicks--;
        if (cinematicLaunchCooldown > 0) cinematicLaunchCooldown--;
        if (supplyCooldown > 0) supplyCooldown--;
        if (speechTicks > 0 && --speechTicks <= 0) entityData.set(SPEECH, "");
        if (meditationCooldown > 0) meditationCooldown--;
        if (isKaiokenActive()) tickKaioken();
        if (isRacialFormActive()) tickRacialForm();

        if (isCaptive()) {
            suppressCombatIntent();
            if (tickCount % 180 == 0 && getSpeech().isEmpty()) speak(FighterDialogue.captive(getRandom()), 60);
            return;
        }

        if (isMeditating()) {
            tickMeditation();
            return;
        }

        if (isDefeated()) {
            tickDefeated();
            return;
        }

        if (awakeningTicks > 0 || isTransforming()) {
            tickAwakening();
            return;
        }

        if (retreatTicks > 0) {
            tickRetreat();
            return;
        }

        if (isNonCombatant()) {
            // Residents/supporters are real Living World people, not secretly combat mobs.
            // They can be hurt/killed and participate in faction simulation, but do not
            // proactively fight until another system explicitly changes their occupation.
            suppressCombatIntent();
            tickAuraBehavior();
            tickFactionSupplies();
            FactionManager.tickMember(this);
            if (!isFactionMember() && tickCount % 1200 == Math.floorMod(getUUID().hashCode(), 1200)) FactionManager.tryRecruitWanderer(this);
            return;
        }

        if (tickCount % TARGET_SCAN_INTERVAL == 0) {
            maintainOrAcquireTarget();
        }

        if (getAlignment() == FighterAlignment.NEUTRAL
                && getTarget() == null
                && tickCount % SPECTATE_SCAN_INTERVAL == 0) {
            spectateNearbyFight();
        }

        tickAuraBehavior();
        tickFactionSupplies();
        tryStartKaioken();
        if (tickCount % 4 == Math.floorMod(getUUID().hashCode(), 4)) FighterArsenalManager.tickCombatEquipment(this);
        FighterCombatDirector.tick(this);
        FactionManager.tickMember(this);
        if (!isFactionMember() && tickCount % 1200 == Math.floorMod(getUUID().hashCode(), 1200)) FactionManager.tryRecruitWanderer(this);
        if (isWanted() && tickCount % 200 == 0) WantedManager.update(this);
    }

    private void configureCombatProfile(boolean refillHealth) {
        FighterRank rank = getRank();
        setAiTierById(rank.aiTier());
        setCanFly(hasFlightUnlocked() && !isNonCombatant());
        if (!hasFlightUnlocked() || isNonCombatant()) setFlying(false);

        var health = getAttribute(Attributes.MAX_HEALTH);
        if (health != null) health.setBaseValue(rank.maxHealth());
        var speed = getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) speed.setBaseValue(rank.speed());
        var attack = getAttribute(Attributes.ATTACK_DAMAGE);
        if (attack != null) attack.setBaseValue(rank.attackDamage());
        var range = getAttribute(Attributes.FOLLOW_RANGE);
        if (range != null) range.setBaseValue(rank == FighterRank.VETERAN ? 72.0D : 56.0D);

        FighterCombatDirector.configure(this);
        if (isAwakened() && !isRacialFormActive()) applyAwakenedCombatBoost();

        if (refillHealth) setHealth(getMaxHealth());
        else if (getHealth() > getMaxHealth()) setHealth(getMaxHealth());
        combatConfigured = true;
    }

    private void maintainOrAcquireTarget() {
        LivingEntity current = getTarget();
        if (current != null && (!current.isAlive() || !canAttack(current) || distanceToSqr(current) > 10000.0D)) {
            setTarget(null);
            current = null;
        }

        if (current != null) {
            if (!isDuelOpponent(current) && shouldRetreatFrom(current)) {
                beginRetreat(current);
            }
            return;
        }

        // Neutral fighters do not start trouble. HurtByTargetGoal still makes them
        // defend themselves, while scripted duels explicitly set an opponent.
        // Unaffiliated neutral fighters stay reactive. Affiliated neutral fighters must
        // still scan because generated faction relationships/reputation can make them hostile.
        if (getAlignment() == FighterAlignment.NEUTRAL && !isFactionMember()) return;

        List<LivingEntity> nearby = level().getEntitiesOfClass(
                LivingEntity.class,
                getBoundingBox().inflate(58.0D, 24.0D, 58.0D),
                this::isProactiveTarget
        );

        nearby.stream()
                .min(Comparator.comparingDouble(this::targetPriorityScore))
                .ifPresent(this::setTarget);
    }

    private double targetPriorityScore(LivingEntity target) {
        double distance = distanceToSqr(target);
        if (getAlignment() == FighterAlignment.GOOD && target instanceof AmbientFighterEntity bad
                && bad.getAlignment() == FighterAlignment.BAD && bad.getTarget() != null) {
            // A visible aggressor gets intervention priority over an idle threat.
            return distance * 0.28D;
        }
        return distance;
    }

    private boolean isProactiveTarget(LivingEntity target) {
        if (target == this || !target.isAlive() || !canAttack(target)) return false;
        if (target instanceof AmbientFighterEntity fighter && fighter.isRecovering()) return false;
        if (!isPowerAcceptableForProactiveFight(target)) return false;

        // Affiliated fighters obey their generated social map before broad alignment.
        if (isFactionMember() && target instanceof ServerPlayer player) {
            return FactionManager.shouldAttackPlayer(this, player);
        }
        if (isFactionMember() && target instanceof AmbientFighterEntity other && other.isFactionMember()) {
            if (FactionManager.areAllies(this, other)) return false;
            if (FactionManager.areEnemies(this, other)) return true;
            if (FactionManager.areRivals(this, other)) return isDuelOpponent(other);
        }

        return switch (getAlignment()) {
            case GOOD -> isThreatToEarth(target);
            case NEUTRAL -> false;
            case BAD -> isBadFighterVictim(target);
        };
    }

    private boolean isBadFighterVictim(LivingEntity target) {
        if (target instanceof Player player) return !player.isCreative() && !player.isSpectator();
        if (target instanceof Villager || target instanceof WanderingTrader || target instanceof IronGolem) return true;
        return target instanceof AmbientFighterEntity other && other.getAlignment() != FighterAlignment.BAD;
    }

    private boolean isThreatToEarth(LivingEntity target) {
        if (target instanceof AmbientFighterEntity other) return other.getAlignment() == FighterAlignment.BAD;

        ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(target.getType());
        if (key == null) return false;

        // Vanilla monsters are safe to interpret as local threats. For DMZ itself,
        // stay conservative and target only known hostile troop families rather than
        // accidentally treating every saga character as evil.
        if (target instanceof Monster && "minecraft".equals(key.getNamespace())) return true;
        if (!"dragonminez".equals(key.getNamespace())) return false;

        String path = key.getPath();
        return path.contains("friezasoldier")
                || path.contains("frieza_soldier")
                || path.contains("redribbon")
                || path.contains("red_ribbon")
                || path.contains("saibaman");
    }

    private boolean isPowerAcceptableForProactiveFight(LivingEntity target) {
        // Civilians and ordinary vanilla threats don't need a scouter calculation.
        if (!(target instanceof Player) && !(target instanceof DBSagasEntity) && !(target instanceof IBattlePower)) return true;

        double targetPower = estimateBattlePower(target);
        if (targetPower <= 0.0D) return true;
        return targetPower <= Math.max(1.0D, getBattlePower()) * getPersonality().overwhelmingPowerRatio();
    }

    private boolean shouldRetreatFrom(LivingEntity threat) {
        if (isDuelOpponent(threat)) return false;

        float healthRatio = getMaxHealth() <= 0.0F ? 1.0F : getHealth() / getMaxHealth();
        if (healthRatio <= getPersonality().retreatHealthRatio()) return true;

        double threatPower = estimateBattlePower(threat);
        if (threatPower <= 0.0D) return false;
        return threatPower > Math.max(1.0D, getBattlePower()) * getPersonality().overwhelmingPowerRatio();
    }

    private double estimateBattlePower(LivingEntity target) {
        if (target instanceof DBSagasEntity sagaEntity) {
            return Math.max(1, sagaEntity.getBattlePower());
        }

        if (target instanceof IBattlePower battlePowerEntity) {
            return Math.max(1, battlePowerEntity.getBattlePower());
        }

        if (target instanceof Player player) {
            final double[] result = {0.0D};
            player.getCapability(StatsCapability.INSTANCE).ifPresent(stats -> result[0] = stats.getBattlePowerExact());
            if (result[0] > 0.0D) return result[0];
        }

        // Conservative fallback for entities without DMZ battle-power data.
        return Math.max(100.0D, target.getMaxHealth() * 45.0D);
    }

    private void beginRetreat(LivingEntity threat) {
        if (threat instanceof net.minecraft.server.level.ServerPlayer player) {
            FighterMemoryManager.rememberEscape(player, this);
        }
        if (getSpeech().isEmpty()) speak(FighterDialogue.retreat(getRandom()), 55);
        FighterCombatDirector.reset(this);
        retreatTicks = getPersonality() == FighterPersonality.CAUTIOUS ? 180 : 120;
        retreatThreatId = threat.getUUID();
        setTarget(null);
        interruptCombo();
        stopCasting();
        setAttacking(false);
        setFlying(false);
        getNavigation().stop();
    }

    private void tickRetreat() {
        setTarget(null);
        if (retreatTicks-- <= 0) {
            retreatThreatId = null;
            return;
        }

        LivingEntity threat = findLivingByUuid(retreatThreatId, 80.0D);
        if (threat == null || !threat.isAlive()) {
            retreatTicks = 0;
            retreatThreatId = null;
            return;
        }

        if (tickCount % 12 == 0) {
            double dx = getX() - threat.getX();
            double dz = getZ() - threat.getZ();
            double length = Math.sqrt(dx * dx + dz * dz);
            if (length < 0.01D) {
                dx = getRandom().nextDouble() - 0.5D;
                dz = getRandom().nextDouble() - 0.5D;
                length = Math.sqrt(dx * dx + dz * dz);
            }
            double scale = 20.0D / Math.max(0.01D, length);
            getNavigation().moveTo(getX() + dx * scale, getY(), getZ() + dz * scale, 1.28D);
        }
    }

    private LivingEntity findLivingByUuid(UUID uuid, double radius) {
        if (uuid == null) return null;
        List<LivingEntity> nearby = level().getEntitiesOfClass(
                LivingEntity.class,
                getBoundingBox().inflate(radius),
                entity -> uuid.equals(entity.getUUID())
        );
        return nearby.isEmpty() ? null : nearby.get(0);
    }

    private void spectateNearbyFight() {
        List<AmbientFighterEntity> fighters = level().getEntitiesOfClass(
                AmbientFighterEntity.class,
                getBoundingBox().inflate(24.0D, 12.0D, 24.0D),
                fighter -> fighter != this && fighter.isAlive() && fighter.getTarget() != null && !fighter.isDefeated()
        );
        fighters.stream()
                .min(Comparator.comparingDouble(this::distanceToSqr))
                .ifPresent(fighter -> getLookControl().setLookAt(fighter, 35.0F, 35.0F));
    }

    /**
     * Non-lethal Earth-fighter combat plus exaggerated impact spacing. The damage is
     * still DMZ's damage; Living World only adds a cinematic launch after selected
     * native combo hits so combat does not remain glued to one two-block square.
     */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        Entity attackerEntity = source.getEntity();
        if (!level().isClientSide && isMeditating()) stopMeditation(false);
        if (!level().isClientSide && attackerEntity instanceof ServerPlayer player) {
            PeacekeeperManager.onPlayerAggression(player, this, source);
        }
        if (!level().isClientSide && attackerEntity instanceof ServerPlayer player && isFactionMember()) {
            long now = level().getGameTime();
            if (lastFactionRepHitTick == Long.MIN_VALUE || now - lastFactionRepHitTick >= 100L) {
                FactionManager.onPlayerHitMember(player, this);
                lastFactionRepHitTick = now;
            }
        }
        if (attackerEntity instanceof AmbientFighterEntity attacker) {
            if (isDefeated() || recoveryGraceTicks > 0) return false;

            // The spectacle branch intentionally gives procedural NPC-vs-NPC fights
            // more room to breathe. Player damage is untouched; only Living World
            // fighters trade reduced effective damage with one another.
            amount *= 0.78F;
            float defeatFloor = Math.max(1.0F, getMaxHealth() * 0.08F);
            if (getHealth() - amount <= defeatFloor) {
                // Rivalries/training remain non-lethal. Actual enemy organizations can
                // occasionally create real casualties so faction momentum, recruitment
                // and leadership succession have something meaningful to respond to.
                boolean seriousFactionWar = isFactionMember() && attacker.isFactionMember()
                        && FactionManager.areEnemies(attacker, this);
                float lethalChance = getFactionRole() == FactionRole.LEADER ? 0.22F
                        : getFactionRole() == FactionRole.LIEUTENANT ? 0.30F : 0.38F;
                if (!seriousFactionWar || getRandom().nextFloat() >= lethalChance) {
                    enterDefeated(attacker);
                    return true;
                }
                // Let DMZ/Minecraft process the real finishing hit. No resurrection is
                // performed for this individual; the organization recruits replacements.
                return super.hurt(source, Math.max(amount, getHealth() + 1.0F));
            }

            boolean damaged = super.hurt(source, amount);
            if (damaged) maybeApplyCinematicLaunch(attacker);
            return damaged;
        }
        return super.hurt(source, amount);
    }

    private void maybeApplyCinematicLaunch(AmbientFighterEntity attacker) {
        if (cinematicLaunchCooldown > 0 || attacker == null || !attacker.isComboing()) return;

        int combo = attacker.getComboId();
        boolean meteor = combo == DBSagasEntity.ComboType.METEOR_COMBINATION.getId();
        boolean air = combo == DBSagasEntity.ComboType.AIR.getId();
        boolean rapid = combo == DBSagasEntity.ComboType.RAPID_KICKS.getId();
        if (!meteor && !air && !(rapid && attacker.getRandom().nextFloat() < 0.28F)) return;

        // 0.6.10 keeps the stronger impact spacing while reducing repetition. Major native
        // combo hits should visibly relocate the fight instead of keeping both actors
        // glued to the same block.
        double horizontal = meteor ? 2.22D : air ? 1.76D : 1.08D;
        double vertical = meteor ? 1.02D : air ? 1.18D : 0.48D;
        if (attacker.getRank() == FighterRank.VETERAN) {
            horizontal *= 1.22D;
            vertical *= 1.18D;
        }

        double dx = getX() - attacker.getX();
        double dz = getZ() - attacker.getZ();
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length < 0.01D) length = 1.0D;
        setDeltaMovement(getDeltaMovement().add(dx / length * horizontal, vertical, dz / length * horizontal));
        cinematicLaunchCooldown = meteor ? 52 : air ? 42 : 34;
        FighterCombatDirector.onCinematicLaunch(attacker, this);
    }

    private void enterDefeated(AmbientFighterEntity victor) {
        entityData.set(DEFEATED, true);
        speak(FighterDialogue.defeat(getRandom()), 65);
        FighterCombatDirector.reset(this);
        defeatedTicks = 160 + getRandom().nextInt(101); // 8-13 seconds.
        setHealth(Math.max(1.0F, getMaxHealth() * 0.08F));
        suppressCombatIntent();

        if (victor != null) {
            FighterLegacyManager.recordConcession(victor, this);
            FactionManager.onConcessionVictory(victor, this);
            // A final launch makes the concession read as an actual finish rather than
            // a health-threshold toggle, then the victor deliberately disengages.
            double dx = getX() - victor.getX();
            double dz = getZ() - victor.getZ();
            double length = Math.max(0.01D, Math.sqrt(dx * dx + dz * dz));
            setDeltaMovement(getDeltaMovement().add(dx / length * 1.35D, 0.58D, dz / length * 1.35D));
            FighterCombatDirector.onVictory(victor, this);
            victor.setTarget(null);
            if (victor.isDuelOpponent(this)) victor.clearDuelOpponent();
        }
        clearDuelOpponent();
    }

    private void tickDefeated() {
        suppressCombatIntent();
        if (defeatedTicks-- > 0) return;

        entityData.set(DEFEATED, false);
        recoveryGraceTicks = RECOVERY_GRACE_TICKS;
        setHealth(Math.max(1.0F, getMaxHealth() * 0.38F));
        setCanFly(getRank().canFly());
    }

    private void suppressCombatIntent() {
        setTarget(null);
        interruptCombo();
        stopCasting();
        setAttacking(false);
        setKiCharge(false);
        setFlying(false);
        getNavigation().stop();
    }

    public void startDuel(AmbientFighterEntity opponent) {
        if (opponent == null || opponent == this) return;
        duelOpponentId = opponent.getUUID();
        setTarget(opponent);
    }

    public void clearDuelOpponent() {
        duelOpponentId = null;
        if (getTarget() instanceof AmbientFighterEntity other && other.getAlignment() == getAlignment()) {
            setTarget(null);
        }
    }

    public boolean isDuelOpponent(Entity entity) {
        return entity != null && duelOpponentId != null && duelOpponentId.equals(entity.getUUID());
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        if (isDefeated() || isCaptive() || isNonCombatant() || isMeditating()) return false;
        if (target instanceof Player player && (player.isCreative() || player.isSpectator())) return false;
        if (target instanceof AmbientFighterEntity other) {
            if (other.isDefeated() || other.isRecovering()) return false;
            // Peacekeeper interventions are an explicit third-party law-enforcement scene.
            // They must be allowed to engage BAD fighters even when the factions' long-term
            // diplomatic relation is only Rival/Neutral, and BAD fighters may fight back.
            if ((getStoryRole() == STORY_PEACEKEEPER && other.getAlignment() == FighterAlignment.BAD)
                    || (other.getStoryRole() == STORY_PEACEKEEPER && getAlignment() == FighterAlignment.BAD))
                return super.canAttack(target);
            if (isFactionMember() && other.isFactionMember()) {
                if (getFactionId().equals(other.getFactionId()) && !isDuelOpponent(other)) return false;
                if (FactionManager.areAllies(this, other) && !isDuelOpponent(other)) return false;
                if (FactionManager.areEnemies(this, other) || isDuelOpponent(other)) return super.canAttack(target);
                // Two affiliated groups with no hostile relationship do not start accidental infighting.
                return false;
            }
            if (other.getAlignment() == getAlignment() && !isDuelOpponent(other)) return false;
        }
        return super.canAttack(target);
    }

    @Override
    public boolean isAlliedTo(Entity entity) {
        if (entity instanceof AmbientFighterEntity other) {
            if (isFactionMember() && other.isFactionMember()) {
                if (getFactionId().equals(other.getFactionId())) return !isDuelOpponent(other);
                return FactionManager.areAllies(this, other) && !isDuelOpponent(other);
            }
            if (other.getAlignment() == getAlignment()) return !isDuelOpponent(other);
        }
        return super.isAlliedTo(entity);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return super.mobInteract(player, hand);

        ItemStack held = player.getItemInHand(hand);

        // Living World only takes over deliberate sneak interactions. Normal right-click
        // is left to Minecraft/DMZ so inspecting a fighter does not interfere with ordinary use.
        if (!player.isShiftKeyDown()) return super.mobInteract(player, hand);

        // Existing companion/bond actions keep priority on sneak + empty hand.
        // If there is no pending bond action, the same deliberate interaction opens the profile.
        if (held.isEmpty()) {
            if (!level().isClientSide && player instanceof ServerPlayer serverPlayer
                    && LivingBondManager.tryHandleInteraction(serverPlayer, this)) {
                return InteractionResult.CONSUME;
            }
            if (!level().isClientSide && player instanceof ServerPlayer serverPlayer) {
                FighterInspectionManager.inspect(serverPlayer, this, false);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        // Sneak + scouter opens the detailed profile while normal scouter use remains DMZ-native.
        if (FighterInspectionManager.isScouter(held)) {
            if (!level().isClientSide && player instanceof ServerPlayer serverPlayer) {
                FighterInspectionManager.inspect(serverPlayer, this, true);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        // Sneak + supported equipment is an intentional gift.
        if (!level().isClientSide && player instanceof ServerPlayer serverPlayer
                && FighterArsenalManager.tryGift(serverPlayer, this, held, false)) {
            serverPlayer.displayClientMessage(Component.literal("[Living World] ").withStyle(ChatFormatting.GOLD)
                    .append(Component.literal(getFighterName() + " accepted the equipment. Equipment: "
                            + FighterArsenalManager.summary(this)).withStyle(ChatFormatting.GRAY)), false);
            return InteractionResult.CONSUME;
        }

        return super.mobInteract(player, hand);
    }

    private void randomizeNativeAppearance(RandomSource random) {
        FighterRace race = getRace();
        // Keep applicable races visibly mixed rather than letting a small test sample
        // accidentally look single-gender. 46% female is close to even while still random.
        entityData.set(GENDER, race.gendered() && random.nextFloat() < 0.46F ? 1 : 0);
        float scale = rollNaturalScale(random, race, isFemale());
        entityData.set(DISPLAY_SCALE, scale);
        setScaleVal(scale);
        entityData.set(HAIR_COLOR, pick(random, HAIR_COLORS));
        entityData.set(EYE1_COLOR, pick(random, EYE_COLORS));
        entityData.set(EYE2_COLOR, pick(random, EYE_COLORS));

        switch (race) {
            case HUMAN, SAIYAN -> {
                entityData.set(BODY_TYPE, 1 + random.nextInt(2));
                entityData.set(EYES_TYPE, random.nextInt(13));
                entityData.set(NOSE_TYPE, random.nextInt(6));
                entityData.set(MOUTH_TYPE, random.nextInt(9));
                entityData.set(HAIR_ID, 1 + random.nextInt(Math.max(1, HairManager.getPresetCount())));
                entityData.set(OUTFIT, random.nextInt(race == FighterRace.SAIYAN ? 14 : 16));
                String skin = pick(random, SKIN_COLORS);
                entityData.set(BODY_COLOR, skin);
                entityData.set(BODY_COLOR2, race == FighterRace.SAIYAN ? "#572117" : skin);
                entityData.set(BODY_COLOR3, skin);
            }
            case NAMEKIAN -> {
                entityData.set(BODY_TYPE, random.nextInt(4)); // selects native warrior/trader variant
                entityData.set(EYES_TYPE, random.nextInt(5));
                entityData.set(NOSE_TYPE, random.nextInt(2));
                entityData.set(MOUTH_TYPE, random.nextInt(2));
                entityData.set(HAIR_ID, 0);
                entityData.set(OUTFIT, random.nextInt(2)); // warrior / trader family
                entityData.set(BODY_COLOR, pick(random, NAMEK_GREEN));
                entityData.set(BODY_COLOR2, pick(random, NAMEK_ACCENT));
                entityData.set(BODY_COLOR3, pick(random, NAMEK_PINK));
            }
            case MAJIN -> {
                entityData.set(BODY_TYPE, random.nextInt(3));
                entityData.set(EYES_TYPE, random.nextInt(2));
                entityData.set(NOSE_TYPE, random.nextInt(2));
                entityData.set(MOUTH_TYPE, random.nextInt(2));
                entityData.set(HAIR_ID, 0);
                entityData.set(OUTFIT, random.nextInt(6));
                String main = pick(random, MAJIN_COLORS);
                entityData.set(BODY_COLOR, main);
                entityData.set(BODY_COLOR2, main);
                entityData.set(BODY_COLOR3, main);
            }
            case FROST_DEMON -> {
                entityData.set(BODY_TYPE, random.nextInt(3));
                entityData.set(EYES_TYPE, random.nextInt(6));
                entityData.set(NOSE_TYPE, random.nextInt(2));
                entityData.set(MOUTH_TYPE, random.nextInt(2));
                entityData.set(HAIR_ID, 0);
                entityData.set(OUTFIT, 0);
                entityData.set(BODY_COLOR, pick(random, FROST_MAIN));
                entityData.set(BODY_COLOR2, pick(random, FROST_SECOND));
                entityData.set(BODY_COLOR3, pick(random, FROST_ACCENT));
            }
            case BIO_ANDROID -> {
                entityData.set(BODY_TYPE, random.nextInt(3));
                entityData.set(EYES_TYPE, 0);
                entityData.set(NOSE_TYPE, 0);
                entityData.set(MOUTH_TYPE, 0);
                entityData.set(HAIR_ID, 0);
                entityData.set(OUTFIT, 0);
                entityData.set(BODY_COLOR, pick(random, BIO_MAIN));
                entityData.set(BODY_COLOR2, pick(random, BIO_SECOND));
                entityData.set(BODY_COLOR3, pick(random, BIO_ACCENT));
            }
        }
    }

    private static float rollNaturalScale(RandomSource random, FighterRace race, boolean female) {
        float min = switch (race) {
            case HUMAN, SAIYAN -> female ? 0.90F : 0.94F;
            case NAMEKIAN -> 0.96F;
            case MAJIN -> female ? 0.89F : 0.93F;
            case FROST_DEMON -> 0.91F;
            case BIO_ANDROID -> 0.96F;
        };
        float max = switch (race) {
            case HUMAN, SAIYAN -> female ? 1.055F : 1.10F;
            case NAMEKIAN -> 1.13F;
            case MAJIN -> female ? 1.06F : 1.12F;
            case FROST_DEMON -> 1.08F;
            case BIO_ANDROID -> 1.12F;
        };
        // Triangular distribution: extremes exist, but most people stay around average.
        float t = (random.nextFloat() + random.nextFloat()) * 0.5F;
        return min + (max - min) * t;
    }

    private static String pick(RandomSource random, String[] values) {
        return values[random.nextInt(values.length)];
    }

    public FighterAlignment getAlignment() { return FighterAlignment.byId(entityData.get(ALIGNMENT)); }
    public FighterRank getRank() { return FighterRank.byId(entityData.get(RANK)); }
    public FighterPersonality getPersonality() { return FighterPersonality.byId(entityData.get(PERSONALITY)); }
    public FighterRace getRace() { return FighterRace.byId(entityData.get(RACE)); }
    public FighterArchetype getArchetype() { return FighterArchetype.byId(entityData.get(ARCHETYPE)); }
    public String getFighterName() { return entityData.get(FIGHTER_NAME); }
    public boolean isDefeated() { return entityData.get(DEFEATED); }
    public boolean isRecovering() { return recoveryGraceTicks > 0 || isDefeated(); }
    public boolean isCaptive() { return entityData.get(CAPTIVE); }
    public String getSpeech() { return entityData.get(SPEECH); }
    public boolean isRetreating() { return retreatTicks > 0; }
    public boolean isAwakened() { return entityData.get(AWAKENED); }
    public boolean isAwakening() { return awakeningTicks > 0 || isTransforming(); }
    public float getDisplayScale() { return entityData.get(DISPLAY_SCALE); }
    public String genderLabel() { return getRace().gendered() ? (isFemale() ? "Female" : "Male") : "—"; }

    public void setPersonality(FighterPersonality personality) {
        entityData.set(PERSONALITY, personality.id());
    }

    public boolean isFemale() { return entityData.get(GENDER) == 1; }
    public void forceGender(boolean female) { if (getRace().gendered()) entityData.set(GENDER, female ? 1 : 0); }
    public int getBodyType() { return entityData.get(BODY_TYPE); }
    public int getEyesType() { return entityData.get(EYES_TYPE); }
    public int getNoseType() { return entityData.get(NOSE_TYPE); }
    public int getMouthType() { return entityData.get(MOUTH_TYPE); }
    public int getHairId() { return entityData.get(HAIR_ID); }
    public int getOutfit() { return entityData.get(OUTFIT); }
    public String getBodyColor() { return entityData.get(BODY_COLOR); }
    public String getBodyColor2() { return entityData.get(BODY_COLOR2); }
    public String getBodyColor3() { return entityData.get(BODY_COLOR3); }
    public String getHairColor() { return entityData.get(HAIR_COLOR); }
    public String getEye1Color() { return entityData.get(EYE1_COLOR); }
    public String getEye2Color() { return entityData.get(EYE2_COLOR); }
    public String getFactionId() { return entityData.get(FACTION_ID); }
    public boolean isFactionMember() { return !getFactionId().isBlank(); }
    public boolean isFactionLeader() { return entityData.get(FACTION_LEADER); }
    public FactionRole getFactionRole() { return FactionRole.byId(entityData.get(FACTION_ROLE)); }
    public String getFactionDisplayName() { return entityData.get(FACTION_NAME); }
    public String getFactionTitle() { return entityData.get(FACTION_TITLE); }
    public boolean isAuraFlared() { return entityData.get(AURA_FLARED); }
    public boolean isNonCombatant() { return entityData.get(NON_COMBATANT); }
    public String getWantedId() { return entityData.get(WANTED_ID); }
    public int getWantedLevel() { return entityData.get(WANTED_LEVEL); }
    public boolean isWanted() { return getWantedLevel() > 0; }
    public String getWantedCrime() { return entityData.get(WANTED_CRIME); }
    public boolean isRegionalPresence() { return regionalPresence; }
    public int getFactionMerit() { return factionMerit; }
    public int getFoodSupplies() { return foodSupplies; }
    public int getSenzuBeans() { return senzuBeans; }
    public boolean hasParty() { return partyId != null; }
    public boolean isPartyCaptain() { return partyCaptain; }
    public UUID getPartyId() { return partyId; }
    public boolean sameParty(AmbientFighterEntity other) {
        return other != null && partyId != null && partyId.equals(other.partyId);
    }

    public void setNonCombatant(boolean value) {
        entityData.set(NON_COMBATANT, value);
        if (value) {
            suppressCombatIntent();
            setCanFly(false);
        } else {
            setCanFly(hasFlightUnlocked());
        }
    }

    public void markWanted(String wantedId, int level, String crime) {
        entityData.set(WANTED_ID, wantedId == null ? "" : wantedId);
        entityData.set(WANTED_LEVEL, Math.max(0, Math.min(5, level)));
        entityData.set(WANTED_CRIME, crime == null ? "" : crime);
        if (level > 0) setPersistenceRequired();
    }

    public void setFighterName(String name) {
        if (name != null && !name.isBlank()) entityData.set(FIGHTER_NAME, name);
    }

    public void addFactionMerit(int amount) { factionMerit = Math.max(0, factionMerit + Math.max(0, amount)); }

    public void setFactionRole(FactionRole role) {
        if (role == null || !isFactionMember()) return;
        entityData.set(FACTION_ROLE, role.id());
        entityData.set(FACTION_LEADER, role == FactionRole.LEADER);
        if (role.ordinal() >= FactionRole.LIEUTENANT.ordinal()) setPersistenceRequired();
        if (level() instanceof net.minecraft.server.level.ServerLevel serverLevel) {
            WorldFaction faction = FactionManager.byId(serverLevel, getFactionId());
            if (faction != null) {
                entityData.set(FACTION_NAME, faction.name());
                entityData.set(FACTION_TITLE, faction.roleTitle(role));
                applyFactionUniform(faction, role);
            }
        }
    }

    public void flareAura(int ticks) {
        if (level().isClientSide) return;
        boolean starting = !entityData.get(AURA_FLARED) && !isCharge() && !isTransforming();
        auraFlareTicks = Math.max(auraFlareTicks, Math.max(20, ticks));
        entityData.set(AURA_FLARED, true);
        if (starting) {
            // Use DMZ's own aura-start sound and DMZ's saga aura rendering pass.
            level().playSound(null, blockPosition(), MainSounds.AURA_START.get(), SoundSource.HOSTILE, 0.85F, 0.96F + getRandom().nextFloat() * 0.08F);
        }
    }

    public void assignFaction(WorldFaction faction, boolean leader, UUID newPartyId, boolean captain) {
        assignFaction(faction, leader ? FactionRole.LEADER : FactionRole.MEMBER, newPartyId, captain, false);
    }

    public void assignFaction(WorldFaction faction, FactionRole role, UUID newPartyId, boolean captain, boolean regional) {
        if (faction == null) return;
        entityData.set(FACTION_ID, faction.id());
        entityData.set(FACTION_ROLE, role.id());
        entityData.set(FACTION_LEADER, role == FactionRole.LEADER);
        entityData.set(FACTION_NAME, faction.name());
        entityData.set(FACTION_TITLE, faction.roleTitle(role));
        partyId = newPartyId;
        partyCaptain = captain;
        regionalPresence = regional;
        applyFactionUniform(faction, role);
        rollFactionSupplies(role);
        if (role == FactionRole.LEADER && level() instanceof net.minecraft.server.level.ServerLevel serverLevel) {
            FactionWorldData data = FactionWorldData.get(serverLevel);
            entityData.set(FIGHTER_NAME, data.currentLeaderName(faction));
            if (getRace().gendered()) entityData.set(GENDER, data.currentLeaderFemale(faction) ? 1 : 0);
        }
        // A regional cell is an actual resident presence, not a temporary locator hint.
        // Once a player discovers/loads it, its members are saved with that region.
        if (regional || role.ordinal() >= FactionRole.LIEUTENANT.ordinal()) setPersistenceRequired();
    }

    public void leaveFaction() {
        entityData.set(FACTION_ID, "");
        entityData.set(FACTION_LEADER, false);
        entityData.set(FACTION_ROLE, FactionRole.MEMBER.id());
        entityData.set(FACTION_NAME, "");
        entityData.set(FACTION_TITLE, "");
        partyId = null;
        partyCaptain = false;
        regionalPresence = false;
    }

    public void assignParty(UUID newPartyId, boolean captain) {
        partyId = newPartyId;
        partyCaptain = captain;
    }

    private void rollFactionSupplies(FactionRole role) {
        RandomSource random = getRandom();
        int foodBase = switch (role) {
            case RECRUIT -> random.nextInt(2);
            case MEMBER -> 1 + random.nextInt(2);
            case ENFORCER -> 1 + random.nextInt(3);
            case LIEUTENANT -> 2 + random.nextInt(3);
            case LEADER -> 3 + random.nextInt(3);
        };
        foodSupplies = Math.max(foodSupplies, foodBase);
        float senzuChance = switch (role) {
            case RECRUIT -> 0.01F; case MEMBER -> 0.06F; case ENFORCER -> 0.16F;
            case LIEUTENANT -> 0.38F; case LEADER -> 0.72F;
        };
        if (random.nextFloat() < senzuChance) senzuBeans = Math.max(senzuBeans, role == FactionRole.LEADER && random.nextFloat() < 0.35F ? 2 : 1);
    }

    private void tickFactionSupplies() {
        if (!isFactionMember() || supplyCooldown > 0 || isDefeated() || isCaptive() || isAwakening()) return;
        LivingEntity target = getTarget();
        float hp = getHealth() / Math.max(1.0F, getMaxHealth());

        // Senzu is rare and valuable: an NPC only risks using it when badly hurt and
        // it has enough separation to plausibly get the bean down.
        if (senzuBeans > 0 && hp < 0.28F && target != null && distanceToSqr(target) >= 49.0D
                && !isCasting() && !isComboing()) {
            senzuBeans--;
            supplyCooldown = 520;
            setHealth(getMaxHealth());
            level().playSound(null, blockPosition(), MainSounds.SENZU_BEAN.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
            speak("Senzu!", 36);
            flareAura(55);
            return;
        }

        // Ordinary provisions represent food/rest without inventing an inventory UI.
        // They are only used outside active combat and heal modestly.
        if (foodSupplies > 0 && target == null && hp < 0.72F
                && tickCount % 100 == Math.floorMod(getUUID().hashCode(), 100)) {
            foodSupplies--;
            supplyCooldown = 300;
            setHealth(Math.min(getMaxHealth(), getHealth() + getMaxHealth() * 0.22F));
            // Routine eating remains background behavior; no speech bubble for every snack.
        }
    }

    private void tickAuraBehavior() {
        if (auraFlareTicks > 0 && --auraFlareTicks <= 0 && !isCharge() && !isTransforming()) {
            entityData.set(AURA_FLARED, false);
        }

        LivingEntity target = getTarget();
        UUID currentTarget = target == null ? null : target.getUUID();
        if ((currentTarget == null && lastAuraTargetId != null)
                || (currentTarget != null && !currentTarget.equals(lastAuraTargetId))) {
            if (target == null) {
                angerAuraUsed = false;
            } else {
                float chance = switch (getPersonality()) {
                    case AGGRESSIVE -> 0.76F; case PROUD -> 0.70F; case HEROIC -> 0.58F;
                    case CALM -> 0.38F; case CAUTIOUS -> 0.32F;
                };
                if (isFactionMember() && getFactionRole().ordinal() >= FactionRole.ENFORCER.ordinal()) chance += 0.10F;
                if (getRandom().nextFloat() < Math.min(0.92F, chance)) {
                    flareAura(46 + getRandom().nextInt(75));
                }
            }
            lastAuraTargetId = currentTarget;
        }

        if (target != null && !angerAuraUsed && getHealth() < getMaxHealth() * 0.52F) {
            angerAuraUsed = true;
            float chance = getPersonality() == FighterPersonality.CALM ? 0.30F : 0.58F;
            if (getFactionRole().ordinal() >= FactionRole.LIEUTENANT.ordinal()) chance += 0.12F;
            if (getRandom().nextFloat() < Math.min(0.90F, chance)) {
                flareAura(90 + getRandom().nextInt(111));
                if (getSpeech().isEmpty() && getRandom().nextFloat() < 0.45F) speak("Enough.", 38);
            }
        }

        // Some experienced fighters deliberately keep their aura up after the fight has
        // escalated. It is a stable-ish personality tell, not a permanent effect on everyone.
        if (target != null && isAwakened() && !isAuraFlared() && !isCharge() && !isTransforming()
                && tickCount % 140 == Math.floorMod(getUUID().hashCode(), 140)
                && getRandom().nextFloat() < 0.42F) {
            flareAura(120 + getRandom().nextInt(161));
        }
    }

    public void varyFactionUniform(WorldFaction faction, int salt) {
        if (faction != null) applyFactionUniform(faction, getFactionRole(), salt);
    }

    private void applyFactionUniform(WorldFaction faction, FactionRole role) { applyFactionUniform(faction, role, 0); }

    private void applyFactionUniform(WorldFaction faction, FactionRole role, int salt) {
        // Same faction = recognizable visual family; same faction != clone army.
        // The seed chooses a stable family while UUID/rank chooses an individual variant.
        long identity = getUUID().getMostSignificantBits() ^ Long.rotateLeft(getUUID().getLeastSignificantBits(), 17);
        int variant = Math.floorMod((int)(identity ^ faction.seed()) + salt * 3, 11);
        int theme = faction.uniformTheme();
        int outfit = switch (getRace()) {
            case HUMAN, SAIYAN -> {
                int[] pool = switch (faction.structure()) {
                    case CULT -> new int[]{16,17,18,19,20,21};
                    case ORDER -> new int[]{16,20,21,3,8};
                    case CLAN -> new int[]{3,8,20,21,11};
                    case SCHOOL -> new int[]{0,3,4,8,9,14};
                    case GUARD -> new int[]{9,10,15,1,21};
                    case GANG, SYNDICATE -> new int[]{1,2,6,7,13,15,19};
                    case CREW -> new int[]{0,1,5,6,8,10,13};
                };
                int rankBias = role.ordinal() >= FactionRole.LIEUTENANT.ordinal() ? 2 : 0;
                yield pool[Math.floorMod(theme + variant + rankBias, pool.length)];
            }
            case NAMEKIAN -> Math.floorMod(theme + variant + role.id(), 2);
            case MAJIN -> Math.floorMod(theme + variant + role.id(), 6);
            case FROST_DEMON, BIO_ANDROID -> 0;
        };
        entityData.set(OUTFIT, outfit);

        // Cults/orders share a recognizable aura family even when individual clothing,
        // hair and faces differ. This uses DMZ's existing aura renderer/state.
        if (faction.structure() == FactionStructure.CULT || faction.structure() == FactionStructure.ORDER) {
            int[] ritualPalette = {0xB05CFF, 0xE75B8D, 0x5DE3D6, 0xF2C14E, 0x7F8CFF, 0xD9E4FF};
            int aura = ritualPalette[Math.floorMod(faction.uniformTheme(), ritualPalette.length)];
            setAuraColor(aura);
            setLightningColor(aura);
        }
    }


    /** Compact identity snapshot used by the selective recurring-fighter system. */
    public CompoundTag writeMemoryProfile() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("Alignment", getAlignment().id());
        tag.putInt("Rank", getRank().id());
        tag.putInt("Personality", getPersonality().id());
        tag.putInt("Race", getRace().id());
        tag.putInt("Archetype", getArchetype().id());
        tag.putString("Name", getFighterName());
        tag.putInt("BattlePower", getBattlePower());
        tag.put("Legacy", legacyData.copy());
        tag.putString("LegacyTitle", getLegacyTitle());
        FighterArsenalManager.writeProfile(this, tag);
        tag.putString("MentorName", mentorName);
        tag.putString("RivalName", rivalName);
        tag.putInt("TrainingSessions", trainingSessions);
        tag.putBoolean("FlightUnlocked", hasFlightUnlocked());
        tag.putInt("RacialSkillLevel", getRacialSkillLevel());
        tag.putInt("RacialTrainingProgress", racialTrainingProgress);
        tag.putBoolean("Awakened", isAwakened());
        tag.putFloat("DisplayScale", getDisplayScale());
        tag.putInt("Gender", entityData.get(GENDER));
        tag.putInt("BodyType", getBodyType());
        tag.putInt("EyesType", getEyesType());
        tag.putInt("NoseType", getNoseType());
        tag.putInt("MouthType", getMouthType());
        tag.putInt("HairId", getHairId());
        tag.putInt("Outfit", getOutfit());
        tag.putString("BodyColor", getBodyColor());
        tag.putString("BodyColor2", getBodyColor2());
        tag.putString("BodyColor3", getBodyColor3());
        tag.putString("HairColor", getHairColor());
        tag.putString("Eye1Color", getEye1Color());
        tag.putString("Eye2Color", getEye2Color());
        if (isFactionMember()) tag.putString("FactionId", getFactionId());
        tag.putBoolean("FactionLeader", isFactionLeader());
        tag.putInt("FactionRole", getFactionRole().id());
        return tag;
    }

    /** Recreates the same procedural person while allowing their PL to evolve between meetings. */
    public void initializeFromMemory(CompoundTag profile) {
        FighterAlignment alignment = FighterAlignment.byId(profile.getInt("Alignment"));
        FighterRank rank = FighterRank.byId(profile.getInt("Rank"));
        FighterPersonality personality = FighterPersonality.byId(profile.getInt("Personality"));
        FighterRace race = FighterRace.byId(profile.getInt("Race"));
        FighterArchetype archetype = FighterArchetype.byId(profile.getInt("Archetype"));
        initializeAs(alignment, rank, personality, race, archetype);

        if (profile.contains("Name")) entityData.set(FIGHTER_NAME, profile.getString("Name"));
        if (profile.contains("BattlePower")) setBattlePower(Math.max(1, profile.getInt("BattlePower")));
        legacyData = sanitizeLegacyData(profile.contains("Legacy", Tag.TAG_COMPOUND) ? profile.getCompound("Legacy").copy() : new CompoundTag());
        syncLegacyTitle();
        FighterArsenalManager.readProfile(this, profile);
        mentorName = profile.getString("MentorName");
        rivalName = profile.getString("RivalName");
        trainingSessions = profile.contains("TrainingSessions") ? profile.getInt("TrainingSessions") : trainingSessions;
        if (profile.contains("FlightUnlocked")) entityData.set(FLIGHT_UNLOCKED, profile.getBoolean("FlightUnlocked"));
        if (profile.contains("RacialSkillLevel")) entityData.set(RACIAL_SKILL_LEVEL, profile.getInt("RacialSkillLevel"));
        racialTrainingProgress = profile.contains("RacialTrainingProgress") ? profile.getInt("RacialTrainingProgress") : 0;
        entityData.set(ACTIVE_RACIAL_FORM_LEVEL, 0);
        float scale = profile.contains("DisplayScale") ? profile.getFloat("DisplayScale") : getDisplayScale();
        entityData.set(DISPLAY_SCALE, scale);
        setScaleVal(scale);
        if (profile.contains("Gender")) entityData.set(GENDER, profile.getInt("Gender"));
        if (profile.contains("BodyType")) entityData.set(BODY_TYPE, profile.getInt("BodyType"));
        if (profile.contains("EyesType")) entityData.set(EYES_TYPE, profile.getInt("EyesType"));
        if (profile.contains("NoseType")) entityData.set(NOSE_TYPE, profile.getInt("NoseType"));
        if (profile.contains("MouthType")) entityData.set(MOUTH_TYPE, profile.getInt("MouthType"));
        if (profile.contains("HairId")) entityData.set(HAIR_ID, profile.getInt("HairId"));
        if (profile.contains("Outfit")) entityData.set(OUTFIT, profile.getInt("Outfit"));
        if (profile.contains("BodyColor")) entityData.set(BODY_COLOR, profile.getString("BodyColor"));
        if (profile.contains("BodyColor2")) entityData.set(BODY_COLOR2, profile.getString("BodyColor2"));
        if (profile.contains("BodyColor3")) entityData.set(BODY_COLOR3, profile.getString("BodyColor3"));
        if (profile.contains("HairColor")) entityData.set(HAIR_COLOR, profile.getString("HairColor"));
        if (profile.contains("Eye1Color")) entityData.set(EYE1_COLOR, profile.getString("Eye1Color"));
        if (profile.contains("Eye2Color")) entityData.set(EYE2_COLOR, profile.getString("Eye2Color"));
        if (profile.contains("FactionId")) entityData.set(FACTION_ID, profile.getString("FactionId"));
        entityData.set(FACTION_LEADER, false); // leaders are world-persistent and never recreated by memory.
        entityData.set(FACTION_ROLE, profile.contains("FactionRole")
                ? Math.min(FactionRole.LIEUTENANT.id(), profile.getInt("FactionRole")) : FactionRole.MEMBER.id());
        boolean rememberedAwakened = profile.contains("Awakened") && profile.getBoolean("Awakened");
        entityData.set(AWAKENED, rememberedAwakened);
        setLightning(rememberedAwakened);
        combatConfigured = false;
        configureCombatProfile(true);
    }

    public void bindMemory(UUID ownerId, UUID recordId, int encounters, int relationship, boolean rescued) {
        this.memoryOwnerId = ownerId;
        this.memoryRecordId = recordId;
        this.memoryEncounters = Math.max(1, encounters);
        this.memoryRelationship = relationship;
        this.memoryRescued = rescued;
    }

    public boolean isRemembered() { return memoryRecordId != null; }
    public UUID getMemoryRecordId() { return memoryRecordId; }
    public UUID getMemoryOwnerId() { return memoryOwnerId; }
    public boolean isRememberedFor(Player player) {
        return player != null && memoryOwnerId != null && memoryOwnerId.equals(player.getUUID());
    }
    public int getMemoryEncounters() { return memoryEncounters; }
    public int getMemoryRelationship() { return memoryRelationship; }
    public boolean wasRescuedByMemoryOwner() { return memoryRescued; }


    /**
     * A pressured fighter either uses a race-appropriate form already learned through
     * training, or falls back to the older generic Awakening if they have no form skill.
     * The form path mirrors DMZ 2.1.3 main-tree unlock levels; legendary branches remain
     * out of procedural progression.
     */
    public boolean beginAwakening() {
        if (level().isClientSide || isAwakening() || isRacialFormActive() || isKaiokenActive()
                || getRank() == FighterRank.ROOKIE) return false;
        if (isAwakened() && getRacialSkillLevel() <= 0) return false;
        racialTransformPending = getRacialSkillLevel() > 0;
        awakeningTicks = getRank() == FighterRank.VETERAN ? 76 : 64;
        setTransforming(true);
        setKiCharge(true);
        RacialFormProfile next = racialTransformPending ? RacialFormProfile.forSkill(getRace(), getRacialSkillLevel()) : null;
        setLightning(next != null ? next.lightning() : (getRank() == FighterRank.VETERAN || getRandom().nextBoolean()));
        if (next != null && next.auraColor() != 0xFFFFFF) {
            setAuraType("kakarot");
            setAuraColor(next.auraColor());
        }
        interruptCombo();
        stopCasting();
        setAttacking(false);
        getNavigation().stop();
        level().playSound(null, blockPosition(), MainSounds.TRANSFORM_ON.get(), SoundSource.HOSTILE, 1.35F, 0.92F + getRandom().nextFloat() * 0.12F);
        return true;
    }

    private void tickAwakening() {
        LivingEntity target = getTarget();
        interruptCombo();
        stopCasting();
        setAttacking(false);
        setFlying(false);
        setKiCharge(true);
        getNavigation().stop();
        if (target != null && target.isAlive()) rotateBodyToTarget(target);

        if (awakeningTicks > 0) awakeningTicks--;
        if (awakeningTicks > 0) return;

        setTransforming(false);
        setKiCharge(false);
        if (racialTransformPending) {
            racialTransformPending = false;
            activateRacialForm();
            return;
        }

        entityData.set(AWAKENED, true);
        double multiplier = getRank() == FighterRank.VETERAN ? 1.72D : 1.42D;
        setBattlePower((int)Math.min(Integer.MAX_VALUE - 1L, Math.round(Math.max(1, getBattlePower()) * multiplier)));
        applyAwakenedCombatBoost();
        setHealth(Math.min(getMaxHealth(), getHealth() + getMaxHealth() * (getRank() == FighterRank.VETERAN ? 0.26F : 0.18F)));

        if (getRace() == FighterRace.SAIYAN) {
            entityData.set(HAIR_COLOR, "#F2D35A");
            entityData.set(EYE1_COLOR, "#58D7D1");
            entityData.set(EYE2_COLOR, "#2F9F9D");
        }
        setLightning(true);
        if (getRandom().nextFloat() < 0.72F) flareAura(140 + getRandom().nextInt(121));
        level().playSound(null, blockPosition(), MainSounds.TRANSFORM_OFF.get(), SoundSource.HOSTILE, 1.25F, 1.0F);
        speak(getPersonality() == FighterPersonality.PROUD ? "Now we can begin." : "My power just changed.", 52);
    }

    private void applyAwakenedCombatBoost() {
        var attack = getAttribute(Attributes.ATTACK_DAMAGE);
        if (attack != null) attack.setBaseValue(getRank().attackDamage() * (getRank() == FighterRank.VETERAN ? 1.32D : 1.20D));
        setKiBlastDamage(FighterCombatDirector.baseKiDamage(this) * (getRank() == FighterRank.VETERAN ? 1.34F : 1.20F));
    }

    private void activateRacialForm() {
        RacialFormProfile form = RacialFormProfile.forSkill(getRace(), getRacialSkillLevel());
        if (form == null || isRacialFormActive()) return;
        racialBasePower = Math.max(1, getBattlePower());
        var attack = getAttribute(Attributes.ATTACK_DAMAGE);
        var speed = getAttribute(Attributes.MOVEMENT_SPEED);
        racialBaseAttack = attack == null ? getRank().attackDamage() : attack.getBaseValue();
        racialBaseSpeed = speed == null ? getRank().speed() : speed.getBaseValue();
        racialBaseAttackSpeed = getDefaultAttackSpeed();
        racialBaseKiDamage = getKiBlastDamage();
        racialBaseScale = getDisplayScale();
        racialBaseHairColor = getHairColor();
        racialBaseEye1Color = getEye1Color();
        racialBaseEye2Color = getEye2Color();
        racialBaseAuraType = getAuraType() == null ? "" : getAuraType();
        racialBaseAuraColor = getAuraColor();
        racialBaseLightning = isLightning();

        entityData.set(ACTIVE_RACIAL_FORM_LEVEL, form.skillLevel());
        setBattlePower((int)Math.min(Integer.MAX_VALUE - 1L, Math.round(racialBasePower * form.powerMultiplier())));
        if (attack != null) attack.setBaseValue(racialBaseAttack * Math.min(2.2D, form.powerMultiplier()));
        if (speed != null) speed.setBaseValue(racialBaseSpeed * form.speedMultiplier());
        setDefaultAttackSpeed(racialBaseAttackSpeed * form.attackSpeedMultiplier());
        setKiBlastDamage((float)(racialBaseKiDamage * Math.min(3.2D, form.powerMultiplier())));
        entityData.set(DISPLAY_SCALE, racialBaseScale * form.scaleMultiplier());
        setScaleVal(getDisplayScale());
        if (!form.hairColor().isBlank()) entityData.set(HAIR_COLOR, form.hairColor());
        if (!form.eyeColor().isBlank()) { entityData.set(EYE1_COLOR, form.eyeColor()); entityData.set(EYE2_COLOR, form.eyeColor()); }
        setAuraType("kakarot");
        if (form.auraColor() != 0xFFFFFF) setAuraColor(form.auraColor());
        setLightning(form.lightning());
        racialCalmTicks = 0;
        flareAura(80);
        level().playSound(null, blockPosition(), MainSounds.TRANSFORM_OFF.get(), SoundSource.HOSTILE, 1.2F, 1.0F);
        speak(form.displayName() + "!", 64);
    }

    private void tickRacialForm() {
        if (!isRacialFormActive()) return;
        if (isCaptive() || isDefeated()) { stopRacialForm(); return; }
        LivingEntity target = getTarget();
        if (target != null && target.isAlive()) racialCalmTicks = 0;
        else if (++racialCalmTicks > 360) stopRacialForm();
    }

    public void stopRacialForm() {
        if (!isRacialFormActive()) return;
        entityData.set(ACTIVE_RACIAL_FORM_LEVEL, 0);
        if (racialBasePower > 0) setBattlePower(racialBasePower);
        var attack = getAttribute(Attributes.ATTACK_DAMAGE);
        var speed = getAttribute(Attributes.MOVEMENT_SPEED);
        if (attack != null && racialBaseAttack > 0.0D) attack.setBaseValue(racialBaseAttack);
        if (speed != null && racialBaseSpeed > 0.0D) speed.setBaseValue(racialBaseSpeed);
        if (racialBaseAttackSpeed > 0.0D) setDefaultAttackSpeed(racialBaseAttackSpeed);
        if (racialBaseKiDamage > 0.0F) setKiBlastDamage(racialBaseKiDamage);
        if (racialBaseScale > 0.0F) { entityData.set(DISPLAY_SCALE, racialBaseScale); setScaleVal(racialBaseScale); }
        if (racialBaseHairColor != null && !racialBaseHairColor.isBlank()) entityData.set(HAIR_COLOR, racialBaseHairColor);
        if (racialBaseEye1Color != null && !racialBaseEye1Color.isBlank()) entityData.set(EYE1_COLOR, racialBaseEye1Color);
        if (racialBaseEye2Color != null && !racialBaseEye2Color.isBlank()) entityData.set(EYE2_COLOR, racialBaseEye2Color);
        setAuraType(racialBaseAuraType == null ? "" : racialBaseAuraType);
        setAuraColor(racialBaseAuraColor);
        setLightning(racialBaseLightning);
        racialCalmTicks = 0;
    }

    public void debugUnlockFlight() {
        entityData.set(FLIGHT_UNLOCKED, true);
        if (!isNonCombatant()) setCanFly(true);
    }

    public boolean debugSetRacialSkill(int requestedLevel) {
        int level = Math.max(0, Math.min(RacialFormProfile.maxSkillLevel(getRace()), requestedLevel));
        if (getRace() == FighterRace.SAIYAN && level == 7) level = 6;
        RacialFormProfile form = level <= 0 ? null : RacialFormProfile.forSkill(getRace(), level);
        if (form == null && level > 0) return false;
        if (isRacialFormActive()) stopRacialForm();
        entityData.set(RACIAL_SKILL_LEVEL, level);
        racialTrainingProgress = 0;
        return true;
    }

    public boolean debugTransformRacial() {
        if (getRacialSkillLevel() <= 0 || isRacialFormActive() || isKaiokenActive() || isMeditating()) return false;
        racialTransformPending = true;
        awakeningTicks = 1;
        setTransforming(true);
        tickAwakening();
        return isRacialFormActive();
    }

    public String getMentorName() { return mentorName; }
    public String getRivalName() { return rivalName; }
    public void setMentorName(String name) {
        String next = name == null ? "" : name;
        if (!next.isBlank() && !next.equals(mentorName)) recordLegacyEvent("Began training under " + next);
        mentorName = next;
    }
    public void setRivalName(String name) {
        String next = name == null ? "" : name;
        if (!next.isBlank() && !next.equals(rivalName)) recordLegacyEvent("Formed a rivalry with " + next);
        rivalName = next;
    }

    public boolean isMeditating() { return entityData.get(MEDITATING); }
    public int getTrainingSessions() { return trainingSessions; }
    public int getKaiokenLevel() { return entityData.get(KAIOKEN_LEVEL); }
    public boolean isKaiokenActive() { return getKaiokenLevel() > 0; }
    public int getStoryRole() { return entityData.get(STORY_ROLE); }
    public void setStoryRole(int role) { entityData.set(STORY_ROLE, Math.max(STORY_NONE, Math.min(STORY_PEACEKEEPER, role))); }
    public boolean hasFlightUnlocked() { return entityData.get(FLIGHT_UNLOCKED); }
    public int getRacialSkillLevel() { return entityData.get(RACIAL_SKILL_LEVEL); }
    public int getActiveRacialFormLevel() { return entityData.get(ACTIVE_RACIAL_FORM_LEVEL); }
    public boolean isRacialFormActive() { return getActiveRacialFormLevel() > 0; }
    public RacialFormProfile getActiveRacialForm() { return isRacialFormActive() ? RacialFormProfile.forSkill(getRace(), getActiveRacialFormLevel()) : null; }
    public String getRacialFormName() { RacialFormProfile form = getActiveRacialForm(); return form == null ? "" : form.displayName(); }
    public boolean isKaiokenAuraPulse() { return isKaiokenActive() && (kaiokenTicks > 0) && (kaiokenTicks % 100 > 92); }

    /** A real social/training state: no combat, no pathfinding, gradual progression. */
    public boolean beginMeditation(int ticks) { return beginMeditation(ticks, false); }

    public boolean beginMeditation(int ticks, boolean force) {
        if (level().isClientSide || isCaptive() || isDefeated() || isTransforming() || isKaiokenActive()
                || getTarget() != null || (!force && meditationCooldown > 0)) return false;
        meditationSessionLength = Math.max(240, ticks);
        meditationTicks = meditationSessionLength;
        meditationHarmonyTicks = 0;
        entityData.set(MEDITATING, true);
        suppressCombatIntent();
        setFlying(false);
        getNavigation().stop();
        com.dmzlivingworld.compat.MeditationCompat.spawnNpcMeditationStartVisual(this);
        return true;
    }

    public void stopMeditation(boolean completed) {
        if (!isMeditating()) return;
        entityData.set(MEDITATING, false);
        int elapsed = Math.max(0, meditationSessionLength - meditationTicks);
        meditationCooldown = 600 + getRandom().nextInt(1201);
        meditationTicks = 0;
        meditationSessionLength = 0;
        if (completed && elapsed >= 200) applyTrainingGrowth(elapsed + meditationHarmonyTicks / 2, true);
        meditationHarmonyTicks = 0;
        // Meditation temporarily suppresses combat locomotion; explicitly restore the
        // learned movement capability so being interrupted cannot leave a caster rooted.
        setCanFly(hasFlightUnlocked() && !isNonCombatant());
        setFlying(false);
        setFlyingFast(false);
        setDeltaMovement(getDeltaMovement().multiply(0.45D, 1.0D, 0.45D));
    }

    private void tickMeditation() {
        suppressCombatIntent();
        getNavigation().stop();
        setDeltaMovement(getDeltaMovement().multiply(0.15D, 1.0D, 0.15D));
        if (hurtTime > 0 || getTarget() != null) {
            stopMeditation(false);
            return;
        }
        if (meditationTicks > 0) meditationTicks--;
        if (tickCount % 20 == 0 && level() instanceof net.minecraft.server.level.ServerLevel server) {
            boolean playerHarmony = !server.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(14.0D),
                    com.dmzlivingworld.compat.MeditationCompat::isPlayerMeditating).isEmpty();
            if (playerHarmony) meditationHarmonyTicks += 20;
        }
        if (tickCount % 18 == Math.floorMod(getId(), 18)) {
            com.dmzlivingworld.compat.MeditationCompat.spawnNpcMeditationVisual(this, meditationHarmonyTicks > 0);
        }
        if (meditationTicks <= 0) {
            stopMeditation(true);
            if (getSpeech().isEmpty() && getRandom().nextFloat() < 0.45F) speak("That helped.", 42);
        }
    }

    /** Used by sparring/meditation scenes and recurring-character progression. */
    public void applyTrainingGrowth(int effortTicks, boolean meditation) {
        if (level().isClientSide || effortTicks < 100) return;
        trainingSessions++;
        if (trainingSessions == 5 || trainingSessions == 15 || trainingSessions == 30)
            recordLegacyEvent("Completed " + trainingSessions + " training sessions");
        double base = meditation ? 0.0045D : 0.0065D;
        double diminishing = 1.0D / (1.0D + trainingSessions * 0.035D);
        double gain = base * diminishing * Math.min(1.7D, Math.max(0.45D, effortTicks / 1200.0D));
        if (getRank() == FighterRank.ROOKIE) gain *= 1.18D;
        double anchor = level() instanceof net.minecraft.server.level.ServerLevel server
                ? WorldPowerScaler.resolveWorldAnchor(server, blockPosition()) : getBattlePower();
        long grown = Math.round(getBattlePower() * (1.0D + gain));
        long cap = Math.round(Math.max(getBattlePower(), anchor * (getRank() == FighterRank.VETERAN ? 2.8D : 1.9D)));
        setBattlePower((int)Math.min(Integer.MAX_VALUE - 1L, Math.max(1L, Math.min(grown, cap))));
        factionMerit += meditation ? 1 : 2;

        // DMZ flight is a learned all-race skill. Training can permanently unlock it.
        if (!hasFlightUnlocked() && !isNonCombatant()) {
            int flightThreshold = 3 + Math.floorMod(getUUID().hashCode(), 5);
            if (trainingSessions >= flightThreshold) {
                entityData.set(FLIGHT_UNLOCKED, true);
                setCanFly(true);
                recordLegacyEvent("Learned flight through training");
                if (getSpeech().isEmpty()) speak("I think I've got it... I can fly.", 64);
            }
        }

        // Racial forms follow DMZ 2.1.3's normal main tree. Growth is deliberately
        // slow; legendary/alternate trees are not handed out by procedural training.
        if (getRank() != FighterRank.ROOKIE && getRacialSkillLevel() < RacialFormProfile.maxSkillLevel(getRace())) {
            racialTrainingProgress += Math.max(1, effortTicks / (meditation ? 120 : 90));
            int next = RacialFormProfile.nextUnlockLevel(getRace(), getRacialSkillLevel());
            int threshold = 95 + next * 42 + Math.floorMod(getUUID().hashCode(), 45);
            if (next > getRacialSkillLevel() && racialTrainingProgress >= threshold) {
                racialTrainingProgress -= threshold;
                entityData.set(RACIAL_SKILL_LEVEL, next);
                RacialFormProfile unlocked = RacialFormProfile.forSkill(getRace(), next);
                if (unlocked != null) {
                    recordLegacyEvent("Unlocked " + unlocked.displayName() + " through training");
                    FighterGoalManager.onRacialAdvanced(this);
                    if (getSpeech().isEmpty()) speak("I finally understand " + unlocked.displayName() + ".", 72);
                }
            }
        }

        // A nearby real mentor can pass on one of their native DMZ techniques after
        // meaningful training. This is lineage, not a random skill roll.
        if (!mentorName.isBlank() && level() instanceof net.minecraft.server.level.ServerLevel server && getRandom().nextFloat() < 0.22F) {
            server.getEntitiesOfClass(AmbientFighterEntity.class, getBoundingBox().inflate(18.0D),
                            other -> other != this && other.isAlive() && mentorName.equals(other.getFighterName()))
                    .stream().findFirst().ifPresent(mentor -> FighterTechniqueManager.tryLearnFrom(this, mentor, "training"));
        }
        FighterGoalManager.onTraining(this);
    }

    private static boolean rollInitialFlight(RandomSource random, FighterRank rank) {
        return switch (rank) {
            case ROOKIE -> random.nextFloat() < 0.16F;
            case TRAINED -> random.nextFloat() < 0.70F;
            case VETERAN -> random.nextFloat() < 0.96F;
        };
    }

    private static int rollInitialRacialSkill(RandomSource random, FighterRank rank, FighterRace race) {
        if (rank == FighterRank.ROOKIE) return 0;
        int max = RacialFormProfile.maxSkillLevel(race);
        if (rank == FighterRank.TRAINED) return random.nextFloat() < 0.14F ? Math.min(1, max) : 0;
        float roll = random.nextFloat();
        if (roll < 0.34F) return 0;
        if (roll < 0.76F) return Math.min(1, max);
        return Math.min(RacialFormProfile.nextUnlockLevel(race, 1), max);
    }

    private boolean rollKaiokenPotential(RandomSource random) {
        if (getRank() == FighterRank.ROOKIE) return false;
        if (!(getArchetype() == FighterArchetype.MARTIAL_ARTIST || getArchetype() == FighterArchetype.BRAWLER
                || getArchetype() == FighterArchetype.SPEEDSTER || getArchetype() == FighterArchetype.GUARDIAN)) return false;
        float chance = getRank() == FighterRank.VETERAN ? 0.19F : 0.055F;
        if (getPersonality() == FighterPersonality.CALM) chance += 0.025F;
        if (getPersonality() == FighterPersonality.CAUTIOUS) chance -= 0.02F;
        return random.nextFloat() < chance;
    }

    private void tryStartKaioken() {
        if (!kaiokenPotential || isKaiokenActive() || isAwakened() || isRacialFormActive() || isTransforming() || isMeditating()
                || getTarget() == null || !getTarget().isAlive() || tickCount < 120) return;
        float hp = getHealth() / Math.max(1.0F, getMaxHealth());
        if (hp > 0.62F && tickCount % 200 != 0) return;
        double targetPower = estimateBattlePower(getTarget());
        boolean pressured = hp < 0.48F || targetPower > Math.max(1, getBattlePower()) * 1.18D;
        if (!pressured) return;
        long stable = FactionWorldData.mix(getUUID().getMostSignificantBits() ^ getTarget().getUUID().getLeastSignificantBits());
        if (Math.floorMod(stable, 100L) >= (getRank() == FighterRank.VETERAN ? 58L : 28L)) return;
        int level = 2;
        int roll = getRandom().nextInt(100);
        if (getRank() == FighterRank.VETERAN && roll < 7) level = 10;
        else if (roll < 28) level = 4;
        else if (roll < 57) level = 3;
        startKaioken(level);
    }

    public boolean startKaioken(int level) {
        if (isKaiokenActive() || isRacialFormActive() || isMeditating() || isTransforming()) return false;
        if (level != 2 && level != 3 && level != 4 && level != 10) level = 2;
        double multiplier = kaiokenMultiplier(level);
        kaiokenBasePower = Math.max(1, getBattlePower());
        var attack = getAttribute(Attributes.ATTACK_DAMAGE);
        var speed = getAttribute(Attributes.MOVEMENT_SPEED);
        kaiokenBaseAttack = attack == null ? getRank().attackDamage() : attack.getBaseValue();
        kaiokenBaseSpeed = speed == null ? getRank().speed() : speed.getBaseValue();
        kaiokenBaseKiDamage = getKiBlastDamage();
        kaiokenBaseAuraType = getAuraType() == null ? "" : getAuraType();
        kaiokenBaseAuraColor = getAuraColor();
        entityData.set(KAIOKEN_LEVEL, level);
        kaiokenTicks = 260 + getRandom().nextInt(getRank() == FighterRank.VETERAN ? 441 : 241);
        setBattlePower((int)Math.min(Integer.MAX_VALUE - 1L, Math.round(kaiokenBasePower * multiplier)));
        if (attack != null) attack.setBaseValue(kaiokenBaseAttack * multiplier);
        if (speed != null) speed.setBaseValue(kaiokenBaseSpeed * multiplier);
        setKiBlastDamage((float)(kaiokenBaseKiDamage * multiplier));
        setAuraType("kakarot");
        setAuraColor(0xDB182C);
        setLightning(false);
        setTransforming(true);
        // A short ignition burst, then only restrained periodic aura pulses. Rendering
        // Kaioken as a permanent saga-effect pass produced far too many sparks.
        flareAura(22);
        level().playSound(null, blockPosition(), MainSounds.TRANSFORM_ON.get(), SoundSource.HOSTILE, 1.2F, 1.05F);
        speak(level >= 10 ? "KAIOKEN TIMES TEN!" : "Kaioken x" + level + "!", 60);
        return true;
    }

    private void tickKaioken() {
        if (kaiokenTicks > 0) kaiokenTicks--;
        if (isTransforming() && kaiokenTicks < 235) setTransforming(false);
        if (tickCount % 20 == 0) {
            double drain = switch (getKaiokenLevel()) {
                case 3 -> 0.06D; case 4 -> 0.095D; case 10 -> 0.16D; default -> 0.03D;
            };
            // DMZ config healthDrain is preserved as the relative severity; the NPC
            // drain is paced to make the form risky without deleting an NPC in seconds.
            float amount = (float)(getMaxHealth() * drain * 0.075D);
            setHealth(Math.max(1.0F, getHealth() - amount));
            if (getHealth() <= getMaxHealth() * 0.10F) kaiokenTicks = 0;
        }
        if (kaiokenTicks <= 0 || isDefeated() || isCaptive()) stopKaioken();
    }

    private void stopKaioken() {
        if (!isKaiokenActive()) return;
        entityData.set(KAIOKEN_LEVEL, 0);
        setTransforming(false);
        if (kaiokenBasePower > 0) setBattlePower(kaiokenBasePower);
        var attack = getAttribute(Attributes.ATTACK_DAMAGE);
        var speed = getAttribute(Attributes.MOVEMENT_SPEED);
        if (attack != null && kaiokenBaseAttack > 0) attack.setBaseValue(kaiokenBaseAttack);
        if (speed != null && kaiokenBaseSpeed > 0) speed.setBaseValue(kaiokenBaseSpeed);
        if (kaiokenBaseKiDamage > 0) setKiBlastDamage(kaiokenBaseKiDamage);
        setAuraType(kaiokenBaseAuraType == null ? "" : kaiokenBaseAuraType);
        setAuraColor(kaiokenBaseAuraColor);
        kaiokenTicks = 0;
        level().playSound(null, blockPosition(), MainSounds.TRANSFORM_OFF.get(), SoundSource.HOSTILE, 0.8F, 0.95F);
    }

    private static double kaiokenMultiplier(int level) {
        return switch (level) { case 3 -> 1.20D; case 4 -> 1.35D; case 10 -> 1.50D; default -> 1.10D; };
    }

    public void speak(String text, int ticks) {
        if (level().isClientSide || text == null || text.isBlank()) return;
        entityData.set(SPEECH, text);
        speechTicks = Math.max(20, ticks);
    }

    public void setCaptive(boolean captive) {
        entityData.set(CAPTIVE, captive);
        setInvulnerable(captive);
        setNoAi(captive);
        if (captive) {
            suppressCombatIntent();
            speak(FighterDialogue.captive(getRandom()), 70);
        } else {
            recoveryGraceTicks = Math.max(recoveryGraceTicks, 80);
        }
    }

    /** Character object expected by DragonMineZ's own HairRenderer. */
    public Character getDMZCharacter() {
        Character character = new Character();
        character.setRace(getRace().dmzId());
        character.setGender(isFemale() ? Character.GENDER_FEMALE : Character.GENDER_MALE);
        character.setCharacterClass(Character.CLASS_WARRIOR);
        character.setBodyType(getBodyType());
        character.setEyesType(getEyesType());
        character.setNoseType(getNoseType());
        character.setMouthType(getMouthType());
        character.setHairId(getHairId());
        character.setRenderHairBase(getRace().usesHair());
        character.setBodyColor(getBodyColor());
        character.setBodyColor2(getBodyColor2());
        character.setBodyColor3(getBodyColor3());
        character.setHairColor(getHairColor());
        character.setEye1Color(getEye1Color());
        character.setEye2Color(getEye2Color());
        character.setAuraColor("#FFFFFF");
        // Do not synthesize a Saiyan tail here. DMZ's real player tail is rendered by
        // its separate race-parts pipeline (tailenrolled + character state), not this model.
        character.setHasSaiyanTail(false);
        if (getRace().usesHair()) {
            CustomHair hair = HairManager.getPresetHair(getHairId(), getRace().dmzId());
            if (hair == null || hair.isEmpty()) hair = HairManager.getPresetHair(getHairId(), "human");
            character.setHairBase(hair);
        }
        return character;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("LWDataVersion", DATA_VERSION);
        tag.put("LWLegacy", legacyData.copy());
        tag.putBoolean("LWArsenalInitialized", arsenalInitialized);
        tag.putBoolean("LWReady", entityData.get(READY));
        tag.putInt("LWAlignment", getAlignment().id());
        tag.putInt("LWRank", getRank().id());
        tag.putInt("LWPersonality", getPersonality().id());
        tag.putInt("LWRace", getRace().id());
        tag.putInt("LWArchetype", getArchetype().id());
        tag.putBoolean("LWCaptive", isCaptive());
        tag.putBoolean("LWDefeated", isDefeated());
        tag.putInt("LWDefeatedTicks", defeatedTicks);
        tag.putInt("LWRecoveryGrace", recoveryGraceTicks);
        tag.putInt("LWCinematicLaunchCooldown", cinematicLaunchCooldown);
        tag.putInt("LWRetreatTicks", retreatTicks);
        if (retreatThreatId != null) tag.putUUID("LWRetreatThreat", retreatThreatId);
        if (duelOpponentId != null) tag.putUUID("LWDuelOpponent", duelOpponentId);
        tag.putString("LWFighterName", getFighterName());
        tag.putInt("LWBattlePower", getBattlePower());
        tag.putBoolean("LWAwakened", isAwakened());
        tag.putInt("LWAwakeningTicks", awakeningTicks);
        tag.putFloat("LWDisplayScale", getDisplayScale());
        if (memoryOwnerId != null) tag.putUUID("LWMemoryOwner", memoryOwnerId);
        if (memoryRecordId != null) tag.putUUID("LWMemoryRecord", memoryRecordId);
        tag.putInt("LWMemoryEncounters", memoryEncounters);
        tag.putInt("LWMemoryRelationship", memoryRelationship);
        tag.putBoolean("LWMemoryRescued", memoryRescued);
        tag.putString("LWFactionId", getFactionId());
        tag.putBoolean("LWFactionLeader", isFactionLeader());
        tag.putInt("LWFactionRole", getFactionRole().id());
        tag.putString("LWFactionName", getFactionDisplayName());
        tag.putString("LWFactionTitle", getFactionTitle());
        tag.putBoolean("LWAuraFlared", isAuraFlared());
        tag.putInt("LWAuraFlareTicks", auraFlareTicks);
        tag.putBoolean("LWAngerAuraUsed", angerAuraUsed);
        tag.putInt("LWFoodSupplies", foodSupplies);
        tag.putInt("LWSenzuBeans", senzuBeans);
        tag.putInt("LWSupplyCooldown", supplyCooldown);
        tag.putBoolean("LWRegionalPresence", regionalPresence);
        tag.putBoolean("LWNonCombatant", isNonCombatant());
        tag.putString("LWWantedId", getWantedId());
        tag.putInt("LWWantedLevel", getWantedLevel());
        tag.putString("LWWantedCrime", getWantedCrime());
        tag.putInt("LWFactionMerit", factionMerit);
        tag.putBoolean("LWMeditating", isMeditating());
        tag.putInt("LWMeditationTicks", meditationTicks);
        tag.putInt("LWMeditationLength", meditationSessionLength);
        tag.putInt("LWMeditationHarmony", meditationHarmonyTicks);
        tag.putInt("LWMeditationCooldown", meditationCooldown);
        tag.putInt("LWTrainingSessions", trainingSessions);
        tag.putBoolean("LWFlightUnlocked", hasFlightUnlocked());
        tag.putInt("LWRacialSkillLevel", getRacialSkillLevel());
        tag.putInt("LWRacialTrainingProgress", racialTrainingProgress);
        tag.putInt("LWActiveRacialForm", getActiveRacialFormLevel());
        tag.putInt("LWRacialBasePower", racialBasePower);
        tag.putDouble("LWRacialBaseAttack", racialBaseAttack);
        tag.putDouble("LWRacialBaseSpeed", racialBaseSpeed);
        tag.putDouble("LWRacialBaseAttackSpeed", racialBaseAttackSpeed);
        tag.putFloat("LWRacialBaseKiDamage", racialBaseKiDamage);
        tag.putFloat("LWRacialBaseScale", racialBaseScale);
        tag.putString("LWRacialBaseHair", racialBaseHairColor == null ? "" : racialBaseHairColor);
        tag.putString("LWRacialBaseEye1", racialBaseEye1Color == null ? "" : racialBaseEye1Color);
        tag.putString("LWRacialBaseEye2", racialBaseEye2Color == null ? "" : racialBaseEye2Color);
        tag.putString("LWRacialBaseAuraType", racialBaseAuraType == null ? "" : racialBaseAuraType);
        tag.putInt("LWRacialBaseAuraColor", racialBaseAuraColor);
        tag.putBoolean("LWRacialBaseLightning", racialBaseLightning);
        tag.putInt("LWStoryRole", getStoryRole());
        tag.putString("LWMentorName", mentorName);
        tag.putString("LWRivalName", rivalName);
        tag.putBoolean("LWKaiokenPotential", kaiokenPotential);
        tag.putInt("LWKaiokenLevel", getKaiokenLevel());
        tag.putInt("LWKaiokenTicks", kaiokenTicks);
        tag.putInt("LWKaiokenBasePower", kaiokenBasePower);
        tag.putDouble("LWKaiokenBaseAttack", kaiokenBaseAttack);
        tag.putDouble("LWKaiokenBaseSpeed", kaiokenBaseSpeed);
        tag.putFloat("LWKaiokenBaseKiDamage", kaiokenBaseKiDamage);
        tag.putString("LWKaiokenBaseAuraType", kaiokenBaseAuraType == null ? "" : kaiokenBaseAuraType);
        tag.putInt("LWKaiokenBaseAuraColor", kaiokenBaseAuraColor);
        if (partyId != null) tag.putUUID("LWPartyId", partyId);
        tag.putBoolean("LWPartyCaptain", partyCaptain);
        tag.putInt("LWGender", entityData.get(GENDER));
        tag.putInt("LWBodyType", getBodyType());
        tag.putInt("LWEyesType", getEyesType());
        tag.putInt("LWNoseType", getNoseType());
        tag.putInt("LWMouthType", getMouthType());
        tag.putInt("LWHairId", getHairId());
        tag.putInt("LWOutfit", getOutfit());
        tag.putString("LWBodyColor", getBodyColor());
        tag.putString("LWBodyColor2", getBodyColor2());
        tag.putString("LWBodyColor3", getBodyColor3());
        tag.putString("LWHairColor", getHairColor());
        tag.putString("LWEye1Color", getEye1Color());
        tag.putString("LWEye2Color", getEye2Color());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        legacyData = sanitizeLegacyData(tag.contains("LWLegacy", Tag.TAG_COMPOUND) ? tag.getCompound("LWLegacy").copy() : new CompoundTag());
        arsenalInitialized = tag.contains("LWArsenalInitialized") && tag.getBoolean("LWArsenalInitialized");
        if (tag.contains("LWReady")) entityData.set(READY, tag.getBoolean("LWReady"));
        if (tag.contains("LWAlignment")) entityData.set(ALIGNMENT, tag.getInt("LWAlignment"));
        if (tag.contains("LWRank")) entityData.set(RANK, tag.getInt("LWRank"));
        if (tag.contains("LWPersonality")) entityData.set(PERSONALITY, tag.getInt("LWPersonality"));
        else entityData.set(PERSONALITY, FighterPersonality.roll(getRandom(), getAlignment()).id());
        if (tag.contains("LWRace")) entityData.set(RACE, tag.getInt("LWRace"));
        else entityData.set(RACE, FighterRace.HUMAN.id());
        if (tag.contains("LWArchetype")) entityData.set(ARCHETYPE, tag.getInt("LWArchetype"));
        else entityData.set(ARCHETYPE, FighterArchetype.roll(getRandom(), getRank()).id());
        if (tag.contains("LWCaptive")) entityData.set(CAPTIVE, tag.getBoolean("LWCaptive"));
        if (tag.contains("LWDefeated")) entityData.set(DEFEATED, tag.getBoolean("LWDefeated"));
        defeatedTicks = tag.contains("LWDefeatedTicks") ? tag.getInt("LWDefeatedTicks") : 0;
        recoveryGraceTicks = tag.contains("LWRecoveryGrace") ? tag.getInt("LWRecoveryGrace") : 0;
        cinematicLaunchCooldown = tag.contains("LWCinematicLaunchCooldown") ? tag.getInt("LWCinematicLaunchCooldown") : 0;
        retreatTicks = tag.contains("LWRetreatTicks") ? tag.getInt("LWRetreatTicks") : 0;
        retreatThreatId = tag.hasUUID("LWRetreatThreat") ? tag.getUUID("LWRetreatThreat") : null;
        duelOpponentId = tag.hasUUID("LWDuelOpponent") ? tag.getUUID("LWDuelOpponent") : null;
        if (tag.contains("LWFighterName")) entityData.set(FIGHTER_NAME, tag.getString("LWFighterName"));
        if (tag.contains("LWBattlePower")) setBattlePower(tag.getInt("LWBattlePower"));
        if (tag.contains("LWAwakened")) entityData.set(AWAKENED, tag.getBoolean("LWAwakened"));
        awakeningTicks = tag.contains("LWAwakeningTicks") ? tag.getInt("LWAwakeningTicks") : 0;
        if (awakeningTicks > 0) setTransforming(true);
        float restoredScale = tag.contains("LWDisplayScale") ? tag.getFloat("LWDisplayScale") : 1.0F;
        entityData.set(DISPLAY_SCALE, restoredScale);
        setScaleVal(restoredScale);
        memoryOwnerId = tag.hasUUID("LWMemoryOwner") ? tag.getUUID("LWMemoryOwner") : null;
        memoryRecordId = tag.hasUUID("LWMemoryRecord") ? tag.getUUID("LWMemoryRecord") : null;
        memoryEncounters = tag.contains("LWMemoryEncounters") ? tag.getInt("LWMemoryEncounters") : 0;
        memoryRelationship = tag.contains("LWMemoryRelationship") ? tag.getInt("LWMemoryRelationship") : 0;
        memoryRescued = tag.contains("LWMemoryRescued") && tag.getBoolean("LWMemoryRescued");
        entityData.set(FACTION_ID, tag.contains("LWFactionId") ? tag.getString("LWFactionId") : "");
        entityData.set(FACTION_LEADER, tag.contains("LWFactionLeader") && tag.getBoolean("LWFactionLeader"));
        entityData.set(FACTION_ROLE, tag.contains("LWFactionRole") ? tag.getInt("LWFactionRole")
                : (entityData.get(FACTION_LEADER) ? FactionRole.LEADER.id() : FactionRole.MEMBER.id()));
        entityData.set(FACTION_NAME, tag.contains("LWFactionName") ? tag.getString("LWFactionName") : "");
        entityData.set(FACTION_TITLE, tag.contains("LWFactionTitle") ? tag.getString("LWFactionTitle") : "");
        entityData.set(AURA_FLARED, tag.contains("LWAuraFlared") && tag.getBoolean("LWAuraFlared"));
        auraFlareTicks = tag.contains("LWAuraFlareTicks") ? tag.getInt("LWAuraFlareTicks") : 0;
        angerAuraUsed = tag.contains("LWAngerAuraUsed") && tag.getBoolean("LWAngerAuraUsed");
        foodSupplies = tag.contains("LWFoodSupplies") ? tag.getInt("LWFoodSupplies") : 0;
        senzuBeans = tag.contains("LWSenzuBeans") ? tag.getInt("LWSenzuBeans") : 0;
        supplyCooldown = tag.contains("LWSupplyCooldown") ? tag.getInt("LWSupplyCooldown") : 0;
        regionalPresence = tag.contains("LWRegionalPresence") && tag.getBoolean("LWRegionalPresence");
        entityData.set(NON_COMBATANT, tag.contains("LWNonCombatant") && tag.getBoolean("LWNonCombatant"));
        entityData.set(WANTED_ID, tag.contains("LWWantedId") ? tag.getString("LWWantedId") : "");
        entityData.set(WANTED_LEVEL, tag.contains("LWWantedLevel") ? tag.getInt("LWWantedLevel") : 0);
        entityData.set(WANTED_CRIME, tag.contains("LWWantedCrime") ? tag.getString("LWWantedCrime") : "");
        factionMerit = tag.contains("LWFactionMerit") ? tag.getInt("LWFactionMerit") : 0;
        entityData.set(MEDITATING, tag.contains("LWMeditating") && tag.getBoolean("LWMeditating"));
        meditationTicks = tag.contains("LWMeditationTicks") ? tag.getInt("LWMeditationTicks") : 0;
        meditationSessionLength = tag.contains("LWMeditationLength") ? tag.getInt("LWMeditationLength") : 0;
        meditationHarmonyTicks = tag.contains("LWMeditationHarmony") ? tag.getInt("LWMeditationHarmony") : 0;
        meditationCooldown = tag.contains("LWMeditationCooldown") ? tag.getInt("LWMeditationCooldown") : 200;
        trainingSessions = tag.contains("LWTrainingSessions") ? tag.getInt("LWTrainingSessions") : 0;
        entityData.set(FLIGHT_UNLOCKED, tag.contains("LWFlightUnlocked") ? tag.getBoolean("LWFlightUnlocked") : getRank().canFly());
        entityData.set(RACIAL_SKILL_LEVEL, tag.contains("LWRacialSkillLevel") ? tag.getInt("LWRacialSkillLevel") : 0);
        racialTrainingProgress = tag.contains("LWRacialTrainingProgress") ? tag.getInt("LWRacialTrainingProgress") : 0;
        entityData.set(ACTIVE_RACIAL_FORM_LEVEL, tag.contains("LWActiveRacialForm") ? tag.getInt("LWActiveRacialForm") : 0);
        racialBasePower = tag.contains("LWRacialBasePower") ? tag.getInt("LWRacialBasePower") : 0;
        racialBaseAttack = tag.contains("LWRacialBaseAttack") ? tag.getDouble("LWRacialBaseAttack") : 0.0D;
        racialBaseSpeed = tag.contains("LWRacialBaseSpeed") ? tag.getDouble("LWRacialBaseSpeed") : 0.0D;
        racialBaseAttackSpeed = tag.contains("LWRacialBaseAttackSpeed") ? tag.getDouble("LWRacialBaseAttackSpeed") : getDefaultAttackSpeed();
        racialBaseKiDamage = tag.contains("LWRacialBaseKiDamage") ? tag.getFloat("LWRacialBaseKiDamage") : 0.0F;
        racialBaseScale = tag.contains("LWRacialBaseScale") ? tag.getFloat("LWRacialBaseScale") : getDisplayScale();
        racialBaseHairColor = tag.contains("LWRacialBaseHair") ? tag.getString("LWRacialBaseHair") : getHairColor();
        racialBaseEye1Color = tag.contains("LWRacialBaseEye1") ? tag.getString("LWRacialBaseEye1") : getEye1Color();
        racialBaseEye2Color = tag.contains("LWRacialBaseEye2") ? tag.getString("LWRacialBaseEye2") : getEye2Color();
        racialBaseAuraType = tag.contains("LWRacialBaseAuraType") ? tag.getString("LWRacialBaseAuraType") : getAuraType();
        racialBaseAuraColor = tag.contains("LWRacialBaseAuraColor") ? tag.getInt("LWRacialBaseAuraColor") : getAuraColor();
        racialBaseLightning = tag.contains("LWRacialBaseLightning") && tag.getBoolean("LWRacialBaseLightning");
        entityData.set(STORY_ROLE, tag.contains("LWStoryRole") ? tag.getInt("LWStoryRole") : STORY_NONE);
        mentorName = tag.getString("LWMentorName");
        rivalName = tag.getString("LWRivalName");
        kaiokenPotential = tag.contains("LWKaiokenPotential") ? tag.getBoolean("LWKaiokenPotential") : rollKaiokenPotential(getRandom());
        entityData.set(KAIOKEN_LEVEL, tag.contains("LWKaiokenLevel") ? tag.getInt("LWKaiokenLevel") : 0);
        kaiokenTicks = tag.contains("LWKaiokenTicks") ? tag.getInt("LWKaiokenTicks") : 0;
        kaiokenBasePower = tag.contains("LWKaiokenBasePower") ? tag.getInt("LWKaiokenBasePower") : 0;
        kaiokenBaseAttack = tag.contains("LWKaiokenBaseAttack") ? tag.getDouble("LWKaiokenBaseAttack") : 0.0D;
        kaiokenBaseSpeed = tag.contains("LWKaiokenBaseSpeed") ? tag.getDouble("LWKaiokenBaseSpeed") : 0.0D;
        kaiokenBaseKiDamage = tag.contains("LWKaiokenBaseKiDamage") ? tag.getFloat("LWKaiokenBaseKiDamage") : 0.0F;
        kaiokenBaseAuraType = tag.contains("LWKaiokenBaseAuraType") ? tag.getString("LWKaiokenBaseAuraType") : "";
        kaiokenBaseAuraColor = tag.contains("LWKaiokenBaseAuraColor") ? tag.getInt("LWKaiokenBaseAuraColor") : 0xFFFFFF;
        // Never preserve a temporary Kaioken multiplier across save/reload. Restore the
        // pre-Kaioken combat profile instead of silently turning a temporary form permanent.
        if (getKaiokenLevel() > 0) {
            entityData.set(KAIOKEN_LEVEL, 0);
            kaiokenTicks = 0;
            setTransforming(false);
            if (kaiokenBasePower > 0) setBattlePower(kaiokenBasePower);
            var attack = getAttribute(Attributes.ATTACK_DAMAGE);
            var speed = getAttribute(Attributes.MOVEMENT_SPEED);
            if (attack != null && kaiokenBaseAttack > 0.0D) attack.setBaseValue(kaiokenBaseAttack);
            if (speed != null && kaiokenBaseSpeed > 0.0D) speed.setBaseValue(kaiokenBaseSpeed);
            if (kaiokenBaseKiDamage > 0.0F) setKiBlastDamage(kaiokenBaseKiDamage);
            setAuraType(kaiokenBaseAuraType == null ? "" : kaiokenBaseAuraType);
            setAuraColor(kaiokenBaseAuraColor);
        }
        // Active race forms are combat state, not a permanent stat multiplier. Restore
        // the exact pre-form profile on load while keeping the learned skill level.
        boolean restoreRacialAppearance = getActiveRacialFormLevel() > 0;
        if (restoreRacialAppearance) {
            entityData.set(ACTIVE_RACIAL_FORM_LEVEL, 0);
            setTransforming(false);
            if (racialBasePower > 0) setBattlePower(racialBasePower);
            var attack = getAttribute(Attributes.ATTACK_DAMAGE);
            var speed = getAttribute(Attributes.MOVEMENT_SPEED);
            if (attack != null && racialBaseAttack > 0.0D) attack.setBaseValue(racialBaseAttack);
            if (speed != null && racialBaseSpeed > 0.0D) speed.setBaseValue(racialBaseSpeed);
            if (racialBaseAttackSpeed > 0.0D) setDefaultAttackSpeed(racialBaseAttackSpeed);
            if (racialBaseKiDamage > 0.0F) setKiBlastDamage(racialBaseKiDamage);
            if (racialBaseScale > 0.0F) { entityData.set(DISPLAY_SCALE, racialBaseScale); setScaleVal(racialBaseScale); }
            if (!racialBaseHairColor.isBlank()) entityData.set(HAIR_COLOR, racialBaseHairColor);
            if (!racialBaseEye1Color.isBlank()) entityData.set(EYE1_COLOR, racialBaseEye1Color);
            if (!racialBaseEye2Color.isBlank()) entityData.set(EYE2_COLOR, racialBaseEye2Color);
            setAuraType(racialBaseAuraType == null ? "" : racialBaseAuraType);
            setAuraColor(racialBaseAuraColor);
            setLightning(racialBaseLightning);
        }
        partyId = tag.hasUUID("LWPartyId") ? tag.getUUID("LWPartyId") : null;
        partyCaptain = tag.contains("LWPartyCaptain") && tag.getBoolean("LWPartyCaptain");
        if (tag.contains("LWGender")) entityData.set(GENDER, tag.getInt("LWGender"));
        if (tag.contains("LWBodyType")) entityData.set(BODY_TYPE, tag.getInt("LWBodyType"));
        if (tag.contains("LWEyesType")) entityData.set(EYES_TYPE, tag.getInt("LWEyesType"));
        if (tag.contains("LWNoseType")) entityData.set(NOSE_TYPE, tag.getInt("LWNoseType"));
        if (tag.contains("LWMouthType")) entityData.set(MOUTH_TYPE, tag.getInt("LWMouthType"));
        if (tag.contains("LWHairId")) entityData.set(HAIR_ID, tag.getInt("LWHairId"));
        if (tag.contains("LWOutfit")) entityData.set(OUTFIT, tag.getInt("LWOutfit"));
        if (tag.contains("LWBodyColor")) entityData.set(BODY_COLOR, tag.getString("LWBodyColor"));
        if (tag.contains("LWBodyColor2")) entityData.set(BODY_COLOR2, tag.getString("LWBodyColor2"));
        else entityData.set(BODY_COLOR2, getBodyColor());
        if (tag.contains("LWBodyColor3")) entityData.set(BODY_COLOR3, tag.getString("LWBodyColor3"));
        else entityData.set(BODY_COLOR3, getBodyColor());
        if (tag.contains("LWHairColor")) entityData.set(HAIR_COLOR, tag.getString("LWHairColor"));
        if (tag.contains("LWEye1Color")) entityData.set(EYE1_COLOR, tag.getString("LWEye1Color"));
        if (tag.contains("LWEye2Color")) entityData.set(EYE2_COLOR, tag.getString("LWEye2Color"));
        // The generic appearance NBT above contains the *currently rendered* form hair/eyes.
        // If a save happened mid-transformation, restore the pre-form appearance one final time
        // after reading those fields so temporary form cosmetics cannot leak across reloads.
        if (restoreRacialAppearance) {
            if (!racialBaseHairColor.isBlank()) entityData.set(HAIR_COLOR, racialBaseHairColor);
            if (!racialBaseEye1Color.isBlank()) entityData.set(EYE1_COLOR, racialBaseEye1Color);
            if (!racialBaseEye2Color.isBlank()) entityData.set(EYE2_COLOR, racialBaseEye2Color);
        }
        entityData.set(SPEECH, "");
        speechTicks = 0;
        combatConfigured = false;
        syncLegacyTitle();
    }

    private static CompoundTag sanitizeLegacyData(CompoundTag input) {
        CompoundTag out = input == null ? new CompoundTag() : input.copy();
        String[] nonNegative = {"Fights", "Wins", "Losses", "Kills", "Deaths", "PlayerWins", "PlayerLosses",
                "StrongestWinPower", "Fusions", "NemesisBattles", "NemesisWins", "GoalsCompleted"};
        for (String key : nonNegative) {
            if (out.contains(key, Tag.TAG_ANY_NUMERIC)) out.putInt(key, Math.max(0, out.getInt(key)));
        }
        out.putInt("NemesisStage", Math.max(0, Math.min(5, out.getInt("NemesisStage"))));
        if (out.contains("Events", Tag.TAG_LIST)) {
            ListTag source = out.getList("Events", Tag.TAG_STRING);
            ListTag clean = new ListTag();
            int start = Math.max(0, source.size() - 20);
            for (int i = start; i < source.size(); i++) {
                String event = source.getString(i);
                if (event == null || event.isBlank()) continue;
                clean.add(StringTag.valueOf(event.length() > 160 ? event.substring(0, 160) : event));
            }
            out.put("Events", clean);
        } else {
            out.remove("Events");
        }
        trimString(out, "LastOpponent", 64);
        trimString(out, "LastResult", 64);
        trimString(out, "StrongestWinName", 64);
        trimString(out, "LastFusionPartner", 64);
        trimString(out, "NemesisName", 64);
        trimString(out, "GoalType", 32);
        trimString(out, "GoalTarget", 64);
        trimString(out, "LastGoalType", 32);
        trimString(out, "LastGoalResult", 120);
        return out;
    }

    private static void trimString(CompoundTag tag, String key, int max) {
        if (!tag.contains(key, Tag.TAG_STRING)) return;
        String value = tag.getString(key);
        if (value.length() > max) tag.putString(key, value.substring(0, max));
    }

    public CompoundTag getLegacyData() { return legacyData; }

    public boolean isArsenalInitialized() { return arsenalInitialized; }
    public void setArsenalInitialized(boolean value) { arsenalInitialized = value; }
    public int getArsenalWeaponCooldown() { return arsenalWeaponCooldown; }
    public void setArsenalWeaponCooldown(int ticks) { arsenalWeaponCooldown = Math.max(0, ticks); }

    public void recordLegacyBattle(String opponentName, int opponentPower, boolean won, boolean lethal, boolean playerOpponent) {
        if (level().isClientSide) return;
        String resolvedName = opponentName == null || opponentName.isBlank() ? "Unknown" : opponentName;
        int previousStrongest = Math.max(0, legacyData.getInt("StrongestWinPower"));
        incrementLegacy("Fights");
        incrementLegacy(won ? "Wins" : "Losses");
        if (lethal) incrementLegacy(won ? "Kills" : "Deaths");
        if (playerOpponent) incrementLegacy(won ? "PlayerWins" : "PlayerLosses");
        legacyData.putString("LastOpponent", resolvedName);
        legacyData.putString("LastResult", won ? (lethal ? "Victory (lethal)" : "Victory") : (lethal ? "Defeat (lethal)" : "Defeat"));
        legacyData.putLong("LastBattle", level().getGameTime());
        boolean newStrongest = won && opponentPower > previousStrongest;
        if (newStrongest) {
            legacyData.putInt("StrongestWinPower", Math.max(0, opponentPower));
            legacyData.putString("StrongestWinName", resolvedName);
        }

        // Counters remember every fight; the visible timeline only remembers fights
        // that changed this person's story. This keeps the profile from becoming a
        // kill-feed disguised as character history.
        boolean relationshipFight = resolvedName.equals(getRivalName()) || resolvedName.equals(getMentorName());
        boolean upset = won && opponentPower > Math.max(1L, Math.round(getBattlePower() * 1.25D));
        if (lethal || newStrongest || relationshipFight || upset || (playerOpponent && getNemesisStage() > 0)) {
            String reason = lethal ? " in a lethal fight" : upset ? " against a stronger opponent" : "";
            recordLegacyEvent((won ? "Defeated " : "Lost to ") + resolvedName + reason);
        }
        syncLegacyTitle();
    }

    public void recordFusion(String partnerName) {
        incrementLegacy("Fusions");
        legacyData.putString("LastFusionPartner", partnerName == null ? "Unknown" : partnerName);
        recordLegacyEvent("Fused with " + (partnerName == null ? "Unknown" : partnerName));
        FighterGoalManager.onFusion(this);
        syncLegacyTitle();
    }

    private void incrementLegacy(String key) {
        int value = Math.max(0, legacyData.getInt(key));
        if (value < Integer.MAX_VALUE) legacyData.putInt(key, value + 1);
    }

    public void recordLegacyEvent(String event) {
        if (event == null || event.isBlank()) return;
        ListTag events = legacyData.getList("Events", Tag.TAG_STRING);
        if (!events.isEmpty() && events.getString(events.size() - 1).equals(event)) return;
        events.add(StringTag.valueOf(event));
        while (events.size() > 20) events.remove(0);
        legacyData.put("Events", events);
    }

    public void setNemesisState(UUID playerId, String playerName, int stage, int battles, int winsVsPlayer) {
        if (playerId != null) legacyData.putUUID("NemesisPlayer", playerId);
        legacyData.putString("NemesisName", playerName == null ? "" : playerName);
        legacyData.putInt("NemesisStage", Math.max(0, Math.min(5, stage)));
        legacyData.putInt("NemesisBattles", Math.max(0, battles));
        legacyData.putInt("NemesisWins", Math.max(0, winsVsPlayer));
        syncLegacyTitle();
    }

    public int getNemesisStage() { return legacyData.getInt("NemesisStage"); }

    public String getLegacyTitle() {
        if (level().isClientSide) return entityData.get(LEGACY_TITLE);
        String title = computeLegacyTitle();
        if (!title.equals(entityData.get(LEGACY_TITLE))) entityData.set(LEGACY_TITLE, title);
        return title;
    }

    private String computeLegacyTitle() {
        int nemesis = legacyData.getInt("NemesisStage");
        if (nemesis >= 4) return "Archrival";
        if (legacyData.getInt("Fusions") >= 3) return "Fusion Veteran";
        if (legacyData.getInt("Wins") >= 12) return "Battle-Hardened";
        int strongest = legacyData.getInt("StrongestWinPower");
        if (strongest > Math.max(1, getBattlePower()) * 2L) return "Giant Killer";
        if (legacyData.getInt("Wins") >= 6) return "Proven Fighter";
        return "";
    }

    private void syncLegacyTitle() {
        if (!level().isClientSide) entityData.set(LEGACY_TITLE, computeLegacyTitle());
    }

    public String getLegacySummary() {
        int fights = legacyData.getInt("Fights");
        if (fights <= 0 && legacyData.getInt("Fusions") <= 0 && legacyData.getInt("NemesisStage") <= 0) return "No major history yet";
        StringBuilder out = new StringBuilder();
        if (fights > 0) out.append(legacyData.getInt("Wins")).append(" wins / ").append(legacyData.getInt("Losses")).append(" losses");
        if (legacyData.getInt("StrongestWinPower") > 0) out.append(" • best: ").append(legacyData.getString("StrongestWinName"))
                .append(" (PL ").append(legacyData.getInt("StrongestWinPower")).append(')');
        if (legacyData.getInt("Fusions") > 0) out.append(" • fusions ").append(legacyData.getInt("Fusions"));
        if (legacyData.getInt("NemesisStage") > 0) out.append(" • rivalry level ").append(legacyData.getInt("NemesisStage"));
        return out.toString();
    }

    /**
     * Remove DBSagasEntity's default NearestAttackableTargetGoal wrappers while
     * retaining HurtByTargetGoal and the rest of DMZ's native goal set.
     * This is the proven 0.6.2 technique, narrowly scoped to target acquisition.
     */
    private void removeAutomaticHostilityGoals() {
        try {
            Class<?> type = getClass();
            while (type != null) {
                for (Field field : type.getDeclaredFields()) {
                    if (!"net.minecraft.world.entity.ai.goal.GoalSelector".equals(field.getType().getName())) continue;
                    field.setAccessible(true);
                    Object selector = field.get(this);
                    if (selector != null) removeNearestTargetWrappers(selector);
                }
                type = type.getSuperclass();
            }
        } catch (Throwable ignored) {
            // If Forge/DMZ internals change, failing closed here is preferable to a crash.
            // The debug status command makes unexpected hostility visible during testing.
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void removeNearestTargetWrappers(Object selector) throws IllegalAccessException {
        Class<?> type = selector.getClass();
        while (type != null) {
            for (Field field : type.getDeclaredFields()) {
                field.setAccessible(true);
                Object value;
                try {
                    value = field.get(selector);
                } catch (Throwable ignored) {
                    continue;
                }
                if (!(value instanceof Collection collection)) continue;
                try {
                    collection.removeIf(AmbientFighterEntity::wrapperContainsNearestTargetGoal);
                } catch (UnsupportedOperationException ignored) {
                }
            }
            type = type.getSuperclass();
        }
    }

    private static boolean wrapperContainsNearestTargetGoal(Object wrapper) {
        if (wrapper == null) return false;
        if (wrapper.getClass().getName().contains("NearestAttackableTargetGoal")) return true;

        Class<?> type = wrapper.getClass();
        while (type != null) {
            for (Field field : type.getDeclaredFields()) {
                try {
                    field.setAccessible(true);
                    Object nested = field.get(wrapper);
                    if (nested != null && nested.getClass().getName().contains("NearestAttackableTargetGoal")) return true;
                } catch (Throwable ignored) {
                }
            }
            type = type.getSuperclass();
        }
        return false;
    }
}
