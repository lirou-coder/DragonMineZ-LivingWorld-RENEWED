tellraw @s [{"text":"=== Living World 1.0.0 ===","color":"gold","bold":true}]
tellraw @s [{"text":"Frieza reputation: ","color":"light_purple"},{"score":{"name":"@s","objective":"lw_frieza_rep"}}]
tellraw @s [{"text":"Pursuit state: ","color":"gray"},{"score":{"name":"@s","objective":"lw_scout_state"}}]
tellraw @s [{"text":"Use /lw fighter status, /lw equipment status, /lw history inspect, /lw memory status and /lw maintenance runtime for Living World diagnostics.","color":"gray"}]
